# PROJECT BURROW | BUR-0049 | VERIFIED JDK17 BUILD ENGINEER

RELEASE HOLD | RESULTS FIRST | NO OWNER WINDOWS TEST

Recover exact `SPOONS-BUR0049-R12-XP-DISABLED-RECONCILED-CHILD-R01.zip` and verify the supplied SHA-256. Inspect `READ-ME-FIRST-SPOONS-BUR0049-R12.md`, diff, and manifest.

1. In isolated child working copy use **actual JDK17**, Gradle **8.14.6**, and real `net.runelite:client:1.13.4` dependencies. Confirm actual `java -version`, `javac -version`, `gradle --version`, resolved RuneLite version. Java21 `--release 17` is NOT acceptable.
2. Run `clean test jar` and save the **full logs, JUnit XML for all test classes, dependency evidence, and JAR SHA-256**. Do not skip the newly staged `BurrowXpDisabledHostTest` or weaken any existing test assertions. On test failure, identify exact error and return to Spoons; do NOT claim PASS.
3. Verify Sessions XP feed stays UNAVAILABLE with no emitted XP event under the disabled host in synthetic fixtures, including all 24 skills, zero XP, legitimate/fabricated deltas, A→B→A, restarted mid-login, same-login hop, confirmed logout, stale +959 ordering and attempted forced AVAILABLE/direct gain. The catalog must still pass for all 51 loadouts.
4. Do NOT enable XP, add native gameplay tests, touch canonical files or GitHub, or request owner Windows. Source-safety objection is NOT resolved by a build.
5. Only after a verifiably green full build, hand the exact candidate to Tongs via `NEXT-UP-TONGS-BUR0049-R12-CONDITIONAL-L2.md`. Wrench release approval remains separate.
