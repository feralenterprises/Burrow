# TONGS | PROJECT BURROW | BUR-0049 R12 | CONDITIONAL INDEPENDENT COMBINED L2

**DISPATCH ONLY AFTER genuine Java 17 Gradle 8.14.6 / RuneLite client 1.13.4 `clean test jar` PASS for this exact R12 child.** RELEASE HOLD. READ-ONLY. NO WINDOWS PLAYER TEST.

Recover source `SPOONS-BUR0049-R12-XP-DISABLED-RECONCILED-CHILD-R01.zip`, supplied SHA-256, full successful build/JUnit/XML/JAR hash evidence, and `TONGS-BUR0049-COMBINED-L2-R01.md`.

Independently verify no accidental XP AVAILABLE or SessionXpGain can escape production `BurrowPlugin` while `SESSION_XP_ENABLED=false`, including stale +959 simulated ordering, 24 skills, true zero, duplicate/backward values, plugin restart, account A→B→A, same-login hops, and logout. Independently run tests where possible; check that changing previously XP-enabled test assertions follows an explicit disabled-feed safety contract and did not remove other safety coverage.

Verify R11 records preserved, 49 tickets with unique IDs and next 0050, 51 untouched Outfitter loadouts and four tabs/bank O. Note the XP observer is intentionally unused, not approved. Distinguish code source guards, synthetic regressions, genuine Java17 JUnit, and actual gameplay evidence. Produce exact PASS/FAIL with reproducible source references. No GitHub writes, canonical changes or owner Windows test. Forward to Wrench for separate no-live-XP account-safety disposition. **Do not declare release or Windows ready without explicit final gates.**
