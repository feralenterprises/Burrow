# TrashPanda Tracker C07 • Icon Pack + Home visual rebuild

**Status: owner visual review; RELEASE HOLD.** This is a candidate, not a RuneLite-tested or accepted release.

## What actually changed

- Replaced C06's repeated raccoon navigation tiles with a 2x2 four-destination menu using icons from the user-supplied `Iron Ledger Feral UI Icon Sheet.png` (home portal / pathfinder compass / outfitter pack and helmet / sessions journal).
- Used the original raccoon chest from `Iron Ledger Feral Raccoon UI Kit.png` for the compact header; exact TPT name and tagline are rendered. Full tab names visible, hover and active visual states.
- Rebuilt Home into a compact den journal with original landscape artwork and only one disconnected progression message. Observable weapon and combat level still use the real unchanged telemetry bridge. Removed visible debug labels and the old stacked demo-dashboard composition.
- For the old non-Home prototype pages, adjusted presentation/hitboxes without changing their model actions.
- Bank overlay / click adapter / bank state and game event logic untouched relative to C06. Original protected C04A unchanged.

## Exact art provenance

The complete original source sheets are included under `design/source-icon-sheets/`. `ICON-PACK-PROVENANCE.txt` accompanies the derived PNGs in `src/main/resources/.../ui`. The original reference sheet images were never redrawn; only specific artwork crops were downsampled for 225px rendering. O-bank's four approved states are protected and not redesigned here.

## Offline evidence

The `verification` folder contains *actual Java Swing* renders from `RenderOwnerReview`, a synthetic-content layout fixture clearly labeled NOT LIVE, short-height scroll renders, test logs and hashes. Java 21 compiled sources with `javac --release 17` because JDK 17 is unavailable in the current container. This is **not** a native Java 17 / Gradle / RuneLite test. Zero claims of in-client appearance or click acceptance are made.

## Windows native test

Unzip to a new folder. In PowerShell, open that folder and confirm that `gradlew.bat` is there. Install/select **JDK 17**, then run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\TEST-TRASHPANDA-WINDOWS.ps1
```

Verify four full navigation names/icons/hover/selected; Home in 225px and short viewport; real weapon/combat observation and logout clearing; O-bank existing chest normal/hover/pressed/disabled in real bank context; click action unchanged. Independent QA follows owner approval; release HOLD.
