# SPOONS BUR-0049 FINAL SOURCE + R11 RESEARCH RECONCILIATION | 2026-10-31

**RELEASE HOLD, NO WINDOWS TEST.** This is a new child, not canonical or a GitHub merge. R11 research is accepted as specification only. Keep older coordination records as historical evidence.

- **Source of this child:** latest verified XP/JUnit repaired child `BUR0049-SPOONS-R06-XP-JUNIT-FIX-INTEGRATED-CHILD-R01.zip`, SHA-256 `c78d2d27d340142e0363411cae678421e5180e6978d90f0da2976738fc7c4730`. Its four latest Java source/test corrections are preserved byte-for-byte.
- **R11 records intake:** `SPOONS-R11-TD-BIB-RECORDS-ONLY-CHILD-R01.zip`, SHA-256 `c49276b9f34e203fd7aa9131593ffef31f09bd9838f043c91744adabacd24e8b`. Take master record, roadmap, ticket register and two R11 research documents only. Do not take older Java source/test files from R11.
- **Ticket correction:** registered the ongoing `BUR-0049` XP task as a permanent ticket without renumbering BUR-0001…BUR-0048; `next_unused_id` now `BUR-0050`. `spoons_r06.next_unused_ticket=BUR-0049` is preserved in historical metadata only and superseded.
- **Actual proof:** prior 18 dependency-free checks and 6,545 Outfitter catalog checks passed with javac 21 --release 17; genuine JDK17/Gradle 8.14.6/RuneLite 1.13.4 `clean test jar` remains BLOCKED in this environment. No fresh JUnit 61/61 pass may be claimed.
- **XP account provenance:** Atlas independently produced a synthetic conditional +959 XP counterexample, not a native RuneLite trace. No authoritative account-bound cache readiness proof is established. XP remains an unapproved release blocker. Never weaken readiness assertions or claim a heuristic solves it.
- **Required gate order:** genuine JDK17 test results on exact reconciled source; Tongs combined L2; Wrench/owner account-safety decision (or safe, separately authorized disabled-feature path); only then stop dispatches and present exact targeted Windows gameplay steps. Best in Bank and bank highlighting remain OFF.

---

# SPOONS R11 OWNER-AUTHORIZED RESEARCH INTAKE | 2026-10-31 | RECORDS ONLY

**Scope:** Spoons reviewed independent Operation Deep Burrow R07-R11 evidence for Tormented Demons-only Best in Bank. **Disposition: ACCEPT AS RESEARCH REQUIREMENTS, NOT AS IMPLEMENTED OR NATIVE-VERIFIED.** This note is supplemental and does not supersede current XP/Sessions integration priority or lift release HOLD.

**Owner request:** Audit the research and incorporate defensible findings into the project's master record, roadmap and existing tickets. This records that authorization without treating the independent research as a patch or pre-approved release.

**Evidence:** R07 through R11 ZIPs pass CRC and declared member SHA checks. Frozen R08 source ZIP matches SHA-256 `bd7a7442985b9245f3a30fb2a35af32789d65b7f11507ef2f07d9f5e5088cd00`. Current records-only parent is the Spoons XP R06 child (see intake receipt for hash). R08/R09 experiments use synthetic/isolated execution; there is no live native proof of bank readiness, gear ranking or TD support.

**Existing ticket coverage (NO NEW PERMANENT ID):**
- `BUR-0023`: authenticate initial bank observation, use RuneLite underlying BANK container, preserve explicit UNKNOWN, recover from missed events/rejected readiness, refresh on mutation.
- `BUR-0042`: account/login epoch isolation, coherent bank+inventory+equipment snapshot and observed-as-of validity, placeholders/fillers/notes/charge/potion-storage semantics.
- `BUR-0030`: TD-only complete-loadout Best in Bank pilot *conditional on* verified ownership and native bank-readiness. Do not select solely by exact item matches or item-stat rank. Fallback must be compatible and actually owned; unknown is not zero.
- `BUR-0021`/`BUR-0033`: supplies, compatible ammo/runes/spells, 28-slot inventory including Emberlight+defender to two-handed bow swap, real withdrawal-ready equipment.
- `BUR-0034`/`BUR-0046`: TD encounter mechanics and method provenance. TDs and Demonic Gorillas are **not** added to the existing 15 bosses by this intake; method registration remains a future separately reviewed decision.
- `BUR-0020`: label last-verifiable bank quantity and as-of timestamp; no stale count described as current.

**Source-grounded safeguards:** `GameTick` follows processed server packets but does not establish complete bank readiness; `ItemContainerChanged` signals changes but may not occur again after opening. RuneLite BankPlugin uses the underlying BANK container for quantity searches independently of rendered bank widgets. Bank tabs/search/tags should not automatically invalidate the underlying container, but native evidence is needed. A null bank container must never be reported as verified-empty. Reject placeholder/filler ownership and inspect item variations before recommending. Account scope and motion of items across containers must not cause double counting.

**TD recommendation design (research only):** For real owned equipment, compare complete practical melee+range or melee+magic configurations. Start with Emberlight+defender and a viable ranged weapon such as Scorching bow when present; consider compatible Eclipse atlatl/crossbow/demonbane spells conditionally. Distinguish TD prayer changes, shield-down special single-hit damage, temporary guaranteed accuracy and Ironman supply cost. Check equipping requirements, charges, ammunition and inventory swap capacity, not just raw stats. The first version must explain why gear was selected, and show 'not recommended / unknown' when no valid owned option exists. No player-specific bank contents have been established.

**Release / verification:** HOLD. TD Best in Bank is **NOT IMPLEMENTED**, bank completeness **UNPROVEN**, native TD test **NOT PERFORMED**. No additional owner PC testing requested at this research intake. Official Java, gameplay JSON, loaded Outfitter catalog, artwork and GitHub remain unchanged. Source parent preserved as separate ZIP; only project coordination records are revised in the child handoff.

**Source references:** RuneLite `BankPlugin.java`, `GameTick.java`, `ItemContainerChanged.java`, `ItemComposition.java` (https://github.com/runelite/runelite); OSRS Wiki Tormented Demon/Strategies (https://oldschool.runescape.wiki/w/Tormented_Demon/Strategies). See Spoons intake receipt for source hashes, evidence grades and conflicts.

---

# CURRENT OWNER OVERRIDE | Batch development before native testing | 2026-10-30

**Effective checkpoint:** `BUR-BATCH-SPOONS-R01` | **Release:** HOLD | **Permanent tickets:** 48 | **Player-facing batch:** BUR-0016 through BUR-0048 (33 tickets). This section supersedes conflicting old manual-scan and session-only language below; the historical roadmap is retained as evidence, not current truth.

**Owner directive:** No more manual RuneLite testing or owner build requests until every one of the 33 player-facing tickets has been worked on and all feasible implementations are integrated. Maintain offline tests, source review and independent QA in the meantime. A researched, blocked, deferred or patched ticket is not a completed feature. A ticket may be blocked, but it must have a documented reason and next possible action. Do not lift Release HOLD.

**Current consolidated source:** P1 integrated F06 + BUR-0035 KBD visible warning + BUR-0019 ordinary item hover, assembled in that exact order. Last two UI changes are staged with scoped reviews, not native accepted. BUG: old `PreparationTooltipSmokeCheck` assumes static KBD preparation Y coordinate; KBD warning moves content +72px; failure predates BUR-0019. Fix its assumption as part of BUR-0037 UI behavior and re-run before marking full automated suite PASS.

**Batch workflow:** One exclusive `BurrowPanel.java` writer at a time: next Sporks BUR-0037 clipped preparation notes, then BUR-0038 method dropdown, then remaining UI issues. Noodles separately owns canonical boss gear & inventory dataset, without concurrent JSON edits. Separate observation/storage features may progress only with file-scope isolation and account-safety constraints. Tongs read-only research/L2; Spoons owns canonical register & merging. Every handback includes actual patch/code or explicit blocker and a next-up one-click dispatch.

**Owner priority board:** All 33 ticket IDs BUR-0016..BUR-0048 remain in the priority scope. Visible screenshot authoritatively establishes ranks #1 BUR-0040, #2 BUR-0034, #3 BUR-0048, #4 BUR-0039, #5 BUR-0021, #6 BUR-0030, #7 BUR-0023, #8 BUR-0020, #9 BUR-0016, #10 BUR-0033. Ranks #11–33 were not exposed in that screenshot and are intentionally left unranked in `docs/coordination/BUR-BATCH-OWNER-33-STATUS.csv` rather than invented.

**Critical dependency:** Best in Bank BUR-0030 cannot be implemented ahead of full verified Wiki Recommended acceptance; planning/canonical matching research is allowed, but a second independent loadout dataset is forbidden. Manual `Scan Bank` is development-only: intended product automatically takes a read-only bank+inventory+equipment snapshot whenever the bank opens, stored by account, persistent and timestamped. **Not yet implemented.** Sessions target current login plus ten completed-session summaries, no pins; independent boss-trip history retained for Outfitter adaptive supply work.

**Native acceptance:** One consolidated owner test phase only after the 33 tickets have each received concrete work or a verified blocker, and all feasible patches have been assembled. Still keep Spoons L1 / Tongs L2, independent verification, Java17-only gate and actual logs before claiming technical or native PASS.

---

# Project Burrow: Feral Edition | R19

**Checkpoint:** `BUR-SYNC-0019-R19` · **Observation cutoff:** 2026-10-29T23:33:52Z · **Release:** **HOLD** · **Current candidate:** BUR-0013 C03.  **No Iron Ledger, Jagex Launcher, B01 or GitHub writes.**

## Actual outcome

**PASS, owner-native C03 smoke.** RuneLite launched with Burrow HOME. Owner shared screenshot showing real seven combat skill levels (Attack 91, Strength 94, Defence 91, Hitpoints 98, Ranged 97, Magic 94, Prayer 79). Logout screenshot shows "Log in to see combat levels" and `?` placeholders. Owner said relogin restored levels and live weapon detection still worked; latter two are **owner-reported**, not separate new screenshots. Owner previously supplied C02 A/B/empty live equipped-weapon screenshots archived in `BUR-0012-OWNER-NATIVE-WEAPON-EVIDENCE-R01.zip`.

**C03 source proven:** exact producer ZIP `BUR-0013-C03-WINDOWS-RUNELITE-DEV-KIT-R01.zip` SHA-256 `f37b3fb0c9020e782c5c17f8b18c4501704cca6564dc1efcf7570fcb81969055` (149409 bytes, 50 member ZIP CRC PASS); scoped patch `BUR-0013-C03-SOURCE-PATCH-R01.zip` SHA-256 `23b3a36e6d13afd1ee57666a44fd9022bc4449cd26c7ed8090b5deaba3425f9d`. Producer reported 383/383 offline `javac --release 17` under Java21 and 32/32 **synthetic** RuneLite host checks. C03 **was not committed to GitHub** and C01 historical Java17 CI does **not** validate C03.

**PowerShell note:** owner pasted `:compileJava` and a deprecated-API note handled as a PowerShell `NativeCommandError` at launcher line 90. Native client later launched. The entire local Java17 Gradle `clean test` log and exit code were **not provided**; do not mark a full clean build as separately documented PASS. See `BUR-0013-C03-OWNER-NATIVE-RECEIPT-R01.json` and `BUR-0013-C03-OWNER-NATIVE-EVIDENCE-R01.zip`.

| Track | Current verified boundary | Next action |
|---|---|---|
| B01 and C01 baseline | B01 `main` `1d1b6f7a3fecae9264f8a9c863cfa6ca6c051ffe` preserved; C01 isolated commit `13e4f59f749e6a16cf2631f7a1496be10b265a47` with genuine Java17 GitHub CI #40960328298 PASS | Do not modify or merge |
| BUR-0012 C02 | Weapon labels for actual equipped item / empty slot proven in owner-native screenshot; source L1 static pass 355/355 and 21/21 synthetic checks; C02-specific full Java17 log and independent native QA missing | Keep original C02 records and limitations |
| BUR-0013 C03 | **Owner-native smoke PASS** on stats and logout, relogin/weapon owner reported; exact package checksum and zip integrity checked | Spoons independent C03 L1, then Tongs scoped L2. Request complete JDK17 Gradle log if available. |
| BUR-0014 Pathfinder | **PREPARED, NOT DISPATCHED.** One real RuneLite quest-state input changes Pathfinder recommendation; completed quest excluded, incomplete quest appropriate | Noodles after bounded C03 QA, one behavior per ticket |
| F02 / F03 | F02 demo-only Best in Bank OPEN; F03 right-click demo kill OPEN | Future isolated bug tickets, no false release |

**Status definitions:** owner screenshot / report is valuable native evidence, but **not** independent L1/L2 acceptance. Existing visual offline preview not actual RuneLite proof. Native C03 scope does not show live quest state, bank, kills, or account-aware Pathfinder.

**Next-up:** Spoons for BUR-0013 independent package/source and documented Windows output intake, then Tongs independent scoped QA; BUR-0014 Noodles queued, no implementation begun. **Release HOLD.**

## Owner-locked product decision: Boss Loot Table (Oct 29, 2026, local)

**Name:** Boss Loot Table. **Placement:** **Outfitter**, not Sessions. **Required for Outfitter to be declared complete**, but **not required in the current C04A integration/visual-UI ticket**. Owner's RuneLite boss loot screenshot is the layout reference, archived as `Reference Archives/BUR-OUTFITTER-BOSS-LOOT-TABLE-REFERENCE-20261029.png`.

**Acceptance:** Compact authentic boss-name × KC heading; total/actual loot values, supplies cost, net profit; item-icon-and-quantity Drops grid; separate Supplies Used grid; boss-specific rare drops with verified per-item odds, KC cumulative probabilities, aggregated probability for selected rares, and honest dry-streak statistics. Preserve unknown/not-observed states, source confidence, and data coverage. Never infer KC from drops or present projected estimates as actual loot.

**Scope cut:** Do **not** build generic Loot Tracker or general NPC/skilling loot UI; RuneLite already has that. Do **not** build Quest Helper-style material checklists; Quest Helper already handles those. Pathfinder still recognizes quest prerequisites and completion. Sessions can summarize/link to boss data but **Boss Loot Table belongs to Outfitter**.

**Implementation state:** Not yet implemented and native-verified in Burrow. No change to existing C04A owner smoke, C03/B01 legacy gate, R19 ticket-sync checkpoint or release **HOLD**. This is a scoped owner requirement addendum, not evidence of code delivery.

## Deferred defect | BUR-0016 charged jewelry and imbued ring recognition (Oct 29, 2026 local)

**OPEN P2 / NOT STARTED.** Owner reports Outfitter bank layout does not correctly load an **imbued Berserker ring** and a **charged Amulet of glory**, with screenshot showing **Amulet of glory(6)** tooltip plus mismatched/empty-looking prepared slots. Exact cause is unknown; investigate item variant ID matching versus layout rendering. Two owner screenshots are saved under `/Project Burrow/Reference Archives/BUR-0016-EVIDENCE-*.png`.

**Future acceptance:** Observe real IDs/variants; correctly display appropriate charged/imbued variants without implying nonexistent bank ownership or silently losing charges; test ordinary/imbued ring, charged/uncharged glory, account/bank lifecycle, and C04A regressions. Sporks owns later isolated work, **not dispatched**. Do not block current Feral Modern UI progress; no code changes from this ticket. Release **HOLD**.


## Owner-prioritized implementation backlog (Oct 29, 2026 local; plan only, no code/QA)

**Pinned next:** `BUR-0017` Feral Modern shared Swing navigation and real Home from owner-tested C04A; then `BUR-0018` remaining screen styling. Preserve C04A and original Iron Ledger. **Release HOLD.**

After those, order balances estimated **player impact** and **implementation effort**, while respecting prerequisites. Effort estimates are provisional until source inspection; they are not validated hours or delivery dates. Existing `BUR-0016` and `BUR-0014` are reused, never duplicated.

| Order | Ticket | Scope | Impact | Effort |
|---:|---|---|:---:|:---:|
| 1 | `BUR-0017` | Feral Modern UI foundation and Home | 5/5 | M |
| 2 | `BUR-0018` | Feral Modern remaining screens | 4/5 | M |
| 3 | `BUR-0019` | Outfitter exact item-name hover tooltips | 4/5 | S |
| 4 | `BUR-0020` | Bank stock vs recommended quantity display | 5/5 | S-M |
| 5 | `BUR-0016` | Fix charged glory / imbued Berserker ring detection | 4/5 | M |
| 6 | `BUR-0022` | Verified Wiki Recommended Scurrius pilot | 5/5 | M |
| 7 | `BUR-0021` | Boss-appropriate 28-slot supply planning | 5/5 | M |
| 8 | `BUR-0014` | Live quest-state Pathfinder first step | 5/5 | M-L |
| 9 | `BUR-0023` | Manual Scan Bank with actual observations | 5/5 | L |
| 10 | `BUR-0024` | Optional bank gear/supply highlighting | 4/5 | M |
| 11 | `BUR-0025` | Observe real boss kill-count deltas | 5/5 | M-L |
| 12 | `BUR-0026` | Boss loot and supplies observations | 5/5 | L |
| 13 | `BUR-0027` | Outfitter Boss Loot Table UI | 5/5 | M |
| 14 | `BUR-0028` | Verified individual rare-drop odds and dryness | 4/5 | M |
| 15 | `BUR-0029` | Aggregated chance for selected boss rares | 4/5 | M-L |
| 16 | `BUR-0031` | Sessions real activity/history MVP | 4/5 | L |
| 17 | `BUR-0032` | Saved Pathfinder goal and rank behavior | 5/5 | L |
| 18 | `BUR-0033` | Outfitter final-departure readiness checks | 4/5 | M |
| 19 | `BUR-0034` | Vetted multi-boss and combat-style expansion | 4/5 | L |
| 20 | `BUR-0030` | Best in Bank real-owned set resolver | 5/5 | XL |

**Owner-observed Outfitter defects:** `BUR-0016` charged Amulet of glory (including 6) and Berserker ring (i) not resolved (root cause unknown); `BUR-0019` item NAME hover only (not GE value/combat stats); `BUR-0020` duplicated apparent bank totals (165 potions, 533 sharks) must not masquerade as recommended quantities; `BUR-0021` four prayer potions / four sharks must be replaced with real boss/method-specific 28-cell supply recommendations. Owner screenshot: `Reference Archives/BUR-0020-0021-EVIDENCE-DEMO-SUPPLIES-20261029.png`.

**Outfitter completion:** `BUR-0027` **Boss Loot Table** belongs in **Outfitter**, uses owner-approved screenshot and boss-only real observations, with drops/supplies/value/profit plus per-item and aggregate rare odds after supporting data is proven (`BUR-0025`, `BUR-0026`, `BUR-0028`, `BUR-0029`). No generic Loot Tracker or Quest Helper clone.

**Safety:** Only ranked backlog requirements were queued, no source/code/test executed or QA gates changed. Existing historical `BUR-SYNC-0019-R19` stays the last actual Spoons sync. Next queue snapshot: `Reference Archives/BURROW-PRIORITIZED-BACKLOG-20261029.json`.

---

## BUR-SYNC-0020-R20 | BUR-0014 Spoons intake | 2026-10-30T02:55:48Z

**Disposition:** Noodles' isolated BUR-0014 quest-state feature is a **producer implementation candidate**, independently replayed by Spoons at **9/9 offline PASS**. **Release HOLD.** No native RuneLite build/launch or quest completion was observed. This section supersedes the *status* of BUR-0014 as PREPARED in older R19 material; it does not delete or backdate historical records. R19 backups are included in the sync kit.

**C07 source/visual preservation:** Parent `TRASHPANDA-C07-SOURCE-AND-WINDOWS-TEST-KIT.zip` SHA-256 `c13c068577dd55fcafc25e55aec449ad870df7abbb9f7cd62a84ff72321fcc5a`; new candidate `TRASHPANDA-BUR-0014-QUEST-SOURCE-CANDIDATE-R01.zip` SHA-256 `958351036e787c87eaa013273031908fe6e6d073e2b3568c9c34336fd2561a97`. Exactly **5 modified + 3 added**, zero deleted; **38/38** protected files identical, including C07 navigation/visual assets, C04A bank adapter and core. Patch SHA-256 `b8585849c1d524d9f9c8d8d2f8e99973eb298427e0c09a438e8f9daa63fb10a8` applies cleanly (`patch -p1 --dry-run`), ZIP CRCs pass.

**Feature:** RuneLite read-only `Quest.COOKS_ASSISTANT.getState(client)` on client thread updates one Pathfinder recommendation: not started → start; in progress → finish; completed → no active quest recommendation; loading/unknown → no unfinished claim; logout → clear. Epoch-fenced EDT updates. A synthetic fixture/replay is **not** evidence of real account quest state.

**Tests/gates:** Producer reported 9/9 offline; Spoons independently compiled with **javac 21.0.12.1 `--release 17`** and reran 9/9 tests PASS. Genuine Java 17 preflight `bash scripts/build-runelite-java17.sh` returned **exit code 17** because host Java/javac were 21.0.12.1; Gradle/RuneLite compilation did not start. Real owner quest-state observation, complete Java 17 Gradle test/run receipt, in-client C07 UI/weapon/combat/bank/regression, and Tongs L2 QA **PENDING**. Prior C03 screenshots are not BUR-0014 proof; **BUR-0013 C03 L1/L2 remains pending**. Explicit BUR-0014 dispatch allowed isolated production work, **not** a QA-gate waiver.

**Roadmap status:** C07 visual direction provisionally owner-accepted; G0 native **PENDING**, G1 BUR-0014 **PRODUCER_COMPLETE / SPOONS_OFFLINE_VERIFIED / NATIVE_BLOCKED**, G2–G6 remain unaccepted/not delivered per `TPT-PLAN-C07-R01`. No backend account-intelligence expansion, Sessions, Bank Scan, Best in Bank, or Boss Loot Table accepted in this intake. Legacy F02/F03 and BUR-0016/19/20/21 remain open or queued; all other ticket IDs and dependencies preserved.

**Next action:** owner Windows machine with **actual JDK 17**, network-enabled Gradle dependencies, and RuneLite developer run (use exact candidate ZIP and included launcher) supplies full Gradle output/exit and live before/after quest/logout screenshots. If quest already completed, prove only the finished/no-recommendation state and use an unfinished account for true transition proof; don't fabricate a completion. Show C07 navigation/scroll, weapon/combat and O-bank click/chest states. Spoons then receipts native evidence; **Tongs** independently reviews candidate, API integration and native behavior. No merge or release.

**QA chain:** Spoons *source and offline intake only* → owner native verification → Spoons evidence check → Tongs independent L2 → Wrench audit/owner release decision only after full gates.

---

## BUR-OUTFITTER-UNIFIED-01 | candidate handback | 2026-10-30

R04 fixes the six Rex potion IDs. Thirteen official Wiki method profiles are implemented in an isolated Burrow 14 candidate with 11/28 geometry and source-backed sprites; 29 variant cells remain visibly unresolved. Obor, Bryophyta, Prime and Supreme show unavailable. Java 17 offline suites pass; RuneLite 1.13.4 direct dependency compile passes; 22/22 host JUnit tests pass. Native candidate verification and normal Gradle task remain pending. Best in Bank, bank scan, highlighting and release remain HOLD. Source SHA-256 `3d10251d0e8808e856250cc0911aacc29d7b55a2edfcd2f2cf34a58c79594677`; candidate JAR SHA-256 `713b3e7aa2b0d4000781ba726118c0db07f14d80ad4038b8c8a409c3f1d86cef`.


---

## BUR-OUTFITTER-WIKI-TIERS-03 | 2026-10-30 | HOLD

An isolated candidate from Tiers-02 now presents Entry, Recommended and Optimal for 15 bosses and 17 methods (51 plans). The 13 verified R04 Recommended layouts remain the basis; dose/charge/stack decisions and new plans are explicitly TrashPanda Tracker curation from Wiki strategy and mechanics, with Obor/Bryophyta community leads labeled separately. Obor, Bryophyta, Dagannoth Prime and Supreme now have complete 11/28 plans. Four KBD/Vorkath Dragonfire ward charge-state cells remain text-only rather than guessed. The R06 item-ID and equipment validator passes, Java 17 offline 10 suites pass, RuneLite 1.13.4 direct dependency compile passes, and 22/22 JUnit pass. Full Gradle task and native RuneLite candidate testing remain pending. The Burrow 14 baseline and Iron Ledger are untouched; this is not a merge or release. See `docs/research/BUR-OUTFITTER-WIKI-TIERS-03-COVERAGE.md` and R06 JSON within the source ZIP.

---

## BUR-OUTFITTER-QUALITY-04 | 2026-10-30 | HOLD

Q07 revises all 51 TPT-curated loadouts across 15 bosses and 17 methods. R04/R06 snapshots are preserved. Obor, Bryophyta, Amoxliatl, Giant Mole, KBD and the other methods have practical tier/provision corrections. Fully charged Dragonfire ward means charged item ID 22002 plus a 50-charge in-game check; only KBD/Vorkath Optimal use it. Java 17 offline, direct host dependency compile, 22/22 JUnit and the complete data validator pass. Full Gradle and native RuneLite remain pending. No merge or release. See Q07, all-51 audit and five reviews in source.


## SPOONS-R05 | source-only consolidated child | 2026-10-30 Pacific | RELEASE HOLD

Source parent: `BUR-0022-SPOONS-L1-INTEGRATED-R04.zip` (independently reviewed Scurrius BUR-0022 L1). Frozen common R03 and parent R04 archives remain unmodified. R05 adds dependency-isolated cores for BUR-0020 bank counts, BUR-0025 boss KC delta, BUR-0028 independent rare-drop odds, BUR-0032 Pathfinder goal state, plus BUR-0037 formatted switch notes in the existing Outfitter UI. The BUR-0037 replacement source preimage exactly matches both R03 and R04. No other original source paths have been modified except ticket/master/roadmap coordinator documents. Original 15 bosses, 17 methods, 51 loadouts, tier identities, inventory quantities, artwork and bank layout preserved from R04. No new methods, real bank scan, Best in Bank, adaptive supplies, or real Sessions have been implemented here.

**Verification:** 25 offline non-RuneLite main Java sources compile under JDK 21 `javac --release 17`, class version 61; 19/19 standalone offline test entry points PASS, including original regression coverage, BUR-0022, and the new core/formatter tests. `scripts/verify-final06.py` PASS: 15 bosses / 17 methods / 51 profiles / 561 gear slots / 1,428 inventory slots. This is NOT genuine JDK17 Gradle, not the RuneLite host build and NOT owner-native or Tongs L2 acceptance; release stays HOLD.

**Deferred lane outputs received:** BUR-0016 diagnosed Glory(6) exact-ID mismatch, ring still requires live identity evidence; BUR-0017/0018 Bandit visual audit; BUR-0021 supplies proposal for 41 changed inventories; BUR-0023/0042 read-only bank observation/account-cache contract; BUR-0026/0027/0031 event contract; BUR-0034 alternate-style research; BUR-0046 independent combat-style matrix; BUR-0047 unresolved window-size triage. These have NOT been merged as production implementations.

**Owner-locked Sessions correction:** BUR-0031 is CURRENT-LOGIN ONLY, clear activity on logout; no rolling 10 old sessions. Any previous ticket or roadmap reference to ten completed summaries is superseded by this correction.

**Next dispatch:** Tongs independent L2 for R05 integrated source, source-diff scope, 19 offline tests and method/gear checks; then Spoons collect genuine Java 17 Gradle and targeted native evidence. Supply research needs independent tier/method L2 before production data changes. Bank observer blocked until exact variant/quantity/account boundary issues are resolved. Ticket IDs BUR-0001..BUR-0048 retained; BUR-0049 unassigned.


## SPOONS-R06 | BUR-0025 L2 boundary repair + BUR-0031 authoritative correction | RELEASE HOLD

The isolated R05 source had an independent Tongs L2 failure: rejected wrong-account and stale-epoch boss KC observations reported zero delta but returned the active session's nonzero KC total. An R06 targeted code fix returns `sessionTotal=0` in rejected NO_SESSION, WRONG_IDENTITY, NO_EPOCH, WRONG_EPOCH, and OLD_OR_REPLAYED observations. Accepted in-scope samples preserve normal session totals; the tracker remains not wired to RuneLite host. R06 adds explicit negative regression coverage after a nonzero gain, including account switch, login/epoch IDs and generations, replay, and world hop. Original boss dataset and UI remain identical to R05.

The authoritative BUR-0031 ticket and current priority queue now say Sessions CURRENT LOGIN ONLY, reset on logout/account switch, NO ten saved summaries. The former title, mission and acceptance are preserved in `BURROW-TICKETS.json` audit metadata; previous priority-queue snapshots and old roadmap checkpoints remain unchanged for evidence provenance. This is contract correction, not an implemented Sessions feature.

**Next up:** Tongs independent targeted R06 L2; do not mark R05 L2 PASS by inheritance. Genuine JDK 17 Gradle/RuneLite client checks and owner-native acceptance remain pending; release HOLD.
