# BUR-OUTFITTER-QUALITY-04 source candidate — HOLD

This isolated candidate derives from `BUR-OUTFITTER-WIKI-TIERS-03-SOURCE.zip`, SHA-256 `736a52914bf2eabfe8debdcc8c9d27b77dfc491696eee51cfee8da3697b6d3ca`. The R04 and R06 source snapshots are preserved; the active curated profile set is `docs/research/BUR-OUTFITTER-QUALITY-04-Q07.json`.

Fifteen bosses, seventeen methods, fifty-one Entry/Recommended/Optimal plans. All are explicitly TPT-curated using Wiki mechanics/rankings; exact supply budgets and positions are product choices, not literal Wiki templates. The source audit and five complete tier reviews are in `docs/research/BUR-OUTFITTER-QUALITY-04-AUDIT.md` and `BUR-OUTFITTER-QUALITY-04-FIVE-REVIEWS.md`. The four prior ward placeholders are resolved: Recommended KBD/Vorkath use anti-dragon shield; Optimal uses charged Dragonfire ward ID 22002, whose full 50 charges must be checked in client.

Use actual JDK 17. Run `bash scripts/build-offline.sh` and `python3 scripts/verify-quality-q04.py`. On an owner machine with a real Gradle distribution and dependency access, run `bash scripts/build-runelite-java17.sh`; on Windows, use `gradlew.bat clean test jar`. Local direct RuneLite 1.13.4 dependency compile and JUnit package scan passed; the full Gradle task was blocked by the local environment. No native RuneLite candidate test is claimed.

The UI and approved art remain intact. Best in Bank, live bank scanning, highlights, and account-aware substitutions are outside this checkpoint. Do not merge or release until native and independent QA gates pass.
