# Project Burrow BUR-0015 C04A | Windows RuneLite test candidate

## Important
This **C04A** source candidate fixes a missing RuneLite plugin event connection in Astra's
C04 emergency save. **C04A has NOT been compiled against RuneLite or tested in-client.**
The previously reported 21 JUnit PASS and Java 17 compile apply to **C04 only**,
not this C04A patch. The old C04 JAR was deliberately removed because it lacks the wiring.
Original Astra C04 emergency ZIP remains unchanged. Release: HOLD.

## Windows / IntelliJ steps
1. Extract THIS ZIP into a **new** directory (not your last known-good C03 project).
2. Open `Project-Burrow/build.gradle` as a Gradle project in IntelliJ.
3. Set IntelliJ Project SDK **and Gradle JVM** to full **JDK 17**.
4. Open IntelliJ Terminal in `Project-Burrow` and run:
   ` .\gradlew.bat --no-daemon clean test jar `
5. Only after a successful build, run:
   ` .\gradlew.bat --no-daemon run `
   OR IntelliJ Application configuration: main class
   `gg.feral.burrow.runelite.BurrowPluginTest`, classpath from **test** module,
   JDK 17, VM `-ea`, program args `--developer-mode`.
6. In RuneLite enable **Project Burrow [Experimental]** and **Bank Tags**.
   Disable the standalone Outfitter so O buttons do not compete.
7. Open an ordinary bank, select **Scurrius** in Burrow, click the green **O** in bank header.
   Expect sample 8-column equipment-left / supplies-right layout. Click O again or All items.
8. Verify Home combat levels, weapon detection, bank search, inventory operations,
   logout/relogin, closing/reopening bank, and Vorkath/Barrows never borrowing Scurrius.
9. Send the **first build error** or screenshot/result to this chat. Do not call it passed
   until tested in the actual client. Do not merge or release.

## What changed since C04
- `BurrowPlugin` now creates and cleans up `OutfitterBank` on the client thread.
- Added event routes for GameTick, MenuEntryAdded and MenuOptionClicked.
- Shares actual panel's `BurrowModel.bankSelection()` with bank controller.
- Clears temporary layout on logout/navigation shutdown/plugin disable.
- Original C04's compiled JAR deliberately removed; rebuild locally to validate this patch.

## Still NOT included
No wiki fetch, bank scanner, Best in Bank optimizer, or bank highlighting.
This is one small native UI behavior for testing, not a release.
