# BUR-F06-NOODLES-BUILD-02: actual JDK 17 + RuneLite Gradle build receipt.
# Run from the extracted Project-Burrow directory in Windows PowerShell.
# The evidence folder is deliberately OUTSIDE build/ so Gradle clean cannot delete it.
$ErrorActionPreference = 'Stop'
$javaVersion = & java -version 2>&1 | Out-String
$javacVersion = & javac -version 2>&1 | Out-String
if ($javaVersion -notmatch 'version "17([.\"]|$)' -or $javacVersion -notmatch 'javac 17([.]|\s|$)') {
    throw "Actual JDK 17 required (runtime AND compiler). Set JAVA_HOME and PATH correctly. Runtime: $javaVersion Compiler: $javacVersion"
}
if (-not (Test-Path -LiteralPath '.\gradlew.bat')) {
    throw 'Missing Gradle wrapper at Project-Burrow root; do not claim a successful build.'
}
$evidence = Join-Path (Get-Location).Path 'f06-native-evidence'
New-Item -ItemType Directory -Force -Path $evidence | Out-Null
$javaVersion | Out-File -FilePath (Join-Path $evidence 'java-version.txt')
$javacVersion | Out-File -FilePath (Join-Path $evidence 'javac-version.txt')
"Command: .\gradlew.bat --no-daemon --stacktrace clean test jar" | Out-File -FilePath (Join-Path $evidence 'command.txt')
& .\gradlew.bat --no-daemon --stacktrace clean test jar 2>&1 | Tee-Object -FilePath (Join-Path $evidence 'gradle.log')
$gradleExitCode = $LASTEXITCODE
if ($gradleExitCode -ne 0) {
    "Gradle exit code: $gradleExitCode" | Out-File -FilePath (Join-Path $evidence 'status.txt')
    throw "Gradle failed ($gradleExitCode). Preserve gradle.log; release remains HOLD."
}
$files = @(Get-ChildItem -LiteralPath 'build\libs' -Filter '*.jar' -File -ErrorAction Stop)
if ($files.Count -eq 0) { throw 'No newly built plugin JAR under build/libs. Release HOLD.' }
$files | ForEach-Object { Get-FileHash -Algorithm SHA256 $_.FullName } | Format-List | Out-File -FilePath (Join-Path $evidence 'jar-sha256.txt')
$testDir = 'build\test-results\test'
if (-not (Test-Path -LiteralPath $testDir)) { throw 'Missing JUnit test-results output. Release HOLD.' }
Copy-Item -LiteralPath $testDir -Recurse -Force -Destination (Join-Path $evidence 'test-results')
"Gradle exit code: 0. JDK17 build completed. Native RuneLite QA NOT YET RUN. RELEASE HOLD." | Out-File -FilePath (Join-Path $evidence 'status.txt')
Write-Host "JDK17 BUILD COMPLETE. Evidence: $evidence. Native RuneLite QA and owner acceptance still required."
