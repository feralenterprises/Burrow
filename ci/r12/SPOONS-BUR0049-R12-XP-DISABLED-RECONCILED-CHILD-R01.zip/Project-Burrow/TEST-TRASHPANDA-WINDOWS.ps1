# Native Windows smoke. Requires real JDK 17, network access for Gradle/RuneLite dependencies.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Test-Path -LiteralPath '.\gradlew.bat')) { throw 'Missing gradlew.bat. Run from the extracted kit root.' }
$jdkVersion = (& cmd.exe /d /c 'java -version 2>&1' | Out-String)
Write-Output $jdkVersion
if ($jdkVersion -notmatch '(?s)version "17[."]') { throw 'JDK 17 required. Set JAVA_HOME/PATH to JDK 17, then retry.' }
# Windows PowerShell 5.1 can throw NativeCommandError for Gradle stderr even on exit 0.
# Inherit real console streams via cmd without misclassifying Gradle's normal output.
$runner = Start-Process -FilePath $env:ComSpec -ArgumentList @('/d','/c','gradlew.bat --no-daemon clean test run') -WorkingDirectory $PSScriptRoot -NoNewWindow -PassThru -Wait
if ($runner.ExitCode -ne 0) { throw "Gradle or RuneLite run failed (exit $($runner.ExitCode))." }
