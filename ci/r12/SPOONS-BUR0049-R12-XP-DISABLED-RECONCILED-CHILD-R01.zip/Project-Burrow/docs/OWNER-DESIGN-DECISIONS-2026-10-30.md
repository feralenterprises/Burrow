# PROJECT BURROW — OWNER DESIGN DECISIONS, 2026-10-30

**Authority:** Owner decisions from the October 30 discussion. **Status:** DESIGN APPROVED / ENGINEERING NOT VERIFIED. **Release:** HOLD.  
**Spoons:** Reconcile with `BURROW-ROADMAP.md`, `BURROW-MASTER.json` and `BURROW-TICKETS.json` before making any official status claims. This document does NOT mean those three files have been updated.

## 0. Architecture and product boundaries

- User-facing working name **TrashPanda Tracker** (provisional); internal project name **Project Burrow**. Tagline exactly: **“We dig through your account so you don't have to.”**
- The accepted visual direction is **Feral Modern**, approximately 225px RuneLite sidebar, graphite/near-black, restrained bronze/gold, feral raccoon artwork and approved icon pack. Do not substitute generic icons; preserve the original source art.
- Four main tabs: **Home, Pathfinder, Outfitter, Sessions**. The separate raccoon-chest/O bank shortcut is **not** a fifth sidebar tab.
- Project Burrow is separate from historic Iron Ledger. Never overwrite or silently merge Iron Ledger.
- Core product stance: **inform and assist, never commandeer the player's game**. No unsolicited GP/gear-sale opinions, automatic allocation or purchases, wealth/value judgements, automatic combat-style or active-task switching.

## 1. Outfitter: Wiki Recommended baseline and quality gate

- 15 bosses, 17 methods and 51 Entry/Recommended/Optimal configurations in authoritative FINAL-06 dataset, SHA-256 `98e53286e043c8308f496741ed6883c2eda1299203340662e4d816f441a56631`.
- Preserve boss and method selectors, three combat-style selectors where applicable, gear/item name hover identification and realistic inventory quantities; do not substitute imaginary equipment. Each tier must be mechanically possible and genuinely useful. Check two-handed/offhand conflicts, ammunition, spells, charges, gear requirements and boss phase/combat mechanics.
- Viewing a boss or gear setup is not gated behind prerequisites. A player may inspect a loadout for a boss they cannot yet reach. Pathfinder handles access prerequisites. Unsupported bosses/methods state **Not supported yet**; do not invent alternative guides.
- Never change chosen combat style automatically because bank has stronger items of another style. Mark impossible or mechanically unsuitable methods as **Not Recommended** or disabled with explanation.
- Show boss-specific mechanics/warnings, including Wilderness travel/PvP exposure for relevant bosses such as King Black Dragon. Do not claim existing UI warning coverage without inspection.
- Acceptance: Finish verified Wiki Recommended UI/gear/inventory/warnings/bank projection, Java 17 Gradle tests and focused RuneLite owner native evidence before starting real Best in Bank. Latest source candidate is not yet native-approved.

## 2. Bank inspection, snapshots and account safety

- Finished experience automatically scans **each time the bank is opened**. A manual **Scan Bank** action is only a temporary testing/development tool, superseding older roadmap wording suggesting permanent manual scanning.
- Single read-only account-scoped snapshot of **bank + inventory + currently equipped gear**. Persist safely across RuneLite restarts, with scan timestamp. Never force deposits; never move, withdraw or reorder items.
- A pickup away from the bank may wait for **next bank open** rather than hot-updating stock. Outside-storages with no evidence remain unknown.
- Failed/incomplete scan must retain prior valid snapshot but mark staleness/unknowns. Do not assert that an item is absent solely from stale or incomplete evidence.
- Account switches must correctly select per-account snapshots, settings and history, and reset live Sessions. Never show one character's data for another. If identity can't be verified reliably: suppress questionable recommendations and show **“Account data couldn't be verified. Please restart RuneLite.”** Restart is a failure fallback, not normal workflow.

## 3. Best in Bank (future phase, NOT implemented in this F06 candidate)

- One canonical Wiki dataset per boss/method/tier. Real Best in Bank maps **owned** items from the bank/inventory/equipment snapshot into a valid loadout slot-by-slot, using role-specific priorities and legal compatible alternatives. Mixed gear tiers are allowed.
- Keep selected combat style and boss method fixed. Quest, level, combat, ammo, spell/rune, offhand, two-handed, item variant and charged-state constraints override naive stat scoring.
- For unavailable choices, show specific missing items or **Not Recommended**; never fake account ownership. Missing essential ammo: **Not Ready**. Unknown weapon/ward charges: **Check Charges**; confirmed empty charges can yield Not Ready. Missing consumables: **Needs More Supplies**, with amounts.
- Food substitution must account for actual healing and effects (e.g. intelligently adjust shark counts when plentiful cooked karambwans are available); account for prayer potions and super restores, combo-eating, potion effects and boss restrictions. Show **both the original Wiki recommendation and the actual adapted recommendation**.
- Bank highlighting stays OFF by default and is not an F06 release prerequisite.

## 4. Boss observation / adaptive supplies

- Outfitter owns boss-related loot and consumption observations, including per-boss trip drops and supplies used, with sufficient context to improve later trip loadouts.
- Do **not** modify advice live in the middle of a session. Re-evaluate for future sessions only after a completed login/session, and only with enough trustworthy evidence. Otherwise use verified Wiki fallback.
- This separate private observation history must outlive rolling Sessions summary retention; deleting a Sessions summary must not discard adaptive evidence.

## 5. Pathfinder goals, prerequisites and autonomy

- Searchable goals (e.g. Bowfa, Vorkath, dragon defender) show factual quests, stats, gear and access prerequisites. Do not duplicate Quest Helper's quest steps or give unsolicited skill training walkthroughs.
- Missing data: show relevant recommendations and **Some data unavailable**, rather than hiding the goal or inventing certainty.
- **Skip** means move on for now; **Ignore** suppresses automatic future recommendation until manually restored from a recoverable Ignore list. A skipped 250-CG-kill Bowfa goal retains progress and can be proposed again after the new active goal is completed.
- If a searched requirement is on Ignore (e.g. Song of the Elves), show **Song of the Elves required (on your Ignore list)**, not an automatic un-ignore.
- Completion must be **confirmed by the player**, not auto-asserted from an observed item. After completion suggest next goals, don't auto-assign them absent hard prerequisites.
- Goal changes take effect immediately and are **independent of what activity the player is doing**. A user can have an active goal and still boss, skill, bank or roam for fun. No mid-trip interruption or forced focus.
- Factual guidance may note that one upgrade is incremental and another dramatically affects mechanics, with progression/RNG context. Do not police preferences or GP spending.

## 6. Outfitter <-> Pathfinder contextual shortcut

- Any **missing recommended gear item** can show a small **Set as Goal** link. Clicking opens Pathfinder focused on that item. **Viewing/clicking this link does not automatically assign the goal**. Player decides there.
- Pathfinder presents item acquisition requirements and whether current account seems eligible. Outfitter remains independent and doesn't become a quest guide.
- If goal was ignored, show **Ignored in Pathfinder**, allow manual restore only; do not resurrect it automatically.
- The link may be offered even for aspirational items beyond current stats; Pathfinder explains restrictions rather than hiding ambitions.

## 7. Sessions: revised live + rolling recent history

**This supersedes the earlier “current-login ONLY, no saved sessions” specification.**

- The prominent Sessions screen tracks **current RuneLite login only** with live XP gains, new levels, boss kills/KC gains, notable boss drops, verified boss kill-time PBs and significant in-game milestones. Do not log ordinary Pathfinder goal-change actions as milestones.
- On logout, close/save the completed session summary. New login always starts a new clean current session. Account switches close/reset the old live view safely.
- Allow quick look-back at the **most recent 10 completed session summaries** in the Sessions UI, in addition to the current live session. When session 11 completes, automatically discard the oldest summary. No pins, no lifetime aggregate in this UI, no large archive-management system.
- Preserve independent adaptive Outfitter boss-trip evidence separately from this 10-summary rotation.
- **Bandit engineering recommendation, not a separate approved feature gate:** checkpoint a long live session to recover from crashes without double-counting XP, KC or drops. Spoons should triage feasibility and ticket scope.
- PB labels require trustworthy recorded boss kill time, no fabrications from partial observations.

## 8. Existing UI and later ticket reminders

- Tooltip/hover item names, including charged glory and imbued berserker ring recognition, remain existing future tickets; distinguish item observation from bank ownership.
- Main sidebar is Home / Pathfinder / Outfitter / Sessions; bank shortcut uses approved raccoon chest artwork in final design (not permanent generic O artwork).
- Sessions current login live feed, Pathfinder scope, and Outfitter per-boss loot + supply accounting need distinct acceptance tests.
- All native launch tests already passed by the owner should be credited; ask only for **targeted changed-feature logs, screenshots and Gradle/JUnit evidence**, never repeated broad smoke tests.

## 9. Work order for Spoons and crew

1. Confirm this bundle's exact source identity against authoritative previous native-accepted Burrow source and latest project register. Recency alone is **not** proof of approved lineage.
2. Reconcile this owner's specification into **master status, roadmap, permanent IDs and acceptance criteria**. Flag which old requirements were superseded, especially automatic bank scanning and 10-session history.
3. Mark features as design-approved vs source-implemented vs automated verified vs native verified; no status inflation. Existing FINAL-06 Java source has offline evidence but no verified Java17 native release from this bundle.
4. Preserve existing known-good builds, original art and independent QA evidence. Iron Ledger unchanged.
5. Dispatch scoped coding/testing tickets: first FINAL-06 genuine Java 17 build and focused native testing, then remaining Wiki Recommended acceptance, then real Best in Bank and adaptive systems, then ancillary UI/tooltip refinements.

**Current candidate remains RELEASE HOLD. Do not merge or call production ready without proof.**
