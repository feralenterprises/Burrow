# BUR-0046 | Tongs independent combat style coverage audit

**Source:** `BUR-0039-JAVA17-INTELLIJ-VERIFY-READY-F06.zip`  
**SHA-256:** `82acd195e2a273e6a55760f05cfe64c8611e175128acbf5126a9fb561d8e9075` (verified directly from exact Library bytes).  
**Role:** Independent QA. **Release:** HOLD. **Output scope:** Research, matrix, focused *test-only* source patch, handoffs. NO UI / controller changes, canonical gear edits, generated catalog edits, or ticket register edits.

## Player-facing verdict

**The controls are not universally broken.** In the baseline, `BurrowPanel.mouseReleased()` dispatches clicks to `clickAt()` and, for selected combat-style rectangle, loops `model.methods()` to find a *registered* method with that style. When no such method exists, the function does nothing, with no click feedback. `BurrowPanel.getToolTipText()` returns `No verified setup for this method` regardless of why it is missing. `BurrowModel.chooseMethod` intentionally rejects unregistered choices.

**Coverage is severely narrow.** Exactly **15 bosses / 17 registered methods / 51 tier profiles**. Every registered method has Entry, Recommended, Optimal. **Fourteen bosses register one method and one combat-style label each.** Dagannoth Kings registers three methods, specifically *different kings* (Rex Magic / Prime Ranged / Supreme Melee). No boss has more than one independently registered style for the *same encounter*. Some single-method labels hide legitimate hybrid switches in inventory.

**Scurrius specifically:** registered only `Standard, mid-level melee with bone mace`. There are no Scurrius Ranged/Magic profiles. Ranged and Magic clicking cannot select those styles until 3-tier methods are researched and approved. Rat bone shortbow (50 Ranged) and bone staff (50 Magic) are established; player needs a Scurrius spine to make each, plus requirements/supplies. Entry Melee uses a rune scimitar despite the method title including bone mace: flag *label-versus-tier applicability* for separate review, not a gear fix authorized by BUR-0046.

## Matrix semantics

`PASS` = source registers a complete three-tier method for this style on that boss; **NOT** a claim of client execution, quality, efficiency, or account ownership.  
`MISSING` = credible mechanically feasible/relevant method is absent from source. **Not automatically approved for import**: full method, phase, gear, 28-slot inventory, requirements, labels and all 3 tier plans must be researched.  
`NOT_RECOMMENDED` = technically possible in some forms or phases but not a practical general solo-style loadout; do not casually enable.  
`NOT_SUPPORTED` = unsupported **as a complete standalone single-style fight** due to boss immunities; a switch may still be necessary as part of a hybrid method.  
These classifications are scoped to a *complete recommended boss-fight method*, not just whether a damage splat can land.

See `BUR-0046-METHOD-COVERAGE-MATRIX.csv` for **all 15 bosses**, 3 styles each, exact status, caveats and direct strategy-source URLs.

| Boss | Melee | Ranged | Magic | Key player-facing gate |
|---|---|---|---|---|
| Scurrius | PASS | MISSING | MISSING | Bone shortbow and staff are separate viable methods |
| Brutus | PASS | MISSING | MISSING | F2P safespot/Ranged and earth-spell Magic |
| Giant Mole | PASS | MISSING | MISSING | Ranged and earth-spell Magic both wiki-supported; spade/light |
| Sarachnis | PASS | NOT_RECOMMENDED | NOT_RECOMMENDED | Crush prioritized; high Ranged/Magic defence |
| Amoxliatl | PASS | NOT_RECOMMENDED | NOT_RECOMMENDED | Melee is needed for unstable ice; fire spell niche |
| King Black Dragon | MISSING | PASS | MISSING | Melee alternative; Magic niche needs dragon hunter wand and costly sustain |
| Vorkath | MISSING | PASS | NOT_RECOMMENDED | Melee lance/fang viable; Crumble Undead is utility |
| Phantom Muspah | NOT_RECOMMENDED | PASS | MISSING | Magic+Ranged hybrid, shield crossbow/sapphire bolts |
| Hueycoatl | PASS | NOT_RECOMMENDED | NOT_RECOMMENDED | Tail crush damage cap; Magic 60% earth weakness still inefficient |
| Grotesque Guardians | PASS | NOT_SUPPORTED | NOT_SUPPORTED | PASS denotes **melee+ranged hybrid**, not a pure melee weapon-only kill |
| Barrows | NOT_RECOMMENDED | NOT_RECOMMENDED | PASS | PASS denotes **Magic-primary hybrid** with Ahrim Ranged switch |
| Dagannoth Kings | PASS | PASS | PASS | Three king-specific methods, not style alternatives for one king |
| Zulrah | MISSING | MISSING | PASS | Ranged/mixed methods; halberd Melee newly feasible since May 2025 |
| Obor | PASS | MISSING | MISSING | Snare Magic and Ranged standard documented options |
| Bryophyta | PASS | MISSING | MISSING | Ranged and fire Magic excellent; growthlings require axe/secateurs |

## Phases, gear and supplies that must constrain future method research

- **Scurrius:** bone shortbow/bone staff are rat weapons with extra damage and minion-specific behavior, but not mandatory entry equipment; each demands a level-50 combat skill and spine acquisition for the bone variant. Protect from boss's changing attacks; account for minions and food/prayer supplies.
- **Giant Mole:** ranged and 50%-earth-weakness Magic are legitimate, including safespotting. Needs spade and light source unless permanent cave light unlocked. Burrow and long trips affect stamina and supplies; cannons conditional.
- **Hueycoatl:** each fight includes body/head/tail phases; tail has cap 4 per damage hit, raised to 9 when crush attack bonus is highest. Multi-hit crush tools and team-size realities determine strategy. A Magic-only *combat achievement* is possible with earth spells in groups, but +200 Magic defence and tail make this a poor general plan. Ranged defence is +350.
- **Grotesque Guardians:** Dawn can be hit with Ranged or a relevant halberd (Magic less effective); Dusk is immune to Ranged and Magic. Existing method is Melee-primary **with Eclipse atlatl switch in inventory**. Confirm granite hammer or rock hammer / Gargoyle smasher final blow and ammo. Do not label it a full-kill ranged-only style.
- **Amoxliatl:** Magic fire bonus is real, but unstable ice only breaks to melee. A non-melee boss-damage style would require a deliberate melee utility switch or special positioning; not a general standalone template.
- **Phantom Muspah:** recommended hybrid uses Magic vs melee form and Ranged vs ranged form, with a ranged sapphire-bolt or ZCB shield phase switch. Pure Melee is technically possible after defence reduction and stepback but weak as broad default. Do not alter reviewed Muspah gear as part of this audit.
- **Zulrah:** ranged/magic switches exploit phase-specific weaknesses. Halberd Melee became possible in the 7 May 2025 update, and a noxious halberd variant is documented; poison-cloud positioning and optional Ranged switch matter. Do **not** mark Melee immune using historical pre-May 2025 advice.
- **Vorkath / KBD:** dragonfire shields/potions, venom/poison, prayer strategy and anti-dragon equipment gate full plans. Vorkath still needs Crumble Undead as a utility spell, even in Melee/Ranged. KBD Wilderness travel has risk implications and specialist AFK Magic requires dragon hunter wand and Blood Barrage.
- **Barrows:** its Magic-primary registered plan already carries a Ranged weapon and ammunition to handle Ahrim. A new `Ranged` button should not simply switch to the already existing magic method or imply a full Ranged-only setup is recommended.
- **Dagannoth Kings:** selecting Melee/Ranged/Magic currently also selects Supreme/Prime/Rex. State the king before the style; each fight has different safe entry, targeting and prayer requirements.
- **Obor / Brutus / Bryophyta:** distinguish F2P loadout restrictions, low-level survivability and relevant spell weaknesses. Bryophyta growthlings render the boss invulnerable and require an axe or secateurs for cleanup, regardless of main damage style.

## Precise handoffs: no ticket ID invention

**Sporks: UI/controller, BUR-0040 (existing).** After identifying a true registered method, clicking that style should select it and show the proper boss/method/tier. An unavailable style must be visibly disabled *with accurate explanation*: `No reviewed [style] setup for [boss]` for missing data, `Not recommended for full fight` for poor styles, or `Requires mixed styles/phase switch` for Grotesque; never silently do nothing. Avoid presenting the three style chips as always available. Keep boss and tier selection and bank projection intact. For Dagannoth Kings, explicitly show that swapping styles swaps targeted king. Add focused genuine MouseEvent tests for every boss at each tier and review the reported native click failure. Do not fabricate methods. BUR-0046's offline 473 assertions show that listener dispatch works in headless Swing for registered methods, but cannot establish the owner's actual JAR behavior.

**Noodles: future canonical coverage research/data work (ask Spoons to map ticket IDs).** Priority 0: Scurrius Ranged/Magic; Giant Mole Ranged/Magic; Bryophyta Ranged/Magic. Priority 1: Brutus, Obor Ranged/Magic; Vorkath, KBD Melee; Muspah Ranged+Magic hybrid; Zulrah Ranged. Priority 2 / conditional: KBD specialist Magic, Zulrah halberd Melee, possible other niche methods only after encounter/gear verification. For each, document all three tiers, fully functional gear/inventory, mechanics, access and skill prerequisites, ammo/runes, antifire/anti-venom, and true switch slot accounting. Review existing Scurrius Entry weapon/method-label mismatch without unauthorized change. Do not modify reviewed Muspah corrections or the 51 original profiles silently. Regenerate catalog and validate with scripts ONLY after Spoons/owner authorizes a separately ticketed data expansion.

**Spoons:** map new method requests to existing tickets or register permanent IDs; reconcile against the **47 original IDs**, preserve project master and release HOLD. Separate UI fix BUR-0040 from data coverage expansion. Owner acceptance/real-client proof and a genuine Java17 build remain distinct future gates.

## Test results and limitations

- Baseline SHA-256 and ZIP extraction: PASS, exact 176 entries. Original canonical project not overwritten.
- Registered data: 15 bosses / 17 methods / 51 profiles. 3 tiers each, 11 gear positions and 28 inventory slots per profile, verified with `scripts/audit-bur0046-coverage.py`: PASS.
- `BUR0046CombatStyleCoverageTest.java`: **473 assertions PASS** across all bosses, tiers, style chips, real Swing `MouseEvent.MOUSE_RELEASED` routing in headless offline execution.
- Java compilation: local JDK **21.0.12.1** using `javac --release 17`. This is NOT a certified JDK17 Gradle test, JUnit run or RuneLite plugin runtime proof.
- Sources: OSRS Wiki current crawled pages and descriptions, not original experiment/observed DPS measurements; some web pages are search-index-extracted because direct fetch is restricted. Specialty and group strategies are **conditionally research-backed**, not validated owned-bank recommendations.
- Release: HOLD. Best in Bank: out of scope. No UI/gear/catalog/47 ticket edits in this patch. The audit does not claim to fix live click behavior.

## Source URLs (mechanics / recommended strategy, checked 2026-10-30)

1. https://oldschool.runescape.wiki/w/Scurrius/Strategies
2. https://oldschool.runescape.wiki/w/Rat_bone_weapons
3. https://oldschool.runescape.wiki/w/Brutus/Strategies
4. https://oldschool.runescape.wiki/w/Giant_Mole/Strategies
5. https://oldschool.runescape.wiki/w/Sarachnis/Strategies
6. https://oldschool.runescape.wiki/w/Amoxliatl/Strategies
7. https://oldschool.runescape.wiki/w/King_Black_Dragon/Strategies
8. https://oldschool.runescape.wiki/w/Vorkath/Strategies
9. https://oldschool.runescape.wiki/w/Phantom_Muspah/Strategies
10. https://oldschool.runescape.wiki/w/The_Hueycoatl/Strategies
11. https://oldschool.runescape.wiki/w/You%27re_a_wizard
12. https://oldschool.runescape.wiki/w/Grotesque_Guardians/Strategies
13. https://oldschool.runescape.wiki/w/Barrows/Strategies
14. https://oldschool.runescape.wiki/w/Dagannoth_Kings/Strategies
15. https://oldschool.runescape.wiki/w/Zulrah/Strategies
16. https://oldschool.runescape.wiki/w/Zulrah (7 May 2025 mechanics change)
17. https://oldschool.runescape.wiki/w/Obor
18. https://oldschool.runescape.wiki/w/Bryophyta
