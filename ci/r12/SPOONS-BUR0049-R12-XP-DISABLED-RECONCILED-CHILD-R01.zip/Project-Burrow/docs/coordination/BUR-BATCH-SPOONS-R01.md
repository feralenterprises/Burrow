# BUR-BATCH-SPOONS-R01 | Spoons handback

**Owner-facing result:** The KBD Wilderness warning and automatic item-name hover are now staged together in one preserved integrated candidate. The earlier combat-style control, Vorkath boot, Muspah gear, and bounded tooltip changes remain included. **No new combat styles were added.** No native RuneLite test requested.

## Source lineage and scoped L1 verdict

- Frozen source: `BUR-P1-INTEGRATED-HOLD-F06.zip` SHA256 `c9ba3a47be2fdd20c171955e13d0328b1c16b22bf295cef27ac6e020874ef570`.
- BUR-0035 KBD: SHA256 `0434549afec3e1181135159ff280e6d08e781d3c7c8632d7347b47459d9f22e7`. Prior independent Spoons L1 source review exists; we verified its frozen SHA and source payload.
- BUR-0019 hover: SHA256 `b049c05d1d9344650bad7f356d1cd2998b0f9ab9e244c103ad198290de108ca2`. It declares BUR-0035's exact `BurrowPanel.java` SHA as its frozen base. This condition passed; after KBD and hover overlays, the UI file matches the producer hash.
- Only original UI source (`BurrowPanel.java`) was updated by the two overlays, with four new focused Java test files total. All existing boss data, 51 profiles and permanent ticket IDs were preserved.
- **Scoped Spoons L1 status of BUR-0019: source/lineage PASS; broad test-suite acceptance remains conditional.** The inherited KBD `PreparationTooltipSmokeCheck` uses old static coordinates; the source baseline with KBD alone also fails it. This was disclosed by Sporks. BUR-0037 must repair coordinate-sensitive preparation display/testing without hiding regression failures.
- JDK21 `javac --release 17` checks are not genuine JDK17 Gradle. No new user-native RuneLite evidence for this combined candidate. Release HOLD.

## Prioritized handoffs

**Next exclusive UI lane:** Sporks BUR-0037 clipped preparation/switch notes. First reconcile current `BurrowPanel.java` SHA, fix actual scroll/layout readability, and update coordinate-sensitive tooltip test to follow KBD shift; preserve hovered item-name label and Wilderness warning. Submit one patch ZIP. Then BUR-0038 explicit method dropdown; BUR-0047 window restoration and broad UI acceptance stay queued.

**Parallel non-conflicting lane:** Noodles may research/patch missing verified boss combat styles under BUR-0034 only after data coverage signoff and without changing UI; or prepare BUR-0021 inventory recommendations. Do not modify the same canonical gear dataset in two chats. Reconcile Vorkath and Muspah outstanding quality findings in their already assigned tickets, not new duplicate IDs.

**Independent QA lane:** Tongs reviews data/method candidates and existing findings without altering source. Spoons handles register, review and one-time integration. No owner native tests until the 33-item batch gate.

**Actual 33-board scope:** BUR-0016..BUR-0048 inclusive. Visible owner ranks #1–#10 preserved; 11–33 ranks unknown, not fabricated. See CSV.
