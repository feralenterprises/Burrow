# 🦝 Spoons P1 integration | staged source only | Release HOLD

Frozen baseline: BUR-0039-JAVA17-INTELLIJ-VERIFY-READY-F06.zip, SHA256 82acd195e2a273e6a55760f05cfe64c8611e175128acbf5126a9fb561d8e9075.

Sporks BUR-0040 UI: available real method style switches; unavailable styles show NO SETUP explanation. No new profiles. Only BurrowPanel.java plus focused UI tests.
Noodles BUR-0048 gear: Vorkath Ranged crossbow Recommended slot 9 Dragon boots (11840) -> Ancient d'hide boots (19921), with source conditions. All Muspah profiles, other gear and inventories unchanged; generated Java/TSV and pinned checksum refreshed.
Tongs BUR-0046 audit: one 15-boss method coverage matrix, narrative, read-only checker and independent test source, no production change. Scurrius Ranged/Magic and Giant Mole alternatives are valid OSRS strategies but no approved new three-tier data exists yet. Keep no-setup state until research-approved expansion.

Spoons-owned central ticket register retains all 47 original IDs and assigns BUR-0048 for Vorkath, total 48 tickets, next unused BUR-0049. BUR-0039 native Muspah display and five L2 findings remain pending; BUR-0036 tooltip native check separate; BUR-0038 method dropdown and BUR-0034 method expansion not closed.

Static merge was generated only after exact-patch manifest hashes and source baselines, no overlap, 51-profile invariant, the one-profile boot substitution, dataset verifier and byte-for-byte regeneration. Actual Java17 native build, live RuneLite clicks and independent post-integration L2 still pending. NEVER promote automatically; Release HOLD.

Next: run **one** genuine JDK17 Gradle clean test jar on isolated integrated candidate. Request only owner RuneLite evidence for Dagannoth Kings valid style buttons; one Scurrius missing style NO SETUP response; Vorkath Ranged crossbow Recommended Ancient d'hide boots. Keep earlier broad smoke tests credited and don't repeat them. Audit other boss methods in a future separate authorized research/data ticket.
