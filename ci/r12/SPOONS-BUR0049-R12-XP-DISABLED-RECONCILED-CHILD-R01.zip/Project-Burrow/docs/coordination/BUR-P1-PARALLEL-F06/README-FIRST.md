# Project Burrow | Spoons P1 parallel repair coordination | 2026-10-30

**RELEASE HOLD. This is an actual, non-production source-tree patch**, consisting of the Spoons-owned ticket register update and a runnable isolated-lane merge verifier. It is **not** a combined UI/gear fix, a replacement canonical source, or a claim of new Java17/native QA.

## Frozen common source
- Exact archive: `BUR-0039-JAVA17-INTELLIJ-VERIFY-READY-F06.zip`
- Verified SHA-256: `82acd195e2a273e6a55760f05cfe64c8611e175128acbf5126a9fb561d8e9075`
- Source contents: 47 existing permanent BUR ticket IDs, 15 bosses, 17 methods, 51 profile keys; 11 equipment + 28 inventory positions per loadout.
- Earlier Windows **JDK 17 build gate PASS** for this exact candidate only, as documented in `BUR-0039-SPOONS-JAVA17-BUILD-PASS-RECEIPT.zip` (27 JUnit tests, 0 failures in host collector evidence). The JAR bytes were not attached for separate hash confirmation; native Muspah display is still pending.

## Ticket mapping and independence

| Lane | Assigned ticket | Allowed | Not allowed | Handback state at this coordination checkpoint |
| --- | --- | --- | --- | --- |
| **Sporks** | **BUR-0040** | Style click event/feedback, UI/controller and focused UI tests | Canonical gear JSON, generated catalogs, ticket register | New source patch pending |
| **Noodles** | **BUR-0048** (new Spoons-assigned ID) | Vorkath exact tier/method/boot research and reviewed data correction + coherent generator pins, focused tests | UI edits; Muspah correction; any other boss data; unapproved method expansion; ticket register | New source patch pending |
| **Tongs** | **BUR-0046** | Independent mechanics / method coverage matrix for all 15 bosses and 17 existing methods, phases and requirements | Any production code, dataset, or ticket-register modifications | New base-pinned read-only audit pending; older research found and retained as reference |
| **Spoons** | Coordination only | Register ownership, L1 validation, controlled integration | Inventing native PASS, merging overlapping/unreviewed changes, changing Release HOLD | This patch delivered |

`BUR-0039` stays a distinct Muspah issue; its previous JDK17 build gate PASS is not acceptance of its five unresolved quality concerns. `BUR-0036` is a separate pending native tooltip acceptance gate. `BUR-0038` method dropdown dependency remains OPEN; BUR-0040 is a narrowly owner-directed UI dispatch, **not** a claim BUR-0038 passed. `BUR-0034` method expansion remains separately gated and **not** part of this patch.

## Already inspected: why styles can look stuck

In `BurrowPanel.clickAt`, style clicks iterate only `model.methods()` and call `model.chooseMethod` if `TieredOutfitterCatalog.style` matches. With no registered method for the selected style, the loop ends without changing state or reporting anything. Baseline method catalog includes three style-specific Dagannoth Kings entries but only one method each for the other 14 bosses. **A better click handler is not a substitute for new evidence-based Scurrius Ranged/Magic loadouts.** BUR-0040 must make valid selections work and unavailable selections explain why.

## Controlled merge order (after all three new handbacks are available)

1. Pin each handback source identity against the exact SHA above. Reject unrelated baselines, silently retitled source trees, duplicated paths, and out-of-lane changes.
2. Apply this Spoons-owned ticket update to a **temporary copy only**. Existing 47 IDs are preserved and Vorkath is BUR-0048; next unused ID is BUR-0049. Never paste a contributor's embedded `BURROW-TICKETS.json` over the register.
3. Apply approved **Sporks UI** source/testing changes; then approved **Noodles Vorkath gear** source/testing changes; keep **Tongs read-only research documents** as evidence. Reject file overlap and all non-Vorkath profile mutations. Do not automatically introduce new methods.
4. If gear JSON changes, require exact generator + verifier SHA-pin synchronization, exact generated Java + TSV outputs and unchanged 51 profile identities. Script fails closed on unexpected drift.
5. Run **one genuine JDK 17** clean test + JAR build on the integrated candidate. Record JDK/compiler/Gradle/JUnit and artifact hash. Java 21 results **do not satisfy** the gate.
6. Request only targeted native RuneLite evidence: (a) functioning DK supported style switch and an unavailable-style explanation such as Scurrius Ranged/Magic until data exists; (b) Vorkath exact method/tier corrected boot choice if a data change is justified. Keep BUR-0039 Muspah Entry/Recommended and BUR-0036 tooltip evidence as separate acceptance gates; no broad previous smoke-test replay.

The included verifier can inspect available lane ZIPs and create an **isolated HOLD output ZIP** only when all three are supplied. It never overwrites the input ZIP or modifies a working tree.

```sh
python Project-Burrow/scripts/verify-parallel-f06.py \
  --base BUR-0039-JAVA17-INTELLIJ-VERIFY-READY-F06.zip \
  --spoons-patch BUR-P1-SPOONS-COORDINATION-PATCH-F06.zip \
  --sporks BUR-0040-SPORKS-PATCH.zip \
  --noodles BUR-0048-NOODLES-PATCH.zip \
  --tongs BUR-0046-TONGS-AUDIT.zip \
  --output BUR-P1-INTEGRATED-HOLD-F06.zip \
  --report BUR-P1-INTEGRATION-PREFLIGHT.json
```

Names for *future* lane handback ZIPs above are illustrative, not files claimed to exist. Sources may be supplied by explicit paths under their actual filenames. Do **not** use `--output` without all three patches.

**Next-up dispatch:** Sporks BUR-0040, Noodles BUR-0048, Tongs BUR-0046 concurrently. Once actual handbacks exist, Spoons L1 inspects all three and initiates one integrated build. Release stays HOLD.
