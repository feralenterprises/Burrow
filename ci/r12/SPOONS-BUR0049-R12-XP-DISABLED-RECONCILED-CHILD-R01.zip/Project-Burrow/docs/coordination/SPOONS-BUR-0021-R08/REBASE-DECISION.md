# Spoons | BUR-0021 | Source integration decision (R08)

**Disposition: STAGE reviewed source resource, BLOCK canonical FINAL-06 rebase. Release HOLD.**

Tongs approved five *conditional research candidate* changes, not unconditional player-visible replacements. There is no production-wired, trusted, equipment-aware supply selector. A direct source dataset substitution would remove access tools or reduce dragonfire protection even when the relevant equipment guard is absent. It would also conflict with SHA-pinned FINAL06 source generation and the Java TSV fixture.

This R08 candidate is an exact child of the independently reviewed R06 UI + bank R02 combined source. Three **added-only** files are present: the Noodles R02 reviewed supply resource, the R08 JSON safety/guard contract, and this decision file, plus a separate offline regression script and dispatch. There are **no edits** to the 51 canonical profiles, generated Java, item metadata, equipment, tickets, or original assets. The new resource is NOT loaded by the plugin; it is stored as an audited proposal.

**Conditional alternatives:**
- Sarachnis Entry, Recommended, Optimal: drop exactly one Knife only while Wilderness sword 1 remains in packed inventory, or equipped Aranea boots remain at the boot slot respectively. Restore a knife or a verified equivalent if those constraints are not met.
- KBD Entry and Vorkath Entry: provide regular antifire(4) as an **optional** cheaper/accessible alternative ONLY with an anti-dragon shield equipped. Keep extended antifire(4) as the current conservative default. The regular dose lasts 6 minutes, not 12. KBD can poison and its special attacks still matter; Vorkath retains unblockable fireball, venom and other dangerous mechanics. Preserve existing antidotes/antipoisons.
- Phantom Muspah Optimal: retain 20 Nature runes outside the full four-type rune pouch for the stated 10 Ward of Arceuus casts. No change.

**Conditions before a real generator/catalog rebase:** a trusted RuneLite equipment/container observation and provenance fence; fail-closed variant-selection with gear substitution safety; explicit owner choice on making regular antifire a default versus optional alternative; deterministic regenerated Java and TSV with updated manifest/validator pins; Tongs independent integrated L2; then genuine Java 17 Gradle and targeted native proof. The original FINAL06 source stays protected until that decision.

**Not completed:** live bank scan, Best in Bank, highlighting, persistence, measured food/prayer budgets, Java 17 Gradle or native acceptance.
