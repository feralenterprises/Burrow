# Spoons: Post Dual-L2 R06 UI Child R01

**Result:** Both Tongs reviews are PASS **in isolated/offline scope**. This archive is a separate child of exact frozen R06 with **UI patch only**; no bank-core or supply patch included, no canonical write, no GitHub, no native or genuine JDK17 PASS. Release HOLD.

## What changed
- `BurrowPanel.java`: Home and Pathfinder visual refinements from the exact independently reviewed Sporks overlay.
- `FeralModernHomePathfinderUiTest.java`: one new offline test.
- Two nonproduction coordinator documents under this folder.
- Protected existing R06 source and resources otherwise byte-identical.

## Spoons L1 check
- Full R06 source SHA-256 exact `c14706d4914b8e24ae1a692b5e6f6108bfe42e2861aff6ed361d4c071561136f`.
- UI source preimage/after image hashes and independent Tongs L2 source-scope verified.
- `javac --release 17` (actual JDK21) compiled offline main + tests successfully.
- **26/26** runnable standalone offline entrypoints in this coordinator replay passed.
- FINAL06 catalog PASS at 15 bosses, 17 methods, 51 loadouts.
- A new offscreen preview attempt stalled; do not claim fresh render. Tongs' independent 225px pixel comparison remains available in the signed receipt ZIP.

## Incoming bank L2
Tongs PASS for isolated cache behavior only; explicit P1 hardening of physical inventory/equipment slot bounds and P2 public Snapshot construction inconsistency. Source attestation remains caller controlled and must be authenticated by a future RuneLite host bridge. **Do not merge bank patch here** or describe bank-owned state as player live stock. Dispatch Noodles narrow hardening and return to Tongs.

## Supply L2
Five conditionally approved R02 supply changes are not in this child. Spoons L1 conditional review and generator/catalog synchronized rebase is next, separately.

## Correct next-up
1. Noodles bank-slot/Snapshot hardening on exact R06 bank overlay, then Tongs targeted L2.
2. Spoons separate guarded BUR-0021 resource/data rebase; Tongs L2 after source regeneration.
3. Independent later integrated candidate genuine JDK17 Gradle + targeted native once host wiring exists.

No player PC required tonight; 48 permanent IDs intact; release HOLD.
