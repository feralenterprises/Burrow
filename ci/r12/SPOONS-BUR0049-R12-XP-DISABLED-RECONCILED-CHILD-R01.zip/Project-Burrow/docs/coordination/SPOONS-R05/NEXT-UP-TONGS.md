# NEXT UP: Tongs independent L2 (R05)

1. Recover `SPOONS-R05-INTEGRATED-SOURCE-CANDIDATE.zip`, verify accompanying hash and frozen R03/R04 parent hashes.
2. Replay `scripts/verify-final06.py`, independent `javac --release 17` source compilation and all 19 offline test entry points. Check BUR-0037 switch formatter handling of malformed/raw JSON and 225px scroll; verify original Home/Pathfinder/Outfitter/Sessions, raccoon art and Bank O button remain intact in source.
3. Check BUR-0022 preserved all 48 other profiles; no hidden new method IDs/ownership assertions. Validate no main source file was changed outside the exact listed 16 paths.
4. Independently review new helpers for missing account scope, replays/epochs, numeric edge cases and false-certainty handling. Report PASS/FAIL per component; don't claim native or Java17 Gradle success from bytecode checks.
5. Return one L2 receipt or bounded blocker, with explicit next-up Spoons. **No canonical GitHub, ticket, bank, or release updates.**

Spoons next action after L2: targeted Windows Java17 clean test/JAR evidence for R05 and necessary owner-native changed-feature evidence. BUR-0021 remains data L2 before loadout changes; BUR-0023 observer blocked on variants/identity.
