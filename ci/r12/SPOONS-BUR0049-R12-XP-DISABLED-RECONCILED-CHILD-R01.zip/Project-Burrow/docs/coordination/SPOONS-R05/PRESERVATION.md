## Scope and preservation

R05 copies original R04 and changes only the 4 additive-core lanes, BUR-0037 source UI patch, and Spoons ticket/master/roadmap records. Every original source file byte-identical to R04 except `BurrowPanel.java` and `PreparationNotesReadabilityTest.java`, both matched exact frozen R03+R04 preimage SHA. Data source and generated catalogs untouched relative to R04. Do not treat this isolated ZIP as a replacement for the owner's canonical project or GitHub.
