# Spoons R05 independently replayed QA

- Frozen R03 SHA256 matched expected; R04 parent archive integrity checked.
- Changed BurrowPanel and PreparationNotesReadabilityTest preimage SHA256 matched R03 and R04 exactly; no three-way conflict.
- R05 main source compilation: 25 dependency-free main sources; JDK 21.0.12.1 `javac --release 17`, exit 0. Classfile major 61, Java 17 bytecode.
- R05 standalone test compilation: 19 existing/new Java test classes, exit 0 with `--release 17`.
- Offline test execution: 18/19 returned exit 0 on first invocation; the one preview emitter was initially called without its required output PNG argument. It was rerun correctly with its PNG output argument and returned exit 0. Thus 19/19 tests pass when correctly invoked. Full exact output recorded in `offline-tests.log` and `live-preview.log`.
- `scripts/verify-final06.py` exit 0: 15 bosses, 17 methods, 51 profiles, 561 equipment and 1428 inventory positions (R04 content unchanged).
- These are JDK 21 runtime results with Java 17 target bytecode, NOT a genuine Java 17 runtime, Gradle/host/JUnit, RuneLite-native, owner gameplay, or independent Tongs L2 PASS.
- No claims about live bank ownership, live boss KC, boss drops, session history, or final boss performance.
- Release HOLD.
