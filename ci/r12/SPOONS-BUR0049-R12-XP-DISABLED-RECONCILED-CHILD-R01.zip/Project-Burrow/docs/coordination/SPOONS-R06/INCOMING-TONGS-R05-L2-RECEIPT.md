# TONGS | Project Burrow | R05 independent L2 receipt

**Release: HOLD. Overall R05 L2 disposition: FAIL / targeted repair required (BUR-0025).**
**Review scope:** Isolated `SPOONS-R05-INTEGRATED-SOURCE-CANDIDATE.zip` and frozen ancestors. No repository, player-data, or canonical ticket writes. Java 21.0.12.1 available; actual JDK 17 and RuneLite host not available in this execution.

## Results-first handback

R05's 16 declared source/test path changes match its manifest and the inherited boss dataset is intact. Independently compiled 25 dependency-free main sources and 19 standalone Java test sources with `javac --release 17`, independently ran **19/19 entry points PASS**, and reran `scripts/verify-final06.py` PASS. The 225px switch UI scrolled through its footer in a headless Swing rendering, and malformed structured text was surfaced as a warning rather than silently trusted.

**One independent L2 defect found:** BUR-0025 (`BossKcDeltaTracker.observe`) returns `WRONG_IDENTITY, delta=0, sessionTotal=5` for a rejected foreign-account Scurrius observation after account A recorded 5 session KC. Stale-epoch observations behave similarly. The count isn't changed, but the rejected `Outcome` exposes active account A's session count at the wrong account/epoch boundary. The isolated reproducer and exact output are in `KcSecurityProbe.java` and `kc-rejected-event-probe.log`. Do not wire this Outcome into a live UI/event stream until rejected observations suppress cross-context totals or otherwise guarantee the caller cannot see them. Add regression assertions for `WRONG_IDENTITY`, `WRONG_EPOCH`, and other rejected cases after a nonzero accepted total. **BUR-0025 L2 FAIL** pending Sporks/Noodles focused fix and independent recheck. This is an account-boundary API defect, not demonstrated external exfiltration.

**Coordinator note:** BUR-0031 owner correction in the new R05 board and roadmap says **current login only, no rolling ten history**, but historical `BURROW-TICKETS.json` entries still retain a stale title and acceptance criteria mentioning ten summaries. Spoons should harmonize the authoritative ticket record, preserving historical snapshots. No source feature related to 10 summaries was added in R05.

## Per-component disposition

| Scope | L2 disposition | Basis / limitation |
|---|---|---|
| Archive integrity / R03→R04→R05 ancestry | PASS | SHA-256 checks and ZIP CRC PASS; parent R04 and frozen R03 hashes exact |
| Declared source change paths | PASS | Exactly 14 added plus 2 changed source/test paths; no undeclared src diff, no deletions; both preimages matched R03/R04 |
| BUR-0022 Scurrius | PASS, offline only | Other 48 profile dicts exactly unchanged from R03; R04/R05 dataset byte-identical; Entry removes bone-mace/spine pre-first-kill gate, all 3 method labels shortened |
| Data catalog | PASS | 15 bosses, 17 methods, 51 plans, 561 gear + 1,428 inventory positions, exact source hash |
| BUR-0037 format & 225px layout | PASS, offline only | Malformed JSON warns, unknown fields retained, formatted full notes, narrow layout/scroll screenshot, tooltip/hitbox tests |
| BUR-0020 quantity helper | PASS, isolated core | Reconciles exact identities; foreign/stale sources ignored, unknown not equated to missing; no host scan or real account observations |
| BUR-0025 KC core | **FAIL, isolated API boundary** | Wrong-identity/epoch rejected Outcomes reveal current accepted total (repro attached); counts themselves not mutated |
| BUR-0028 odds helper | PASS, isolated core | Replayed 899 assertions; requires separately verified odds and eligible kills, no live data |
| BUR-0032 Pathfinder goal state | PASS, isolated core | 58 assertions; account key checks and player choice guard; not wired to RuneLite UI or persistent store |
| Home / Pathfinder / Outfitter / Sessions source | PRESERVED | No unlisted source edits; offline Home/Swing tests PASS; not native behavior acceptance |
| Raccoon artwork / O-bank source | PRESERVED | Resource assets and RuneLite host/OutfitterBank sources unchanged; no live click or bank lifecycle run |
| Full Gradle/JUnit under genuine JDK17 | NOT RUN | Tool environment contains JDK21 only; `--release 17` bytecode ≠ JDK17 runtime or host build |
| Owner native RuneLite QA | NOT RUN | Host/client unavailable here; retain prior targeted native evidence, not a new pass |
| BUR-0031 ticket metadata consistency | FAIL, coordinator cleanup | R05 board correction conflicts with legacy title/acceptance entries in canonical ticket JSON |

## Independent execution facts

- R03 SHA-256: `1d909537570931ffa12f39718a3dc7118712cf57103ab2a5bb8864004cafd44c`
- R04 SHA-256: `b2e1f925a2c631ad55bcce3fc5da12dacb1b671419a6967691ca3a3392a2be8c`
- R05 SHA-256: `63f0764ece22f9d21145c18746e170a441c1ce314b6dabb88f25649eb875b4e3`
- `python scripts/verify-final06.py`: exit 0; source hash `165f0781ab4e0e738235833e51dee04c21f30825cc8b3ab421c051e48e6dbe98`
- Compilation: JDK21.0.12.1 `javac --release 17`, exit 0; classfile major 61. These were 25 dependency-free main sources and 19 standalone test entry points, not the full RuneLite-dependent application compile.
- Independent 19/19 offline test entry point invocation exit 0. One preview emitter received its required image-output argument. Tests were run with headless AWT and classpath for main/test resources. The 19 entry points do not constitute a full Gradle/JUnit suite.
- L2 safety: no changes to Iron Ledger, GitHub, original frozen archives, or live player data; release HOLD.

## Spoons: next-up dispatch

**Next-up: Spoons coordinator → targeted Noodles/Sporks BUR-0025 fix, then Tongs L2 recheck.** On rejected foreign-account or stale-epoch observations, return no sensitive active-session totals (for example, zero or a separate no-total result) while preserving accepted event totals. Add a negative regression test establishing a nonzero current session, injecting another account/epoch, and requiring no count exposure or mutation. Spoons also reconciles BUR-0031 canonical ticket text against owner-locked current-login-only requirement. After acceptance, run genuine JDK17 `clean test jar` and targeted owner-native changed-feature verification. Do not count R05 as L2 accepted or released before these gates.
