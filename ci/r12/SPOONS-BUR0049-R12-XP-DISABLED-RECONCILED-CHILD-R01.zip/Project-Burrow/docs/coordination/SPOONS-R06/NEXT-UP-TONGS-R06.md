# Tongs | Targeted independent L2 of SPOONS-R06

Start from `SPOONS-R06-L2-REPAIR-CANDIDATE.zip` (verify its SHA in handback). Compare to frozen `SPOONS-R05-INTEGRATED-SOURCE-CANDIDATE.zip` SHA-256 `63f0764ece22f9d21145c18746e170a441c1ce314b6dabb88f25649eb875b4e3`. Read `docs/coordination/SPOONS-R06/R06-SOURCE-SCOPE.json`.

1. Independently reproduce Tongs' former `KcSecurityProbe`: foreign-account and stale-epoch observations now **must** return correct rejection status, `delta=0`, `sessionTotal=0` after legitimate +5.
2. Replay negative cases for foreign account, wrong login ID/generation, wrong epoch ID/generation, old sequence, prior world on hop, post-logout. All must have zero exposed totals while legitimate +5/+1, baseline, hop persistence and logout reset still work. Explicitly inspect any other boundary leaks.
3. Run targeted and unrelated offline regression tests plus `scripts/verify-final06.py`; verify 15 bosses, 17 methods, 51 plans unchanged; 3 only src/test paths modified, zero added/deleted. Do not infer full Gradle/RuneLite success from Java 17-targeted bytecode.
4. Confirm `BURROW-TICKETS.json` authoritative BUR-0031 and active priority queue now specify CURRENT LOGIN ONLY and no 10 history, prior requirements retained in audit metadata. No Sessions feature implemented. All 48 existing tickets preserved, BUR-0049 unused.
5. Return an independent PASS/FAIL receipt with exact tests, regressions, blockers, next-up Spoons. Do not modify canonical project, ticket IDs, repo, or release. Release HOLD.
