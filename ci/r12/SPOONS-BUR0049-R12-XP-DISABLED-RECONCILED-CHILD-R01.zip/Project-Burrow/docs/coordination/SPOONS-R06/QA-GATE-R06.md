# R06 source-level QA gate

- Parent R05 SHA256: `63f0764ece22f9d21145c18746e170a441c1ce314b6dabb88f25649eb875b4e3` (verified).
- Exactly 3 modified source/test paths; no source additions or deletions; all other src files identical to R05, including 15/17/51 gear data and artwork.
- JDK **21.0.12.1** `javac --release 17`, compiling 25 standalone main and 19 standalone test sources, class major 61; **not** a real JDK 17 host build.
- **19/19** standalone test entry points PASS. BUR-0025 replay includes new nonzero-total privacy regression and fixture updates.
- Original Tongs `KcSecurityProbe`: formerly `WRONG_IDENTITY` / `WRONG_EPOCH` showed `sessionTotal=5`; both now show `sessionTotal=0`, while accepted gain still shows 5.
- `scripts/verify-final06.py`: PASS unchanged, original dataset 15 bosses, 17 methods, 51 profiles; no gear/supply/catalog change.
- BUR-0031 current metadata and active priority queue harmonized. Prior title/mission/acceptance preserved under historical audit.
- Independent Tongs L2: PENDING; genuine Java17 Gradle/JUnit: NOT RUN; actual RuneLite owner-native verification: NOT RUN.
- Release HOLD.
