# SPOONS R06 | Repair handback | RELEASE HOLD

Fixed the boss KC rejection leak: foreign-account, stale-epoch and replayed events no longer expose the active player's count, while real gains, world hops and logout behavior remain intact. Replayed Tongs' original bug reproducer and ran all 19 standalone offline test entry points PASS. Only 3 source/test paths changed; all 15 bosses, 17 methods, 51 equipment profiles and UI assets are unchanged.

Corrected BUR-0031 authoritative ticket and active queue to CURRENT LOGIN ONLY, clearing on logout, with historic ten-summary text retained for audit. No new Sessions functionality is implemented.

**NEXT UP: Tongs independent R06 L2 recheck; then Spoons JDK17 Gradle/native evidence collection and release-gate decision. No GitHub changes, no owner's canonical overwrite.**
