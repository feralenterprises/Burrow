# SPOONS | R11 RESEARCH ACCEPTANCE & RECONCILIATION

**Decision: L1 ACCEPT (RESEARCH REQUIREMENTS ONLY).** This is owner-authorized integration of independent research into project coordination records, **not** an endorsement of a Best in Bank implementation or a release claim.

## Audit findings

- R07/R08/R09/R10/R11 archives pass their ZIP CRC checks and all declared internal file hashes successfully resolve and match.
- Frozen R08 source archive has the declared SHA-256; the latest Spoons XP R06 child is used as the project-record parent, not as a newly native-accepted release.
- Older R08/R09 isolated probes expose potential double-counting and bank-observer lifecycle failures with synthetic events, not proven production RuneLite failures. Preserve the test conditions when citing them.
- Source-level BankPlugin observation is stronger than widget/search assumptions. A blank search field is not automatically required, and no widget/script/GameTick on its own proves the authoritative complete bank. `BANK` null must be UNKNOWN rather than verified-empty.
- Item IDs, variant normalization, charge state, ammunition compatibility, potion storage, skills and switches are independent predicates; a good base-item ID alone is insufficient to claim usable ownership.
- TD hybrid loadout proposal is a candidate ranking design, not an actual bank-conditioned recommendation; combat phase formulas and 2026 changes require source/version checks before numerical claims.
- No extra game boss registered, no existing method or loadout changed, no new permanent ticket created. Existing BUR-0023/BUR-0042/BUR-0030/BUR-0021/BUR-0033/BUR-0034/BUR-0046/BUR-0020 link the requirements.

## Caveats and limitations

1. User's current bank inventory and equipment are unavailable to this intake. No claim is made that a Scorching bow or charged alternatives are in the bank.
2. 180 cases in R07 were proposed; R08/R09 offline tests are synthetic, not real client integration.
3. R11 has no Java 17 native build or player test. The pinned 1.13.4 API must be checked in an eventual implementation, separate from GitHub master source viewed for research.
4. The latest Spoons XP R06 child is not necessarily the canonical accepted source. This is a records-only derivative handoff; do not overwrite live branch or working source without reconciliation.
5. Parent `BURROW-TICKETS.json` retains `next_unused_id: BUR-0049` although BUR-0049 is now used by an ongoing XP lane. The research handoff preserves this older field rather than manufacturing a new ID. Spoons ticket reconciliation must resolve it against current project authority before any new ticket allocation.

## Integration boundaries

- Accepted: audit/decision records, evidence hashes, requirements, ticket references and future acceptance criteria.
- Rejected as premature: actual bank completeness proof; gear optimizer implementation; TD method/catalog addition; native PASS; general Best in Bank activation.
- No new owner Windows test request and no disruption of current XP/Sessions milestones.

## Future proof requirements (not owner tasks today)

1. First native bank-open capture: explicitly distinguish unavailable/loading and verified observed count; no false empty.
2. Bank movement: no phantom duplication after withdraw/deposit/equip; observation validity clearly updates.
3. Account A→B→A, logout/hop: no leakage or stale-scope reuse.
4. Placeholder/filler/variant/ammo/charges: never recommend unowned or unusable equipment.
5. TD pilot: complete two-style gear, 28-slot swap space and source-grounded attack mechanics, with uncertainty/fallback explanation.
6. Preserved general Outfitter behaviors (existing 15 bosses / 17 methods / 51 loadouts), release HOLD until independent tests.

## Source links

- RuneLite Bank plugin: https://github.com/runelite/runelite/blob/master/runelite-client/src/main/java/net/runelite/client/plugins/bank/BankPlugin.java
- RuneLite GameTick event: https://github.com/runelite/runelite/blob/master/runelite-api/src/main/java/net/runelite/api/events/GameTick.java
- RuneLite ItemContainerChanged: https://github.com/runelite/runelite/blob/master/runelite-api/src/main/java/net/runelite/api/events/ItemContainerChanged.java
- OSRS Wiki TD: https://oldschool.runescape.wiki/w/Tormented_demon
- OSRS Wiki TD Strategies: https://oldschool.runescape.wiki/w/Tormented_Demon/Strategies

See `SPOONS-R11-RESEARCH-INTAKE-RECEIPT.json` for exact SHA-256 checks, parent chain and record hashes.
