# BUR-OUTFITTER-QUALITY-04 — all 51 loadouts audited

Release **HOLD**. Q07 is a TrashPanda Tracker curated recommendation set. The official OSRS Wiki supports combat mechanics and ranked item choices; it does not prescribe the exact Q07 28-cell budgets. R04 and R06 remain immutable comparison sources. Community leads for Obor/Bryophyta stay distinct.

**Inventory budget:** one to several kills, not a guaranteed kill count. The table shows occupied cells before and after; every plan retains exactly 28 positions and explicit empty cells. Items normally have quantity 1 per cell; bolts and runes are identified as stacks in Q07. The complete 11/28 slot data and item IDs are in JSON.

| Boss/method | Tier | Weapon before → after | Gear changes | Inventory cells before → after | Official strategy/mechanics |
|---|---|---|---:|---:|---|
| Scurrius | Entry | Rune scimitar → Rune scimitar | 3 | 25 → 16 | [Wiki](https://oldschool.runescape.wiki/w/Scurrius/Strategies) |
| Scurrius | Recommended | Bone mace → Bone mace | 4 | 28 → 13 | [Wiki](https://oldschool.runescape.wiki/w/Scurrius/Strategies) |
| Scurrius | Optimal | Bone mace → Bone mace | 6 | 26 → 11 | [Wiki](https://oldschool.runescape.wiki/w/Scurrius/Strategies) |
| Brutus | Entry | Barronite mace → Adamant scimitar | 5 | 25 → 12 | [Wiki](https://oldschool.runescape.wiki/w/Brutus/Strategies) |
| Brutus | Recommended | Rune scimitar → Rune scimitar | 3 | 22 → 10 | [Wiki](https://oldschool.runescape.wiki/w/Brutus/Strategies) |
| Brutus | Optimal | Rune scimitar → Rune scimitar | 3 | 24 → 8 | [Wiki](https://oldschool.runescape.wiki/w/Brutus/Strategies) |
| Giant Mole | Entry | Dragon sword → Dragon dagger | 4 | 25 → 19 | [Wiki](https://oldschool.runescape.wiki/w/Giant_Mole/Strategies) |
| Giant Mole | Recommended | Abyssal dagger → Zombie axe | 4 | 21 → 16 | [Wiki](https://oldschool.runescape.wiki/w/Giant_Mole/Strategies) |
| Giant Mole | Optimal | Osmumten's fang → Osmumten's fang | 9 | 27 → 14 | [Wiki](https://oldschool.runescape.wiki/w/Giant_Mole/Strategies) |
| Sarachnis | Entry | Dragon mace → Dragon mace | 2 | 28 → 18 | [Wiki](https://oldschool.runescape.wiki/w/Sarachnis/Strategies) |
| Sarachnis | Recommended | Zamorakian hasta → Sarachnis cudgel | 4 | 28 → 15 | [Wiki](https://oldschool.runescape.wiki/w/Sarachnis/Strategies) |
| Sarachnis | Optimal | Scythe of Vitur → Scythe of Vitur | 7 | 27 → 14 | [Wiki](https://oldschool.runescape.wiki/w/Sarachnis/Strategies) |
| Amoxliatl | Entry | Dual macuahuitl → Dragon mace | 10 | 26 → 14 | [Wiki](https://oldschool.runescape.wiki/w/Amoxliatl/Strategies) |
| Amoxliatl | Recommended | Inquisitor's mace → Dual macuahuitl | 10 | 23 → 12 | [Wiki](https://oldschool.runescape.wiki/w/Amoxliatl/Strategies) |
| Amoxliatl | Optimal | Inquisitor's mace → Inquisitor's mace | 0 | 27 → 11 | [Wiki](https://oldschool.runescape.wiki/w/Amoxliatl/Strategies) |
| King Black Dragon | Entry | Rune crossbow → Rune crossbow | 2 | 28 → 21 | [Wiki](https://oldschool.runescape.wiki/w/King_Black_Dragon/Strategies) |
| King Black Dragon | Recommended | Dragon hunter crossbow → Rune crossbow | 10 | 28 → 19 | [Wiki](https://oldschool.runescape.wiki/w/King_Black_Dragon/Strategies) |
| King Black Dragon | Optimal | Dragon hunter crossbow → Dragon hunter crossbow | 11 | 27 → 18 | [Wiki](https://oldschool.runescape.wiki/w/King_Black_Dragon/Strategies) |
| Vorkath | Entry | Rune crossbow → Rune crossbow | 2 | 27 → 22 | [Wiki](https://oldschool.runescape.wiki/w/Vorkath/Strategies) |
| Vorkath | Recommended | Dragon hunter crossbow → Dragon crossbow | 10 | 28 → 20 | [Wiki](https://oldschool.runescape.wiki/w/Vorkath/Strategies) |
| Vorkath | Optimal | Dragon hunter crossbow → Dragon hunter crossbow | 1 | 27 → 18 | [Wiki](https://oldschool.runescape.wiki/w/Vorkath/Strategies) |
| Phantom Muspah | Entry | Rune crossbow → Rune crossbow | 2 | 27 → 20 | [Wiki](https://oldschool.runescape.wiki/w/Phantom_Muspah/Strategies) |
| Phantom Muspah | Recommended | Twisted bow → Bow of Faerdhinen (c) | 10 | 28 → 19 | [Wiki](https://oldschool.runescape.wiki/w/Phantom_Muspah/Strategies) |
| Phantom Muspah | Optimal | Twisted bow → Twisted bow | 0 | 26 → 18 | [Wiki](https://oldschool.runescape.wiki/w/Phantom_Muspah/Strategies) |
| Hueycoatl | Entry | Dragon mace → Dragon mace | 2 | 27 → 15 | [Wiki](https://oldschool.runescape.wiki/w/The_Hueycoatl/Strategies) |
| Hueycoatl | Recommended | Inquisitor's mace → Dragon mace | 10 | 28 → 17 | [Wiki](https://oldschool.runescape.wiki/w/The_Hueycoatl/Strategies) |
| Hueycoatl | Optimal | Inquisitor's mace → Dragon hunter lance | 10 | 26 → 16 | [Wiki](https://oldschool.runescape.wiki/w/The_Hueycoatl/Strategies) |
| Grotesque Guardians | Entry | Granite hammer → Granite hammer | 2 | 26 → 18 | [Wiki](https://oldschool.runescape.wiki/w/Grotesque_Guardians/Strategies) |
| Grotesque Guardians | Recommended | Granite hammer → Granite hammer | 2 | 28 → 17 | [Wiki](https://oldschool.runescape.wiki/w/Grotesque_Guardians/Strategies) |
| Grotesque Guardians | Optimal | Soulreaper axe → Scythe of Vitur | 6 | 26 → 16 | [Wiki](https://oldschool.runescape.wiki/w/Grotesque_Guardians/Strategies) |
| Barrows | Entry | Iban's staff (u) → Iban's staff (u) | 1 | 26 → 14 | [Wiki](https://oldschool.runescape.wiki/w/Barrows/Strategies) |
| Barrows | Recommended | Air battlestaff → Trident of the seas (full) | 7 | 26 → 11 | [Wiki](https://oldschool.runescape.wiki/w/Barrows/Strategies) |
| Barrows | Optimal | Tumeken's shadow → Trident of the Swamp | 8 | 26 → 10 | [Wiki](https://oldschool.runescape.wiki/w/Barrows/Strategies) |
| Dagannoth Kings — Rex safespot with Guthan healing switch | Entry | Iban's staff (u) → Iban's staff (u) | 0 | 27 → 20 | [Wiki](https://oldschool.runescape.wiki/w/Dagannoth_Kings/Strategies) |
| Dagannoth Kings — Rex safespot with Guthan healing switch | Recommended | Trident of the Swamp → Trident of the Swamp | 0 | 28 → 17 | [Wiki](https://oldschool.runescape.wiki/w/Dagannoth_Kings/Strategies) |
| Dagannoth Kings — Rex safespot with Guthan healing switch | Optimal | Sanguinesti staff → Sanguinesti staff | 0 | 27 → 15 | [Wiki](https://oldschool.runescape.wiki/w/Dagannoth_Kings/Strategies) |
| Zulrah | Entry | Trident of the seas (full) → Iban's staff (u) | 5 | 27 → 16 | [Wiki](https://oldschool.runescape.wiki/w/Zulrah/Strategies) |
| Zulrah | Recommended | Twinflame staff → Trident of the Swamp | 2 | 28 → 13 | [Wiki](https://oldschool.runescape.wiki/w/Zulrah/Strategies) |
| Zulrah | Optimal | Tumeken's shadow → Tumeken's shadow | 0 | 27 → 12 | [Wiki](https://oldschool.runescape.wiki/w/Zulrah/Strategies) |
| Dagannoth Kings — Prime | Entry | Rune crossbow → Rune crossbow | 2 | 28 → 19 | [Wiki](https://oldschool.runescape.wiki/w/Dagannoth_Kings/Strategies) |
| Dagannoth Kings — Prime | Recommended | Bow of Faerdhinen (c) → Bow of Faerdhinen (c) | 0 | 28 → 17 | [Wiki](https://oldschool.runescape.wiki/w/Dagannoth_Kings/Strategies) |
| Dagannoth Kings — Prime | Optimal | Twisted bow → Twisted bow | 0 | 28 → 16 | [Wiki](https://oldschool.runescape.wiki/w/Dagannoth_Kings/Strategies) |
| Dagannoth Kings — Supreme | Entry | Dragon scimitar → Dragon scimitar | 1 | 27 → 18 | [Wiki](https://oldschool.runescape.wiki/w/Dagannoth_Kings/Strategies) |
| Dagannoth Kings — Supreme | Recommended | Osmumten's fang → Abyssal whip | 3 | 28 → 17 | [Wiki](https://oldschool.runescape.wiki/w/Dagannoth_Kings/Strategies) |
| Dagannoth Kings — Supreme | Optimal | Scythe of Vitur → Scythe of Vitur | 8 | 28 → 16 | [Wiki](https://oldschool.runescape.wiki/w/Dagannoth_Kings/Strategies) |
| Obor | Entry | Rune scimitar → Rune scimitar | 1 | 27 → 14 | [Wiki](https://oldschool.runescape.wiki/w/Obor) |
| Obor | Recommended | Dragon scimitar → Dragon scimitar | 6 | 27 → 12 | [Wiki](https://oldschool.runescape.wiki/w/Obor) |
| Obor | Optimal | Scythe of Vitur → Abyssal whip | 10 | 26 → 10 | [Wiki](https://oldschool.runescape.wiki/w/Obor) |
| Bryophyta | Entry | Rune scimitar → Rune scimitar | 1 | 27 → 15 | [Wiki](https://oldschool.runescape.wiki/w/Bryophyta) |
| Bryophyta | Recommended | Dragon scimitar → Dragon scimitar | 5 | 27 → 15 | [Wiki](https://oldschool.runescape.wiki/w/Bryophyta) |
| Bryophyta | Optimal | Scythe of Vitur → Abyssal whip | 10 | 27 → 13 | [Wiki](https://oldschool.runescape.wiki/w/Bryophyta) |

## Significant corrections and justified overlaps

- **Scurrius:** Rat-bone weapon is the progression pivot; no Torva required. Fast tag weapon is only needed before Bone mace.
- **Brutus:** F2P tiers use progressively stronger attainable gear; Rune scimitar overlaps because it is the best listed F2P melee weapon. Mooleta is a boss drop, not an Entry prerequisite.
- **Giant Mole:** Stab preference and Protect from Melee; Dragon dagger is a low-cost stab entry, Zombie axe is a practical mid-step and Fang is the Wiki melee kill-rate leader. Shield/light/spade are conditional tools.
- **Sarachnis:** Crush and magic defence matter; Dragon mace to Cudgel to Scythe. Aranea boots reduce web burden.
- **Amoxliatl:** Low defence and crush/multiple hits: Dragon mace entry, full Blood Moon dual mid-step, Inquisitor mace/full set high end. Prayer can be restored with moths outside.
- **King Black Dragon:** Wilderness risk matters. Rune crossbow/anti-dragon shield is practical through Recommended; DHCB/Masori/charged ward reserved for Optimal with explicit risk warning.
- **Vorkath:** Crossbow tiers progress Rune crossbow to Dragon crossbow to Dragon hunter crossbow. Salve(ei), protection and Crumble Undead remain important.
- **Phantom Muspah:** Ranged camp is slower on melee form. Entry bolt shield; Bowfa plus crystal mid-progression; Tbow/ZCB late shield switch.
- **Hueycoatl:** Crush body, multi-hit tail: Glacial temotli makes Entry attainable, full Blood Moon is the mid-step, and Dragon hunter lance is Wiki-ranked best for body in Optimal.
- **Grotesque Guardians:** Slayer-gated melee plus Dawn ranged switch; Granite hammer overlap is encounter-justified. Scythe is Wiki-ranked high end, not a generic price upgrade.
- **Barrows:** Iban to trident seas to swamp is a deliberate spell progression; Shadow is not required to clear Barrows.
- **Dagannoth Kings — Rex safespot with Guthan healing switch:** Safe-spot mage progresses Iban to Trident with Guthan sustain to Sanguinesti; pet rock and thrownaxe are route tools.
- **Zulrah:** Magic-only caveat persists on Tanzanite; Wiki-ranked Iban staff, Trident swamp, then Shadow span an attainable Ironman entry and high-end mage progression.
- **Dagannoth Kings — Prime:** Crossbow to Bowfa full crystal to Tbow; two-handed offhand is empty. Single-king safespot and cave access tools.
- **Dagannoth Kings — Supreme:** Melee progresses Dragon scimitar, whip, Scythe with safe isolation; avoid treating a tribrid DPS rank as a generic solo guarantee.
- **Obor:** F2P Rune scimitar entry then Dragon scimitar/whip members-world upgrades, avoiding Torva/Scythe; first-entry key is conditional and reusable until chest.
- **Bryophyta:** F2P Rune scimitar entry, members Dragon scimitar/whip later; an actual woodcutting axe finishes growthlings. Slower hits can avoid extra spawns.

## Charge and provenance decisions

- The [Dragonfire ward Wiki page](https://oldschool.runescape.wiki/w/Dragonfire_ward) identifies item ID 22003 as uncharged and 22002 as charged. The charged ID does **not** prove 50 stored charges; inspect the shield in game before departure. Q07 retains it only in KBD and Vorkath Optimal. Their Recommended tiers instead use an anti-dragon shield. This resolves all four prior placeholders by changing two to the practical shield and giving the other two charged ID 22002.
- No Q07 plan claims its curated food counts or exact inventory cells are verbatim Wiki templates. Obor/Bryophyta have first-gate keys in all three tiers, labeled conditional; the Wiki says gate unlock does not consume the key and later entry does not require one. Bryophyta has a woodcutting axe, not a battleaxe. F2P Entry omits members-only antipoison/prayer potions.
- The official pages consulted on 2026-10-30 were Obor, Bryophyta and 13 strategy pages: Scurrius, Brutus, Giant Mole, Vorkath, Phantom Muspah, Sarachnis, The Hueycoatl, Amoxliatl, KBD, Grotesque Guardians, Zulrah, Barrows and Dagannoth Kings. Source URLs are embedded per profile. The R04 pinned rendered layout remains separately preserved.

## Open owner judgments

- **KBD Optimal:** DHCB, Masori and charged ward are high value through Wilderness transit. The Wiki discusses risk limits; a player may prefer Recommended for protected-item safety. No automatic account/risk adaptation is implemented.
- **Hueycoatl Entry:** the Wiki lists Glacial temotli as a tail multi-hit option; practical kill rate depends on team size and player levels. The Q07 food/prayer budget is a starting point.
- **Brutus:** Rune scimitar remains Recommended and Optimal because the F2P ranking favors it; the late tier changes shield/food rather than inventing a stronger F2P melee weapon. Mooleta is a boss drop.
- **Scurrius and Grotesque Guardians:** Bone mace and Granite hammer overlap across tiers because their encounter roles persist; armour/accessories and supply budgets distinguish tiers.
- **Zulrah:** the supported method is magic-only, with slower Tanzanite phases. A hybrid method needs separate research and approval.
- **All supply budgets:** TPT starting quantities have not been measured in native RuneLite for Zokeroth or any other account. Adjust after observed kill count and consumption; account-aware balancing is outside this ticket.
- **All item sprites:** IDs were validated against RuneLite 1.13.4 constants, but native sprite appearance and ward 50-charge Check require owner client proof.
