# BUR-OUTFITTER-QUALITY-04 — five full three-tier reviews

These are TPT curated short-trip loadouts. All equipment and inventory cells are shown; `—` is intentionally empty. Numbered inventory positions are UI positions, not a promise that every item is consumed. Wiki mechanic/ranking links are provided for each encounter.

## Obor

Official reference: https://oldschool.runescape.wiki/w/Obor

F2P Rune scimitar entry then Dragon scimitar/whip members-world upgrades, avoiding Torva/Scythe; first-entry key is conditional and reusable until chest.

| Equipment slot | Entry | Recommended | Optimal |
|---|---|---|---|
| Head | Rune full helm | Helm of Neitiznot | Neitiznot faceguard |
| Cape | Red cape | Ardougne cloak 2 | Fire cape |
| Neck | Amulet of strength | Amulet of strength | Amulet of fury |
| Ammunition | — | — | — |
| Weapon | Rune scimitar | Dragon scimitar | Abyssal whip |
| Body | Rune chainbody | Fighter torso | Fighter torso |
| Offhand | Rune kiteshield | Dragon defender | Dragon defender |
| Legs | Rune plateskirt | Rune plateskirt | Obsidian platelegs |
| Hands | Leather gloves | Rune gloves | Barrows gloves |
| Feet | Fancy boots | Climbing boots | Dragon boots |
| Ring | — | — | Berserker ring (i) |

| Inventory position | Entry | Recommended | Optimal |
|---:|---|---|---|
| 1 | Giant key | Giant key | Giant key |
| 2 | Strength potion(4) | Super combat potion(4) | Super combat potion(4) |
| 3 | Swordfish | Prayer potion(4) | Prayer potion(4) |
| 4 | Swordfish | Monkfish | Shark |
| 5 | Swordfish | Monkfish | Shark |
| 6 | Swordfish | Monkfish | Shark |
| 7 | Swordfish | Monkfish | Shark |
| 8 | Swordfish | Monkfish | Shark |
| 9 | Swordfish | Monkfish | Shark |
| 10 | Swordfish | Monkfish | Teleport to house (tablet) |
| 11 | Swordfish | Monkfish | — |
| 12 | Swordfish | Teleport to house (tablet) | — |
| 13 | Swordfish | — | — |
| 14 | Swordfish | — | — |
| 15 | — | — | — |
| 16 | — | — | — |
| 17 | — | — | — |
| 18 | — | — | — |
| 19 | — | — | — |
| 20 | — | — | — |
| 21 | — | — | — |
| 22 | — | — | — |
| 23 | — | — | — |
| 24 | — | — | — |
| 25 | — | — | — |
| 26 | — | — | — |
| 27 | — | — | — |
| 28 | — | — | — |

**Occupied slots:** Entry 14, Recommended 12, Optimal 10. Keys are first-gate/optional-chest items on Obor/Bryophyta and should be removed on repeat normal visits.

## Bryophyta

Official reference: https://oldschool.runescape.wiki/w/Bryophyta

F2P Rune scimitar entry, members Dragon scimitar/whip later; an actual woodcutting axe finishes growthlings. Slower hits can avoid extra spawns.

| Equipment slot | Entry | Recommended | Optimal |
|---|---|---|---|
| Head | Rune full helm | Helm of Neitiznot | Neitiznot faceguard |
| Cape | Red cape | Ardougne cloak 2 | Fire cape |
| Neck | Amulet of power | Amulet of fury | Amulet of fury |
| Ammunition | — | — | — |
| Weapon | Rune scimitar | Dragon scimitar | Abyssal whip |
| Body | Green d'hide body | Green d'hide body | Bandos chestplate |
| Offhand | Rune kiteshield | Rune kiteshield | Dragon defender |
| Legs | Green d'hide chaps | Green d'hide chaps | Bandos tassets |
| Hands | Leather gloves | Barrows gloves | Barrows gloves |
| Feet | Fancy boots | Climbing boots | Dragon boots |
| Ring | — | — | Berserker ring (i) |

| Inventory position | Entry | Recommended | Optimal |
|---:|---|---|---|
| 1 | Mossy key | Mossy key | Mossy key |
| 2 | Rune axe | Rune axe | Rune axe |
| 3 | Strength potion(4) | Antipoison(4) | Antipoison(4) |
| 4 | Swordfish | Super combat potion(4) | Super combat potion(4) |
| 5 | Swordfish | Prayer potion(4) | Prayer potion(4) |
| 6 | Swordfish | Prayer potion(4) | Prayer potion(4) |
| 7 | Swordfish | Monkfish | Shark |
| 8 | Swordfish | Monkfish | Shark |
| 9 | Swordfish | Monkfish | Shark |
| 10 | Swordfish | Monkfish | Shark |
| 11 | Swordfish | Monkfish | Shark |
| 12 | Swordfish | Monkfish | Shark |
| 13 | Swordfish | Monkfish | Teleport to house (tablet) |
| 14 | Swordfish | Monkfish | — |
| 15 | Swordfish | Teleport to house (tablet) | — |
| 16 | — | — | — |
| 17 | — | — | — |
| 18 | — | — | — |
| 19 | — | — | — |
| 20 | — | — | — |
| 21 | — | — | — |
| 22 | — | — | — |
| 23 | — | — | — |
| 24 | — | — | — |
| 25 | — | — | — |
| 26 | — | — | — |
| 27 | — | — | — |
| 28 | — | — | — |

**Occupied slots:** Entry 15, Recommended 15, Optimal 13. Keys are first-gate/optional-chest items on Obor/Bryophyta and should be removed on repeat normal visits.

## Amoxliatl

Official reference: https://oldschool.runescape.wiki/w/Amoxliatl/Strategies

Low defence and crush/multiple hits: Dragon mace entry, full Blood Moon dual mid-step, Inquisitor mace/full set high end. Prayer can be restored with moths outside.

| Equipment slot | Entry | Recommended | Optimal |
|---|---|---|---|
| Head | Helm of Neitiznot | Blood Moon helm | Inquisitor's great helm |
| Cape | Ardougne cloak 2 | Fire cape | Infernal cape |
| Neck | Amulet of strength | Amulet of fury | Amulet of rancour |
| Ammunition | Peaceful blessing | Rada's blessing 4 | Rada's blessing 4 |
| Weapon | Dragon mace | Dual macuahuitl | Inquisitor's mace |
| Body | Fighter torso | Blood Moon chestplate | Inquisitor's hauberk |
| Offhand | Dragon defender | — | Avernic defender |
| Legs | Obsidian platelegs | Blood Moon tassets | Inquisitor's plateskirt |
| Hands | Rune gloves | Barrows gloves | Ferocious gloves |
| Feet | Dragon boots | Dragon boots | Avernic treads (max) |
| Ring | — | Berserker ring (i) | Ultor ring |

| Inventory position | Entry | Recommended | Optimal |
|---:|---|---|---|
| 1 | Super combat potion(4) | Super combat potion(4) | Divine super combat potion(4) |
| 2 | Prayer potion(4) | Prayer potion(4) | Prayer potion(4) |
| 3 | Prayer potion(4) | Prayer potion(4) | Prayer potion(4) |
| 4 | Shark | Shark | Shark |
| 5 | Shark | Shark | Shark |
| 6 | Shark | Shark | Shark |
| 7 | Shark | Shark | Shark |
| 8 | Shark | Shark | Shark |
| 9 | Shark | Shark | Cooked karambwan |
| 10 | Shark | Cooked karambwan | Cooked karambwan |
| 11 | Shark | Cooked karambwan | Teleport to house (tablet) |
| 12 | Cooked karambwan | Teleport to house (tablet) | — |
| 13 | Cooked karambwan | — | — |
| 14 | Teleport to house (tablet) | — | — |
| 15 | — | — | — |
| 16 | — | — | — |
| 17 | — | — | — |
| 18 | — | — | — |
| 19 | — | — | — |
| 20 | — | — | — |
| 21 | — | — | — |
| 22 | — | — | — |
| 23 | — | — | — |
| 24 | — | — | — |
| 25 | — | — | — |
| 26 | — | — | — |
| 27 | — | — | — |
| 28 | — | — | — |

**Occupied slots:** Entry 14, Recommended 12, Optimal 11. Keys are first-gate/optional-chest items on Obor/Bryophyta and should be removed on repeat normal visits.

## Giant Mole

Official reference: https://oldschool.runescape.wiki/w/Giant_Mole/Strategies

Stab preference and Protect from Melee; Dragon dagger is a low-cost stab entry, Zombie axe is a practical mid-step and Fang is the Wiki melee kill-rate leader. Shield/light/spade are conditional tools.

| Equipment slot | Entry | Recommended | Optimal |
|---|---|---|---|
| Head | Rune full helm | Helm of Neitiznot | Neitiznot faceguard |
| Cape | Ardougne cloak 2 | Fire cape | Fire cape |
| Neck | Amulet of glory | Amulet of fury | Amulet of torture |
| Ammunition | — | Rada's blessing 4 | Rada's blessing 4 |
| Weapon | Dragon dagger | Zombie axe | Osmumten's fang |
| Body | Proselyte hauberk | Proselyte hauberk | Bandos chestplate |
| Offhand | Rune defender | Dragon defender | Dragon defender |
| Legs | Proselyte cuisse | Proselyte cuisse | Bandos tassets |
| Hands | Combat bracelet(4) | Barrows gloves | Barrows gloves |
| Feet | Climbing boots | Dragon boots | Dragon boots |
| Ring | — | — | Berserker ring (i) |

| Inventory position | Entry | Recommended | Optimal |
|---:|---|---|---|
| 1 | Super combat potion(4) | Super combat potion(4) | Divine super combat potion(4) |
| 2 | Prayer potion(4) | Prayer potion(4) | Prayer potion(4) |
| 3 | Prayer potion(4) | Prayer potion(4) | Prayer potion(4) |
| 4 | Prayer potion(4) | Prayer potion(4) | Prayer potion(4) |
| 5 | Prayer potion(4) | Prayer potion(4) | Prayer potion(4) |
| 6 | Energy potion(4) | Stamina potion(4) | Stamina potion(4) |
| 7 | Energy potion(4) | Shark | Shark |
| 8 | Shark | Shark | Shark |
| 9 | Shark | Shark | Shark |
| 10 | Shark | Shark | Shark |
| 11 | Shark | Shark | Spade |
| 12 | Shark | Shark | Falador shield 4 |
| 13 | Shark | Spade | Bullseye lantern |
| 14 | Shark | Falador shield 3 | Teleport to house (tablet) |
| 15 | Shark | Bullseye lantern | — |
| 16 | Spade | Teleport to house (tablet) | — |
| 17 | Bullseye lantern | — | — |
| 18 | Falador teleport (tablet) | — | — |
| 19 | Teleport to house (tablet) | — | — |
| 20 | — | — | — |
| 21 | — | — | — |
| 22 | — | — | — |
| 23 | — | — | — |
| 24 | — | — | — |
| 25 | — | — | — |
| 26 | — | — | — |
| 27 | — | — | — |
| 28 | — | — | — |

**Occupied slots:** Entry 19, Recommended 16, Optimal 14. Keys are first-gate/optional-chest items on Obor/Bryophyta and should be removed on repeat normal visits.

## King Black Dragon

Official reference: https://oldschool.runescape.wiki/w/King_Black_Dragon/Strategies

Wilderness risk matters. Rune crossbow/anti-dragon shield is practical through Recommended; DHCB/Masori/charged ward reserved for Optimal with explicit risk warning.

| Equipment slot | Entry | Recommended | Optimal |
|---|---|---|---|
| Head | Coif | Ancient coif | Ancient coif |
| Cape | Ava's accumulator | Ava's assembler | Ava's assembler |
| Neck | Amulet of fury | Amulet of fury | Necklace of anguish |
| Ammunition | Ruby bolts (e) | Ruby bolts (e) | Ruby dragon bolts (e) |
| Weapon | Rune crossbow | Rune crossbow | Dragon hunter crossbow |
| Body | Black d'hide body | Ancient d'hide body | Masori body (f) |
| Offhand | Anti-dragon shield | Anti-dragon shield | Dragonfire ward (charged; check 50 charges) |
| Legs | Black d'hide chaps | Ancient d'hide chaps | Masori chaps (f) |
| Hands | Barrows gloves | Barrows gloves | Barrows gloves |
| Feet | Dragon boots | Ancient d'hide boots | Ancient d'hide boots |
| Ring | Ring of life | Ring of shadows | Ring of shadows |

| Inventory position | Entry | Recommended | Optimal |
|---:|---|---|---|
| 1 | Diamond bolts (e) ×150 | Diamond bolts (e) ×150 | Diamond dragon bolts (e) ×150 |
| 2 | Antidote++(4) | Antidote++(4) | Antidote++(4) |
| 3 | Extended antifire(4) | Extended antifire(4) | Extended antifire(4) |
| 4 | Ranging potion(4) | Ranging potion(4) | Divine ranging potion(4) |
| 5 | Prayer potion(4) | Prayer potion(4) | Prayer potion(4) |
| 6 | Prayer potion(4) | Prayer potion(4) | Prayer potion(4) |
| 7 | Prayer potion(4) | Prayer potion(4) | Prayer potion(4) |
| 8 | Shark | Shark | Shark |
| 9 | Shark | Shark | Shark |
| 10 | Shark | Shark | Shark |
| 11 | Shark | Shark | Shark |
| 12 | Shark | Shark | Shark |
| 13 | Shark | Shark | Shark |
| 14 | Shark | Shark | Shark |
| 15 | Shark | Shark | Shark |
| 16 | Shark | Shark | Shark |
| 17 | Shark | Shark | Burning amulet(5) |
| 18 | Shark | Burning amulet(5) | Teleport to house (tablet) |
| 19 | Shark | Teleport to house (tablet) | — |
| 20 | Burning amulet(5) | — | — |
| 21 | Teleport to house (tablet) | — | — |
| 22 | — | — | — |
| 23 | — | — | — |
| 24 | — | — | — |
| 25 | — | — | — |
| 26 | — | — | — |
| 27 | — | — | — |
| 28 | — | — | — |

**Occupied slots:** Entry 21, Recommended 19, Optimal 18. Keys are first-gate/optional-chest items on Obor/Bryophyta and should be removed on repeat normal visits.
