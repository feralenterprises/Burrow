# Outfitter research R04 correction

Parent: R03 loadouts SHA-256 `83e8dfe32340c2807b413cb09037589345fb06d0683c016c08f206c8e8105fde`.

- Corrected Dagannoth Kings Rex inventory positions 4, 8, 11, 12, 16, 20 from item ID 5943 (Antidote+(4)) to 5952 (Antidote++(4)). The pinned Wiki strategy labels each cell Antidote++(4); the [OSRS Wiki GEIDs mapping](https://oldschool.runescape.wiki/w/Module:GEIDs/data.json) distinguishes the two IDs.
- Audited 29 other named cells without exact IDs. None can be assigned a unique raw ID from the pinned source because dose or charge/state is unspecified. R04 retains them as null IDs, text labels, source attribution and `UNRESOLVED_VARIANT` entries in the accompanying CSV. Cowbell amulet, ward and teleport jewellery have charge/state distinctions; no single variant is implied.
- Preserved all 17 research records, including 13 complete Wiki methods, two partial community candidates and the incomplete Prime/Supreme methods. The Java catalog includes only the 13 verified complete methods.
- Known item IDs with variable quantities display an unknown amount and do not form an exact bank requirement. The R03 price-dependent rendered food and prayer snapshot remains a research caveat.

Release HOLD. No Iron Ledger source was modified.
