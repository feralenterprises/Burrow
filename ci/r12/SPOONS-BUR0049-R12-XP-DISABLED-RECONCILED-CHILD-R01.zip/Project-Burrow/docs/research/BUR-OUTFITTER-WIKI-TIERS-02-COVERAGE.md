# BUR-OUTFITTER-WIKI-TIERS-02 coverage and handback

Release: **HOLD**. Product tier names are not official OSRS Wiki categories. The R04 recommended layouts are unchanged. Entry uses Wiki-ranked alternative gear with the same exact R04 inventory, and is labeled as a product combination in the interface. An unavailable tier never borrows items from another tier.

| Boss | Entry | Recommended | Optimal | Method and evidence |
|---|---|---|---|---|
| Scurrius | Available, Wiki alternatives + R04 inventory | R04 official layout | Unavailable | Mid-level melee, Rune scimitar before bone mace; [Wiki strategy](https://oldschool.runescape.wiki/w/Scurrius/Strategies) |
| Brutus | Available, Wiki alternatives + R04 inventory | R04 official layout | Unavailable | Standard F2P melee; [Wiki strategy](https://oldschool.runescape.wiki/w/Brutus/Strategies) |
| Giant Mole | Unavailable | R04 official layout | Unavailable | Melee and prayer budget |
| Vorkath | Unavailable | R04 official layout | Unavailable | Ranged crossbow |
| Phantom Muspah | Unavailable | R04 official layout | Unavailable | Ranged-only bow with shield-phase switch |
| Sarachnis | Unavailable | R04 official layout | Unavailable | Low-level crush melee |
| Hueycoatl | Unavailable | R04 official layout | Unavailable | Body melee plus tail switches |
| Amoxliatl | Unavailable | R04 official layout | Unavailable | Full Inquisitor melee |
| King Black Dragon | Unavailable | R04 official layout | Unavailable | Ranged crossbow standard route |
| Grotesque Guardians | Unavailable | R04 official layout | Unavailable | Mid-game melee with ranged switch |
| Zulrah | Unavailable | R04 official layout | Unavailable | Magic-only |
| Barrows | Unavailable | R04 official layout | Unavailable | Lower-level hybrid, Magic primary |
| Dagannoth Kings | Unavailable | R04 official Rex | Unavailable | Rex safespot; Prime ranged and Supreme melee selectable but unavailable |
| Obor | Unavailable | Unavailable | Unavailable | Existing community gear list lacks a complete verified 11/28 layout |
| Bryophyta | Unavailable | Unavailable | Unavailable | Existing community gear list lacks a complete verified 11/28 layout |

The official Wiki supplies ranked equipment and preparation prose for several additional methods. The reviewed source does not specify independent, complete 28-position layouts for the other product tiers. R04 partial community suggestions for Obor/Bryophyta have reconstructed positions and unspecified gear slots; Prime has equipment but no validated inventory; Supreme has no validated full layout. They remain unavailable. No community plan is presented as official.

## Implementation

- Three buttons in the existing Outfitter recommendation row: Entry, Recommended (initial default), Optimal. Boss and method selection preserve the chosen tier, while unsupported combinations show no equipment, inventory or bank projection.
- Scurrius Entry uses the Wiki mid-level rank alternatives (Rune scimitar, rune armour, Combat bracelet, Climbing boots and source-listed N/A ring) with the unchanged R04 28-slot inventory. Brutus Entry uses Barronite mace, Rune kiteshield, Leather gloves and Fancy boots with unchanged R04 inventory. These are product-curated combinations; the R04 literal Wiki layout remains Recommended.
- Prime and Supreme appear under Dagannoth Kings as selectable methods, with Ranged and Melee style labels and an explicit unavailable state. Obor and Bryophyta also show an explicit unavailable melee method.
- Exact RuneLite sprite IDs and quantities are retained for known variants; 29 R04 dose, charge or variant ambiguities remain text-only. Rex inventory positions 4, 8, 11, 12, 16 and 20 retain Antidote++(4) ID 5952. Two-handed pairings in the 13 original profiles are unchanged.
- Source authority and pinned URL are available in the source tooltip. No Best in Bank, account-aware substitution, loot or bank scanning feature was added.

## Build and test

- Java 17.0.20 compiler and runtime: `PATH="$PWD/tooling:$PATH" bash scripts/build-offline.sh` — PASS, 10 standalone suites including 896 tier assertions, Swing previews produced.
- `python3 scripts/verify-tier-research.py` — PASS, 51 method/tier records, 15 available, parent R04 unchanged.
- `tooling/javac --release 17 -encoding UTF-8 -cp "$RL_CP" -d build/host-main @build/HOST-MAIN-SOURCES.txt` with the recovered RuneLite 1.13.4 host classpath — PASS; test source compile — PASS with missing optional annotation class warnings.
- JUnit Platform launcher package scan — 22/22 tests PASS. This is a direct Java classpath run, not a Gradle task.
- Native RuneLite client test and Windows owner smoke: NOT RUN for this candidate. Release remains HOLD.

## Owner verification

1. Build this source using Java 17 and the project Gradle task on the owner machine; start RuneLite with this exact candidate.
2. Open Outfitter: verify Recommended opens Scurrius with bone mace, switch to Entry for Rune scimitar, then Optimal for no items. Switch to Brutus Entry and confirm Barronite mace, Rune kiteshield, Leather gloves and Fancy boots. Switch back to Recommended and confirm its original gear.
3. Select Dagannoth Kings Rex, then Prime and Supreme: both should clear all items; returning to Rex should restore Antidote++(4) sprites in six positions. Check Obor and Bryophyta unavailable states.
4. Check Home, Pathfinder, Sessions, existing bank header behavior, 225px scroll, item tooltips and two-handed switches. Record the exact Gradle command/log, plugin JAR hash, RuneLite version and screenshots. Do not release until owner-native and remaining gates pass.
