# BUR-OUTFITTER-WIKI-TIERS-03 coverage and provenance

Release: **HOLD**. Entry, Recommended, and Optimal are TrashPanda Tracker product labels. The 13 prior R04 Wiki layouts are preserved in `VerifiedOutfitterCatalog` and remain the Recommended base; R06 explicitly selects a dose, charge or stack amount where an original cell was unspecified. New tiers and the four completed methods are product curation, not official Wiki tier templates.

| Boss / method | Entry weapon | Recommended weapon | Optimal weapon | Source treatment |
|---|---|---|---|---|
| Scurrius / Standard, mid-level melee with bone mace | Rune scimitar | Bone mace | Bone mace | R04 Wiki layout + TPT variants |
| Brutus / Standard free-to-play | Barronite mace | Rune scimitar | Rune scimitar | R04 Wiki layout + TPT variants |
| Giant Mole / Melee and prayer budget | Dragon sword | Abyssal dagger | Osmumten's fang | R04 Wiki literal |
| Sarachnis / Low-level melee, crush with Zamorakian hasta | Dragon mace | Zamorakian hasta | Scythe of Vitur | R04 Wiki layout + TPT variants |
| Amoxliatl / Melee, full Inquisitor with mace | Dual macuahuitl | Inquisitor's mace | Inquisitor's mace | R04 Wiki layout + TPT variants |
| King Black Dragon / Crossbow, standard route | Rune crossbow | Dragon hunter crossbow | Dragon hunter crossbow | R04 Wiki layout + TPT variants |
| Vorkath / Ranged crossbow | Rune crossbow | Dragon hunter crossbow | Dragon hunter crossbow | R04 Wiki layout + TPT variants |
| Phantom Muspah / Ranged-only, Twisted bow with Zaryte crossbow shield-phase switch | Rune crossbow | Twisted bow | Twisted bow | R04 Wiki layout + TPT variants |
| Hueycoatl / Body melee plus tail switches | Dragon mace | Inquisitor's mace | Inquisitor's mace | R04 Wiki literal |
| Grotesque Guardians / Mid-game melee with Eclipse atlatl ranged switch | Granite hammer | Granite hammer | Soulreaper axe | R04 Wiki layout + TPT variants |
| Barrows / Standard lower-level hybrid, Magic primary | Iban's staff (u) | Air battlestaff | Tumeken's shadow | R04 Wiki literal |
| Dagannoth Kings / Rex safespot with Guthan healing switch | Iban's staff (u) | Trident of the Swamp | Sanguinesti staff | R04 Wiki layout + TPT variants |
| Zulrah / Magic-only Zulrah loadout | Trident of the seas (full) | Twinflame staff | Tumeken's shadow | R04 Wiki layout + TPT variants |
| Dagannoth Kings / Prime, ranged | Rune crossbow | Bow of Faerdhinen (c) | Twisted bow | Wiki strategy + TPT curation |
| Dagannoth Kings / Supreme, melee | Dragon scimitar | Osmumten's fang | Scythe of Vitur | Wiki strategy + TPT curation |
| Obor / Melee, standard | Rune scimitar | Dragon scimitar | Scythe of Vitur | Wiki mechanics + Ironman Path lead + TPT curation |
| Bryophyta / Melee, standard | Rune scimitar | Dragon scimitar | Scythe of Vitur | Wiki mechanics + Ironman Path lead + TPT curation |

**Coverage:** 15 bosses, 17 combat methods, 51 of 51 tier plans. Each has 11 equipment positions and 28 inventory positions; `null` is an intentional empty TPT position. No tier is unavailable. Source URLs, item-level IDs, role labels, selected quantities and preparation notes are in the R06 JSON.

## Curation and source boundaries

- The 13 original R04 loadouts remain untouched as a source reference. R06 Recommended uses their layout and chooses explicit four-dose potions, charge options and ammunition/rune stacks where R04 did not specify them. These choices are labeled TPT-selected; the Wiki is not credited with those exact quantities.
- Entry and Optimal selections use ranked equipment options, boss mechanics, and practical budget or high-end tradeoffs. All new inventory positions and supply counts are TPT choices. The official Wiki strategy URL is recorded per profile. [Scurrius strategy](https://oldschool.runescape.wiki/w/Scurrius/Strategies), [Giant Mole strategy](https://oldschool.runescape.wiki/w/Giant_Mole/Strategies), [Vorkath strategy](https://oldschool.runescape.wiki/w/Vorkath/Strategies), [Sarachnis strategy](https://oldschool.runescape.wiki/w/Sarachnis/Strategies) and [Zulrah strategy](https://oldschool.runescape.wiki/w/Zulrah/Strategies) give ranked options and encounter guidance; the R04 source matrix retains the pinned revision for all 13 original methods.
- Obor and Bryophyta include an [Ironman Path Obor](https://ironmanpath.app/en/bosses/obor/) or [Bryophyta](https://ironmanpath.app/en/bosses/bryophyta/) partial key-gear lead. Their completed slots and quantities are TPT selections. The official boss pages supersede older key-per-fight claims: the key is first access or an optional reward chest; inventory notes say when to remove it.
- Prime uses a complete Bowfa/Crystal pairing for Recommended and Twisted bow/Masori for Optimal. R04 paired Twisted bow with Elysian shield in its partial Prime lead; R06 clears the offhand. Supreme is a newly curated melee method. Pet rock and rune thrownaxe remain cave-entry utility.
- Rune crossbows use regular enchanted bolts in Entry plans. Bowfa has Crystal armour, no offhand and no ammo. Two-handed bows, Scythe, Soulreaper axe, dual macuahuitl and Shadow leave the offhand empty. R06 switch plans reserve free inventory space, except preserved R04 layouts whose notes instruct consuming a supply first.
- For exact item identity, new cells carry a RuneLite 1.13.4 `ItemID` field name and numeric value. The validator compares both. The six Rex Antidote++(4) cells remain 5952.

## Specific remaining item blocker

Four R06 equipment cells—King Black Dragon and Vorkath, Recommended and Optimal—retain `Dragonfire ward` without a numeric ID. R04 did not establish its charge variant. They render a labeled text placeholder and do not enter a bank projection. The RuneLite constants expose IDs 22002 and 22003, but this candidate does not guess which charge state belongs in those four source cells. All other R06 items have exact IDs; native verification should confirm the intended ward variant before filling them.

## Test and native gate

Java 17 offline suite, direct RuneLite 1.13.4 dependency compile, JUnit regression suite, R06 schema/ID/compatibility validator and deterministic source ZIP integrity are recorded in verification logs. No native RuneLite client was run for this candidate. Release stays HOLD.

Owner verification should target the new tier changes, not repeat previously demonstrated sidebar launch behavior: check Prime Bowfa and Twisted bow offhand, Supreme melee, Obor/Bryophyta key and axe cases, Vorkath Rune crossbow bolts, a two-handed switch with free inventory space, source tooltips, and the four ward placeholders. Capture the exact Gradle log, plugin JAR SHA, RuneLite version and any item sprite/tooltip mismatch.
