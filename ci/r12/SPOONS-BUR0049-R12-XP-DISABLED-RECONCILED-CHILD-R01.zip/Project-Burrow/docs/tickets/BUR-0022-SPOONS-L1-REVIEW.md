# BUR-0022 | Spoons Independent L1 Source Review

**Disposition: PASS for scoped source correction; Tongs independent L2 pending; release HOLD.**

## What changed for players
Scurrius Entry no longer incorrectly says you must obtain Scurrius' spine and craft a bone mace before your first kill. All three melee tiers now display **Standard melee** instead of a misleading name promising bone mace in every tier. Entry retains Rune scimitar; Recommended retains bone mace; Optimal retains Scythe of Vitur with a bone mace rat switch. No inventories, other bosses, or additional combat methods were changed.

## Independent findings
- Frozen R03 ZIP SHA-256: `1d909537570931ffa12f39718a3dc7118712cf57103ab2a5bb8864004cafd44c` verified.
- Noodles patch: exactly nine manifest files (eight modifications, one new test); their `before_sha256` and `after_sha256` match independently reconstructed files.
- The canonical dataset has exactly **four semantic differences**: three Scurrius method titles, one removal from Entry's prerequisites. Other 48 profiles and every equipment/inventory position unchanged.
- Entry retains Rune scimitar item 1333; Recommended retains bone mace item 28792; Optimal retains Scythe 22325 in the weapon slot and bone mace 28792 in the inventory as a rat switch.
- Quest gates for the selected Entry equipment remain: **Dragon Slayer I** for rune platebody and **Death Plateau** for climbing boots. These are equipment requirements, not universal requirements to fight Scurrius.
- Strict JSON verifier passes, generated Java and TSV were reproduced byte-for-byte twice; tampered JSON was correctly rejected.
- Independently compiled with **JDK 21 `--release 17`**, then ran **20 standalone offline regression programs**, all passing. This is **not** a genuine JDK17 Gradle/JUnit or RuneLite native test.
- Verified 48 permanent IDs and unchanged next unused `BUR-0049`; 33-item player-facing board retains its 33 items. Only BUR-0022 status/notes updated.

## OSRS research cross-check
- https://oldschool.runescape.wiki/w/Bone_mace: bone mace requires 50 Attack, a rune mace and Scurrius' spine obtained from Scurrius, plus Smithing or fee. It therefore cannot be demanded for a first kill.
- https://oldschool.runescape.wiki/w/Rune_platebody: Dragon Slayer I needed to equip platebody.
- https://oldschool.runescape.wiki/w/Climbing_boots: Death Plateau completion needed to wear boots.

## Remaining boundaries
- **BUR-0034**: Scurrius Ranged and Magic methods absent; not authorized by this ticket.
- **BUR-0021**: Realistic 28-slot inventory improvements pending; existing supplies unchanged.
- **BUR-0037**: Raw JSON switching text remains a separate open readability issue.
- No additional owner RuneLite testing until all 33 prioritized tickets have been worked on and feasible changes integrated.
- Tongs L2 must challenge the whole Scurrius pilot independently before source acceptance is considered final.

## Next dispatch
**Tongs: BUR-0022 independent L2 source/gameplay review** of this R04. Once reviewed, **Noodles: BUR-0021 realistic boss inventories** as the next data-lane development task. UI lane remains single-editor and unmodified.
