# BUR-0036 | Spoons independent L1 patch review

**Checkpoint:** BUR-0036-SPOONS-L1-REVIEW-01  
**Status:** **CONDITIONAL L1 PASS for source lineage and offline tooltip regression only**  
**Release:** **HOLD**  
**Next up:** **Tongs independent L2**, followed by genuine Java 17 Gradle and targeted owner-native verification.

## Reviewed inputs and source identity

- Baseline: `TRASHPANDA-TRACKER-INTELLIJ-F06-OWNER-HANDOFF-20261030.zip`  
  SHA-256: `a68aeba08846ab84c758112a6dd388adee3a52a0da8fff8fa54da9bcec31f58e`.
- Patch: `BUR-0036-SPORKS-F06-TOOLTIP-PATCH.zip` (unmodified copy included under `evidence/`).
- Reconciled prereq: `BUR-0018-SPOONS-L1-DEPENDENCY-RECON-F06.zip`.
- Owner evidence: `BUR-0045-SPOONS-L1-EVIDENCE-INTAKE-F06.zip`.

`evidence/source-audit.json` pins hashes for each input and checks every file in Sporks' patch manifest.

## Independent source-scope audit

- Compared actual patch ZIP against exact F06 baseline, not an already-mutated project.
- Only **one** existing production Java file modified: `BurrowPanel.java`, one method's preparation-hover return expression.
- New production helper: `PreparationTooltip.java`.
- Three test entrypoints added; companion handback/log/manifest files added.
- `getToolTipText(MouseEvent)` preserves both gear and inventory hitboxes and the unchanged exact-item tooltip subroutine. Swing tooltip registration (`setToolTipText(" ")`) is unchanged.
- No changes to catalog/boss recommendations, plugin entrypoint, Gradle configuration, navigation, bank activity or other production classes.
- All Sporks patch-manifest file hashes match.
- Sporks' register updates exactly **BUR-0036** versus the prior BUR-0018 reconciled register. This handback separately reconciles **BUR-0019** in its own scoped exception.

## Tests freshly run for this review

Independently extracted F06 original and overlaid exact Sporks patch in a fresh folder:

- `javac --release 17` offline source compilation: **PASS** under **JDK 21**, major Java class-file version **61**.
- Actual Outfitter `getToolTipText(MouseEvent)` smoke across 51 profiles: **PASS**, worst bounded tooltip **213 x 212 pixels**, compared with original 16,480px maximum text width.
- HTML escaping, basic mouse route and pre-existing gear tooltip name route: **PASS offline**.
- 11 additional baseline offline core/UI regression main programs: **PASS** including 6,540 canonical FINAL-06 dataset assertions.
- Note: first review attempt omitted `src/test/resources`, causing a **test harness classpath error** for FINAL06 manifest. Re-run with the proper resources **PASS**. This is recorded, not concealed.

These are **JDK 21 `--release 17` smoke/regression passes**, NOT a real Java 17 Gradle build, NOT execution of newly added JUnit tests, and NOT native RuneLite validation. Evidence logs are in `evidence/`.

## Limitations and evidence gaps

1. Gradle requires **an actual JDK 17 JVM**. The review environment has JDK 21 only; `./gradlew clean test jar` **NOT RUN**.
2. JUnit 5 test source is present but no JUnit runner was available; JUnit tests **NOT RUN**.
3. A smaller Swing tooltip in headless mode does **not prove** native position, visibility, interaction, default hover latency, or modifier-free item hover.
4. BUR-0019 (ordinary item hover) is still unresolved; source-path preservation is not an acceptance test.
5. The preview intentionally truncates notes. The full preparation panel remains clipped; BUR-0037 is a distinct open defect. The phrase `See preparation panel` is not proof that all hidden notes are visible there.
6. Existing suspect gear recommendations and KBD missing visible Wilderness warning were not modified.

## Register reconciliation and ID policy

- **BUR-0036** updated to `L1_SOURCE_OFFLINE_PASS__TONGS_L2_JDK17_GRADLE_NATIVE_PENDING` and remains OPEN.
- **BUR-0019** is now separately scoped to the already-present Outfitter gear/inventory hover component: `BUR-0018` is no longer a *functional prerequisite for this narrow repair*, because the UI scaffold already exists. **BUR-0018 remains OPEN**, with no blanket waiver for other tickets.
- **BUR-0019** remains BLOCKED by **BUR-0036 acceptance** and must not be dispatched as closed/ready solely on L1 offline tests.
- All permanent IDs `BUR-0001`..`BUR-0047` remain untouched and unique; next unused `BUR-0048`. No other ticket metadata or dependencies change. `release_gate=HOLD` remains.
- **This is an overlay, not a code update.** The Java patch is already in the separate Sporks ZIP. Do not accidentally overwrite a newer local register.

## Acceptance and next-up

Tongs must independently check this exact patch against source and acceptance gates. Once Tongs reviews, compile and run `\.\gradlew.bat --no-daemon clean test jar` under an actual Java 17 Gradle JVM on Windows. Owner-native verification should only require a *targeted hover* over the previously oversized preparation region and one normal item icon; do not ask to repeat established four-tab launch proof. Capture exact relevant logs/screenshot if a discrepancy is found.

**Next-up dispatch:** Tongs L2 on `BUR-0036`. If accepted by independent L2, proceed to genuine Java17 Gradle and owner-native checks; then Sporks `BUR-0019` no-Ctrl hover repair can be dispatched. Release HOLD until all gates pass.
