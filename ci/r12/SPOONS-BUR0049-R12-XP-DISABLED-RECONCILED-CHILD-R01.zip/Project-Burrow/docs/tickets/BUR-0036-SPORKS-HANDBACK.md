# BUR-0036 | Sporks F06 tooltip overflow patch

**Result:** Source patch produced. Offline regression PASSED. **Release HOLD**.  
**Role:** Sporks; independent Spoons L1 and Tongs L2 remain pending.

## Exact source identity

- Original complete IntelliJ archive: `TRASHPANDA-TRACKER-INTELLIJ-F06-OWNER-HANDOFF-20261030.zip`
- Archive SHA256: `a68aeba08846ab84c758112a6dd388adee3a52a0da8fff8fa54da9bcec31f58e`
- Before `BurrowPanel.java` SHA256: `0512a6eb9534d0ca93ff692960511545721e36ae12d64cf7e21a3bf5266b220a`
- After `BurrowPanel.java` SHA256: `f6b34166df641ab0075ab10fb555357523e338cca297b9dd6b4699e9ce953c8c`

## Changes

- Replaced only the **preparation-area** tooltip concatenation (`BurrowPanel#getToolTipText`), which previously joined the complete notes, unlocks, charge requirements and switches on **one plain line**.
- Added pure Java `PreparationTooltip` with explicit bounded line wrapping, HTML-safe text, group labels, truncation notices, and a pointer back to the preparation panel.
- Did **not** alter item-identity lookup or ordinary gear/inventory tooltip routing (BUR-0019 still open); did not alter layouts, boss dataset, quest logic, bank behavior, or production build configuration.
- Added a four-case JUnit test and offline smoke/measurement entrypoints.

## Tests and evidence

- Locally compiled transitive Java source with **JDK 21 `javac --release 17`**: PASS, generated Java 17 bytecode (major 61). **This is not a genuine Java 17 JVM build.**
- Offline headless Swing test for **all 51 profiles**: PASS, maximum measured patched tooltip **213 x 212 pixels**.
- Source-equivalent previous unwrapped tooltip: **16,480 pixels wide** in worst example, explaining owner screenshot.
- HTML escaping and gear hover route preservation: PASS in offline smoke check.
- JUnit source included but **not executed** here; Gradle itself requires JDK17 and it is unavailable here.
- Native RuneLite and no-modifier item hover: **not verified** by this patch. Do not close BUR-0019.
- Run results captured in `BUR-0036-LOCAL-VALIDATION.log`.

## Apply locally (IMPORTANT)

This is a **partial source patch**, not a complete IntelliJ project. Back up your working `Project-Burrow` first. Extract this ZIP in the **parent folder containing `Project-Burrow`** and merge the matching tree, replacing the named `BurrowPanel.java` and `BURROW-TICKETS.json` only if the baseline SHA above matches and local ticket data has not advanced. No existing source files should be deleted. If another crew patch modified these files since F06, reconcile manually rather than overwriting.

After applying from the `Project-Burrow` folder on Windows with Java 17:

```powershell
.\gradlew.bat --no-daemon clean test jar
```

**Targeted owner-native confirmation, only after Java17 build passes:** On a previously reproduced boss Outfitter preparation box, hover over the notes region once. Verify a short multiline tooltip (not across the game), then hover one gear icon and ensure its item-name behavior has not regressed. No request to repeat established RuneLite launch/four-tab proof. Full no-Ctrl hover acceptance belongs to BUR-0019.

## Gates and dispatch

- **BUR-0036** stays OPEN/PATCH READY pending Java17 Gradle, Spoons L1, independent Tongs L2, and targeted owner-native proof.
- **BUR-0017 and BUR-0018** remain OPEN; only the scoped prerequisite for BUR-0036 was reconciled.
- **Next:** Spoons L1 review of this exact patch, followed by Tongs L2. **Do not automatically bypass BUR-0019's remaining dependencies**; Spoons can separately reconcile the narrow BUR-0018 dependency when needed.
- **Release HOLD.**
