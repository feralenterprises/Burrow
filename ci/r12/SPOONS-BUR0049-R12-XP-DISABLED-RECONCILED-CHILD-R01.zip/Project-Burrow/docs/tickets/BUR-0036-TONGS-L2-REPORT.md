# BUR-0036 | Tongs Independent L2 QA

**Checkpoint:** BUR-0036-TONGS-L2-QA-01  
**Verdict:** **CONDITIONAL L2 PASS** for bounded preparation tooltip source and offline behavior ONLY.  
**Release:** **HOLD**. **Ticket status:** still OPEN; not accepted for native release.  
**Owner-native original defect:** tooltip extended across the game viewport.

## Source identities

| Artifact | SHA-256 |
|---|---|
| TRASHPANDA-TRACKER-INTELLIJ-F06-OWNER-HANDOFF-20261030.zip | `a68aeba08846ab84c758112a6dd388adee3a52a0da8fff8fa54da9bcec31f58e` |
| BUR-0036-SPORKS-F06-TOOLTIP-PATCH.zip | `841498baaadf8223955601953c312e0f3f0686e896d8eb256f43f911026b6cb3` |
| BUR-0036-SPOONS-L1-REVIEW-F06.zip | `f1d53b1c2c13f3261313cea46ad0edc40dd0545b4fe2a84272f8c8bcecffcc35` |
| BUR-0018-SPOONS-L1-DEPENDENCY-RECON-F06.zip | `859a12fc0cd2b50f29c89034f21e796a32ade90f19936b12246226761af3660a` |

Sporks patch inside Spoons L1 is byte-for-byte identical to original Sporks patch.
All 9 declared files in Sporks patch manifest independently match their hashes.
The only existing production source changed is `BurrowPanel.java` and its change is the preparation tooltip return expression. One new production helper (`PreparationTooltip.java`) added; item-name tooltip method, equipment/inventory hitboxes, navigation, data tables and bank code remain unchanged. No release artifact/JAR is claimed.

## What I reran independently

- `javac --release 17` from the reconstructed F06 source plus exact Sporks overlay: **PASS** using **JDK 21.0.12.1**, class major version **61**. **NOT** proof of executing Gradle on actual JDK 17.
- Actual panel `getToolTipText(MouseEvent)` over all **51** registered profile combinations: **PASS** bounded max **213 × 212 px** in headless Swing; comparison prior max width **16,480 px**.
- Existing offline entrypoints: `BurrowHitboxTest`, `Final06CatalogTest` (**6,540 dataset assertions**), `BurrowCoreTest`, `BurrowP1RegressionTest`, `TieredOutfitterTest`, `ApprovedHomeTest`: **PASS**. Together with the tooltip smoke and size comparison, **8 entrypoints passed**.
- Independent adversarial cases: unbroken 9,000-character token, markup/ampersand escaping, 40-item category overload, and empty notes: **PASS** tooltip size limits. Evidence source and result are included.
- Initial offline compile wrongly included a JUnit-dependent class without the JUnit classpath (21 missing JUnit symbols); after separating non-JUnit sources, compile passed. Initial adversarial harness also had an ambiguous `List` import, fixed before the final passed test. Neither represents a production Java failure.
- The actual new `PreparationTooltipJUnitTest` was **NOT EXECUTED**; do not count that as a JUnit PASS.

## Adversarial assessment: what this does NOT prove

1. **BUR-0037 is still open.** `PreparationTooltip.render()` deliberately limits lines and items. It can remove critical preparation details; `See preparation panel` is currently misleading when the original panel is clipped. The patch fixes viewport overflow, **not full-note visibility**.
2. **BUR-0035 remains open.** No visible KBD Wilderness safety callout was added; do not claim safety warning acceptance because string data exists somewhere.
3. **BUR-0019 remains open.** The original gear/inventory tooltip routing is unchanged, but there is no proof tooltips display without pressing Ctrl in native RuneLite. Do not claim ordinary hover fixed.
4. Headless Swing tooltip size is not native Windows rendering at 225px width and different scaling, and does not establish tooltip timing or placement.
5. No true JDK 17 Gradle execution, fresh JUnit report, or new Windows RuneLite confirmation occurred in this L2 review.
6. Earlier mechanical gear/method recommendations are outside BUR-0036 and remain flagged separately.

## Ticket-register reconciliation

- Source of truth for this overlay: Spoons L1 register; 47 IDs `BUR-0001` through `BUR-0047`, next `BUR-0048`, all unique.
- **Only BUR-0036** received an L2 review receipt and conditional status update. Existing BUR-0019 scoped dependency exception was preserved **unchanged**; it remains blocked pending BUR-0036 final acceptance.
- BUR-0017/BUR-0018 remain OPEN. No dependent tickets closed. `release_gate=HOLD` unchanged.
- Do not overwrite newer local ticket changes without comparing the overlay.

## Next gate: real Java 17 and targeted native confirmation

**Build on Windows, using the baseline F06 source with the Sporks patch applied** and the supplied PowerShell helper. Deliver `BUILD SUCCESSFUL` or exact failure logs and JUnit output, pinning the patched source identity. The helper does not declare success if Gradle fails.

Then only one targeted RuneLite check is necessary: open Outfitter, hover the preparation notes where the old enormous line appeared, confirm the preview is readable/bounded without covering game, and send a screenshot if anything differs. A separate no-modifier item hover test belongs to BUR-0019. Do **not** demand the owner redo previously proven RuneLite launch, tabs, bank-button, or basic account tests.

After genuine build and targeted native proof, Spoons updates acceptance evidence and, if cleared, unlocks BUR-0019 Sporks while preserving its own acceptance gates. Release remains HOLD until other defects pass.

**Tongs signoff:** `CONDITIONAL_L2_PASS_BOUNDED_TOOLTIP_SOURCE_OFFLINE_ONLY`. The patch is safe to take to the next validation gate; not approved for release.
