# BUR-0038 | SPOONS Independent L1 review (F06)

**Verdict: PASS for the contained method dropdown patch. Release HOLD.**

## Player-facing change
Outfitter now presents a recognizable METHOD dropdown with full registered names instead of hidden click-to-cycle text. Dagannoth Kings gives Rex safespot with Guthan healing switch, Prime ranged, and Supreme melee. Selecting any option updates the method plan while keeping boss and Entry/Recommended/Optimal tier.

This **does not** implement missing Scurrius, Giant Mole, or Hueycoatl combat styles; BUR-0034 still owns vetted method expansion.

## Independent review scope
- Frozen source archive `BUR-0037-SPOONS-L1-INTEGRATED-R02.zip`, SHA256 `d1f37bba5194de83a8050aae2e99180e99e3b5db0fc66f4dccb57f46e5d0bcf9` confirmed.
- Sporks patch `BUR-0038-SPORKS-METHOD-DROPDOWN-PATCH-F06.zip`, SHA256 `95af9a79c966e5dc33e6b2da33f6c25c5154af89d9543620b3767d8bb9034249` confirmed.
- Production modification limited to `BurrowPanel.java`. `TieredOutfitterTest.java` updated; `OutfitterMethodDropdownTest.java` and `OutfitterMethodDropdownJUnitTest.java` added. Old/new file hashes match manifest.
- Reconstructed project preserves every other original project file before the L1 ticket/board updates. Canonical FINAL-06 JSON is byte-identical. All 48 original IDs unique, next unused BUR-0049; 33 board entries preserved.
- Native Swing `JPopupMenu` with `JRadioButtonMenuItem` and selection handlers is connected to `model.methods()` and `model.chooseMethod()`. `clickAt` no longer cycles methods. No synthetic styles inserted.
- Independent offline compile with OpenJDK 21 `--release 17` succeeded; **19 of 19** standalone regression programs passed. Test classpath setup initially included tests needing unavailable RuneLite/JUnit libraries; rerun correctly with dependency-free offline test list, full result stored.
- Limitations: JDK 21 target-bytecode checks are not a genuine JDK 17 Gradle build; no native RuneLite proof, no independent Tongs L2 yet. Swing popup screen-edge placement is only proven by offline component/menu tests, not on the owner's client.
- Remaining issue BUR-0037: raw JSON switching instructions need human-friendly rendering. Other unresolved owner-facing tickets preserved.

## Next dispatch
Data lane: **Noodles BUR-0022** Scurrius Wiki Recommended pilot validation/repair, producing a concrete canonical 11-slot/28-slot player-facing profile and prerequisite evidence while preserving existing 51 plans; then **BUR-0021** inventory quality and **BUR-0034** alternate combat styles after dependency gates. No batch-native testing requests until all 33 player-facing tickets have been worked on and feasible changes integrated. UI lane may separately continue BUR-0037 raw-JSON readability; keep a single UI editor and integrate sequentially.
