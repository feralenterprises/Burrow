# BUR-0039 | Noodles Muspah gear correction

**Release HOLD. Scope: existing Phantom Muspah Ranged method, three existing tiers only.**

## Source lineage

- Original F06 owner ZIP SHA-256: `a68aeba08846ab84c758112a6dd388adee3a52a0da8fff8fa54da9bcec31f58e`
- Input candidate (includes prior BUR-0036 tooltip patch) SHA-256: `7472d5805b6a461448b4213d0d325e99736a961bf7acbf816c2230b0453accd6`
- Reconciled research archive BUR-0046 Spoons: `f7e5f6880e2811dae6c9d9cbf2cc0f4d296e6f8b4b444873cbe973ebf3aeac36`
- Original FINAL-06 resource: `98e53286e043c8308f496741ed6883c2eda1299203340662e4d816f441a56631`
- BUR-0039 patched F06-derived resource: `3cb0ac8099fab07f8e9e216fcdafb904332c8f06c9f8cdbc259683bc5dd7691f`
- Other 48 profiles, Optimal Muspah, all 51 inventories, method names and inventory geometry: **unchanged**. This is a **derived candidate**, not a rewrite of the original canonical research archive.

## Concrete corrected equipment

| Tier | Before | After | Rationale |
|---|---|---|---|
| Entry | Coif (1169) | Archer helm (3749) | +6 vs +2 Ranged attack; 45 Defence and Fremennik Trials required |
| Entry | Fury (6585) | Glory (1704) | Less extreme acquisition than onyx Fury, with Ranged stats; optional ownership alternatives remain |
| Entry | No offhand with Rune crossbow | Black d'hide shield (22284) | Rune crossbow is one-handed; shield offers +7 Ranged accuracy; 70 Ranged/40 Defence, 83 Crafting to self-craft |
| Entry | Barrows gloves (7462) | Black d'hide vambraces (2491) | 70 Ranged wear requirement, consistent with existing 70-Ranged d'hide body/chaps; removes RFD gate |
| Recommended | Dragon boots (11840) | Saradomin d'hide boots (19933) | Blessed Ranged boots; 70 Ranged/40 Defence; other blessed d'hide colors functionally equivalent |
| Recommended | Empty Bowfa offhand | **Still empty** | Two-handed Bowfa cannot equip shield simultaneously |
| Optimal | Tbow plus empty offhand | **Unchanged** | Two-handed Tbow; ZCB/sapphire dragon bolts switch retained |

All gear IDs were checked against `BUR-RUNELITE-1.13.4-ITEMIDS.txt` and OSRS Wiki item pages. Changes were mirrored in `gear`, `equipment_slots`, generated `TieredOutfitterCatalog.java`, metadata, requirement registry, and fixture. The Java catalog is what RuneLite actually renders, so updating only JSON would **not** be sufficient.

## Checks run in this environment

- JDK 21 `javac --release 17` compile: **PASS**, not genuine JDK 17 Gradle.
- 12 offline Java regression mains: **PASS**.
- `MuspahGearRegressionTest`: 18 assertions PASS.
- `Final06CatalogTest`: 6540 assertions PASS across 51 profiles, with new F06-derived SHA.
- `TieredOutfitterTest`: 3654 assertions PASS, including combat selection and slot geometry.
- JUnit wrapper added but **not executed** (requires genuine JDK 17 Gradle/JUnit).
- No native RuneLite session claimed.
- Original input Java 17 Gradle acceptance still pending on Windows.

## Other Ranged profiles reviewed, NOT changed

- Vorkath Recommended boots: Dragon boots melee Strength, no Ranged offence; review Ranged-specific alternatives
- Dagannoth Kings Entry shield: One-handed crossbow; verify an available Ranged offhand or defensible empty-slot reason
- Dagannoth Kings Recommended boots: Dragon boots melee Strength, no Ranged offence; review Ranged-specific alternatives

These should be separately triaged under BUR-0039 expanded cross-boss audit or a new uniquely numbered follow-up **only after Spoons checks register duplication**. No extra source edits authorized.

## Mechanical sources

- https://oldschool.runescape.wiki/w/Phantom_Muspah/Strategies
- https://oldschool.runescape.wiki/w/Armour/Ranged_armour
- https://oldschool.runescape.wiki/w/The_Fremennik_Trials
- https://oldschool.runescape.wiki/w/Black_d%27hide_shield
- https://oldschool.runescape.wiki/w/Black_d%27hide_vambraces
- https://oldschool.runescape.wiki/w/Saradomin_d%27hide_boots
- https://oldschool.runescape.wiki/w/Amulet_of_glory

## Implementation and scope

This is a **merge-overlay patch** for the **BUR-0036-JAVA17-VERIFY-READY-F06.zip** source only; extract into a copy of the matching `Project-Burrow` directory. Do not blindly apply to a different regenerated source. No plugins, run logic, user-owned bank data, or other boss profiles were changed. The original FINAL-06 archive remains unchanged; the patched candidate intentionally uses a new dataset hash in Java and tests.

**Required next gates:** Spoons L1 independently reviews source diff, item gates, old vs new fixtures and no unrelated changes; then Tongs L2; genuine JDK 17 `gradlew.bat clean test jar` and narrow native Muspah Entry/Recommended inspection. BUR-0036 Windows/native acceptance stays separate. Release HOLD.

**Next dispatch:** BUR-0039 Spoons L1 source/data audit.
