param()
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$logs = Join-Path $projectRoot 'build\bur0036-validation'
New-Item -Path $logs -ItemType Directory -Force | Out-Null
Set-Location $projectRoot
& java -version 2>&1 | Out-File (Join-Path $logs 'java-version.log')
& .\gradlew.bat --version 2>&1 | Out-File (Join-Path $logs 'gradle-version.log')
Write-Host 'JAVA 17 REQUIRED. Check build/bur0036-validation/gradle-version.log reports JVM: 17.'
& .\gradlew.bat --no-daemon clean test jar 2>&1 | Tee-Object -FilePath (Join-Path $logs 'gradle-clean-test-jar.log')
$exitCode = $LASTEXITCODE
if ($exitCode -ne 0) { Write-Host "FAIL: Gradle exited $exitCode. Save logs."; exit $exitCode }
Write-Host 'BUILD COMMAND PASSED. Native RuneLite hover check and independent acceptance still pending.'
Write-Host "Evidence directory: $logs"
