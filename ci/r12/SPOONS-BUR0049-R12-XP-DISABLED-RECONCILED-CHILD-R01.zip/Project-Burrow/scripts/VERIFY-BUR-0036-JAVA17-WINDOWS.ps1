# BUR-0036 / genuine Java 17 Windows build evidence collector
# Read-only on production source and registers; writes solely to build/bur0036-validation.
# A Gradle BUILD SUCCESSFUL is NOT native RuneLite confirmation.
$ErrorActionPreference = 'Continue'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$folder = Join-Path $root 'build\bur0036-validation'
New-Item -ItemType Directory -Path $folder -Force | Out-Null
Set-Location $root
$expectedPanel = 'f6b34166df641ab0075ab10fb555357523e338cca297b9dd6b4699e9ce953c8c'
$expectedHelper = 'f5e21f847d2696a78fa36278456d83f3163763e42b25757a4d6b28b94f3cf3c2'
function ReceiptError([string]$message, [int]$exitCode=1) {
    ('FAIL: ' + $message) | Tee-Object -FilePath (Join-Path $folder 'RESULT.txt')
    Write-Host ('Evidence directory: ' + $folder)
    exit $exitCode
}
$panel = Join-Path $root 'src\main\java\gg\feral\burrow\ui\BurrowPanel.java'
$helper = Join-Path $root 'src\main\java\gg\feral\burrow\ui\PreparationTooltip.java'
if (-not (Test-Path $panel) -or -not (Test-Path $helper)) { ReceiptError 'Patched source files not found. Open the inner Project-Burrow folder.' }
$panelHash = (Get-FileHash -Algorithm SHA256 $panel).Hash.ToLowerInvariant()
$helperHash = (Get-FileHash -Algorithm SHA256 $helper).Hash.ToLowerInvariant()
"BurrowPanel.java SHA256: $panelHash`nPreparationTooltip.java SHA256: $helperHash" | Set-Content -Path (Join-Path $folder 'source-hashes.txt')
if ($panelHash -ne $expectedPanel -or $helperHash -ne $expectedHelper) {
    ReceiptError 'Source hashes differ from reviewed BUR-0036 candidate; do not overwrite local changes.'
}
if (-not (Test-Path (Join-Path $root 'gradlew.bat'))) { ReceiptError 'gradlew.bat missing from Project-Burrow root.' }
if (-not (Get-Command java -ErrorAction SilentlyContinue)) { ReceiptError 'java not on PATH. Set Gradle JVM / JAVA_HOME to JDK 17.' }
if (-not (Get-Command javac -ErrorAction SilentlyContinue)) { ReceiptError 'javac not on PATH. A JDK 17, not only a JRE, is required.' }
& java -version *>&1 | Out-File (Join-Path $folder 'java-version.log')
$javaOutput = Get-Content -Raw (Join-Path $folder 'java-version.log')
& javac -version *>&1 | Out-File (Join-Path $folder 'javac-version.log')
$javacOutput = Get-Content -Raw (Join-Path $folder 'javac-version.log')
if ($javaOutput -notmatch '(?m)\bversion\s+"17(?:[.\+\-\"]|$)' -or $javacOutput -notmatch '(?m)\bjavac\s+17(?:[.\+\-]|$)') {
    ReceiptError 'Java 17 and javac 17 required. Inspect java-version.log and javac-version.log.'
}
& .\gradlew.bat --version *>&1 | Tee-Object -FilePath (Join-Path $folder 'gradle-version.log')
$preflightExit = $LASTEXITCODE
if ($preflightExit -ne 0) { ReceiptError ('Gradle version preflight failed with exit code ' + $preflightExit) $preflightExit }
$gradleInfo = Get-Content -Raw (Join-Path $folder 'gradle-version.log')
if ($gradleInfo -notmatch '(?mi)^\s*(?:Launcher JVM|JVM):\s*17(?:[.\+\s]|$)') {
    ReceiptError 'Gradle is not running on JDK 17; see gradle-version.log. Set IntelliJ Gradle JVM to JDK 17.'
}
& .\gradlew.bat --no-daemon clean test jar *>&1 | Tee-Object -FilePath (Join-Path $folder 'gradle-clean-test-jar.log')
$gradleExit = $LASTEXITCODE
if ($gradleExit -ne 0) { ReceiptError ('Gradle clean test jar failed with exit code ' + $gradleExit) $gradleExit }
$gradleText = Get-Content -Raw (Join-Path $folder 'gradle-clean-test-jar.log')
if ($gradleText -notmatch '\bBUILD SUCCESSFUL\b') { ReceiptError 'Gradle exited zero but BUILD SUCCESSFUL was not in the captured log.' }
$xmlDir = Join-Path $root 'build\test-results\test'
$reports = @(Get-ChildItem -Path $xmlDir -Filter 'TEST-*.xml' -ErrorAction SilentlyContinue)
if ($reports.Count -eq 0) { ReceiptError 'BUILD SUCCESSFUL but no JUnit TEST-*.xml reports; test execution is not verified.' }
$summary = [ordered]@{ jdk='17'; build='BUILD SUCCESSFUL'; reports=$reports.Count; tests=0; failures=0; errors=0; skipped=0; tooltip_tests=0; jars=@() }
foreach($report in $reports) {
    [xml]$doc = Get-Content -Raw $report.FullName
    foreach($suite in @($doc.testsuite)) {
        $summary.tests += [int]$suite.tests
        $summary.failures += [int]$suite.failures
        $summary.errors += [int]$suite.errors
        $summary.skipped += [int]$suite.skipped
        if ($report.Name -match 'PreparationTooltipJUnitTest') { $summary.tooltip_tests += [int]$suite.tests }
    }
}
$jarFolder = Join-Path $root 'build\libs'
$jars = @(Get-ChildItem -Path $jarFolder -Filter '*.jar' -ErrorAction SilentlyContinue)
foreach($jar in $jars) {
    $summary.jars += [ordered]@{file=$jar.Name;bytes=$jar.Length;sha256=(Get-FileHash -Algorithm SHA256 $jar.FullName).Hash.ToLowerInvariant()}
}
$summary | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 (Join-Path $folder 'junit-and-jar-summary.json')
if ($summary.failures -ne 0 -or $summary.errors -ne 0) { ReceiptError 'JUnit reports include failing/error tests.' }
if ($summary.tooltip_tests -lt 4) { ReceiptError 'Fewer than 4 BUR-0036 JUnit cases observed in the JUnit XML.' }
if ($jars.Count -eq 0) { ReceiptError 'No compiled JAR was found in build/libs.' }
'BUILD SUCCESSFUL - JAVA17/JUNIT/JAR EVIDENCE COLLECTED. NATIVE RUNELITE: NOT YET VERIFIED. RELEASE HOLD.' | Tee-Object -FilePath (Join-Path $folder 'RESULT.txt')
Write-Host ''
Write-Host 'Send RESULT.txt, gradle-clean-test-jar.log and junit-and-jar-summary.json from:'
Write-Host $folder
Write-Host 'Then perform ONLY the previously targeted preparation-tooltip hover check in RuneLite.'
