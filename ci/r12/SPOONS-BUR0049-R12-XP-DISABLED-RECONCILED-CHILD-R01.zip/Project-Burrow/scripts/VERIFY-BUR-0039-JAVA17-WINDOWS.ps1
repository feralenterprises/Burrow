# BUR-0039 Windows genuine Java 17 evidence collector. Source read-only.
# Evidence deliberately saved OUTSIDE build/, to survive Gradle clean.
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location $root
$evidence = Join-Path $root 'BUR-0039-WINDOWS-EVIDENCE'
$bundle = Join-Path $root 'BUR-0039-WINDOWS-EVIDENCE.zip'
New-Item -ItemType Directory -Path $evidence -Force | Out-Null
$expected = @{
  'BURROW-TICKETS.json' = '92372afbd56588e0123f508207fa6da5120d2f6079be5df7fa9d797fff7fe5e7'
  'src\main\java\gg\feral\burrow\core\TieredOutfitterCatalog.java' = 'a72a308aa3f159dcb6ee0633a7a3f47cd569db8b24d9ffedf2ee076d1e92c6c3'
  'src\main\java\gg\feral\burrow\core\Final06ProfileMetadata.java' = 'cc2effdc02aeab0e4e31703493d260cfe875fffb3e941f5aea50989f4eb74e3d'
  'src\main\resources\gg\feral\burrow\outfitter\BUR-OUTFITTER-MASTER-FINAL-06-LOADOUTS.json' = '428aebc418c65169b48ab4684b48358d792da9051086b598bbb670bdf8d2abe9'
  'src\main\resources\gg\feral\burrow\outfitter\BUR-OUTFITTER-MASTER-FINAL-06-ITEM-REQUIREMENTS.json' = '7d416ab8f74efb40990c00d76c76268acfd68275f966e9b46baa80d87fad8e03'
  'src\main\java\gg\feral\burrow\ui\BurrowPanel.java' = 'f6b34166df641ab0075ab10fb555357523e338cca297b9dd6b4699e9ce953c8c'
  'src\main\java\gg\feral\burrow\ui\PreparationTooltip.java' = 'f5e21f847d2696a78fa36278456d83f3163763e42b25757a4d6b28b94f3cf3c2'
  'src\test\java\gg\feral\burrow\core\MuspahGearJUnitTest.java' = '75a6a7896a7a33c9f394ec907394a9a0b357eeaecd5052e8d56cf69ba2a69594'
  'src\test\java\gg\feral\burrow\ui\PreparationTooltipJUnitTest.java' = 'aaa3a47475d589c151c6b7e5ec95761146f96de6b0d543d99aa5098f08207274'
  'scripts\generate-final06.py' = 'd1aac00837adf109885ed12cf93087e119431ec275c824b7f62bfafaefc0a5a1'
  'scripts\verify-final06.py' = 'f2a1ca28d18beaace8a9e46b21b8c91fa3c4c23fb64c352965debf5949ba563d'
}
function Seal-Evidence {
  try {
    if (Test-Path $bundle) { Remove-Item $bundle -Force }
    Compress-Archive -Path (Join-Path $evidence '*') -DestinationPath $bundle -Force
    Write-Host "Evidence ZIP: $bundle"
  } catch { Write-Warning "Could not ZIP evidence: $_. Send the folder $evidence instead." }
}
function Stop-Verification([string]$message,[int]$code=1) {
  ('FAIL: ' + $message) | Set-Content -Encoding UTF8 (Join-Path $evidence 'RESULT.txt')
  Write-Host ('FAIL: ' + $message)
  Seal-Evidence
  exit $code
}
try {
  $results = @()
  foreach($relative in ($expected.Keys | Sort-Object)) {
    $full = Join-Path $root $relative
    if (-not (Test-Path -LiteralPath $full)) { Stop-Verification ("Required source missing: " + $relative) }
    $actual = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToLowerInvariant()
    $results += [pscustomobject]@{path=$relative;expected=$expected[$relative];actual=$actual;matches=($actual -eq $expected[$relative])}
  }
  $results | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 (Join-Path $evidence 'source-hashes.json')
  if (@($results | Where-Object {-not $_.matches}).Count -gt 0) { Stop-Verification 'Reviewed source SHA256 mismatch. Do not build a mixed candidate.' }
  if (-not (Test-Path .\gradlew.bat)) { Stop-Verification 'gradlew.bat missing. Open the inner Project-Burrow folder.' }
  if (-not (Get-Command java -ErrorAction SilentlyContinue)) { Stop-Verification 'java is not on PATH. Configure JDK17.' }
  if (-not (Get-Command javac -ErrorAction SilentlyContinue)) { Stop-Verification 'javac is not on PATH. Configure a full JDK17.' }
  $javaText = (& cmd.exe /d /c 'java -version 2>&1' | Out-String)
  $javaText | Set-Content -Encoding UTF8 (Join-Path $evidence 'java-version.log')
  $javacText = (& cmd.exe /d /c 'javac -version 2>&1' | Out-String)
  $javacText | Set-Content -Encoding UTF8 (Join-Path $evidence 'javac-version.log')
  if ($javaText -notmatch '(?i)(?:openjdk|java) version "17(?:[.\+\-]|\")' -or $javacText -notmatch '(?im)\bjavac\s+17(?:[.\+\-\s]|$)') {
    Stop-Verification 'Actual JDK17 java and javac are required, not JDK21 with --release 17.'
  }
  & cmd.exe /d /c 'gradlew.bat --version 2>&1' | Tee-Object -FilePath (Join-Path $evidence 'gradle-version.log')
  $gradleVersionExit=$LASTEXITCODE
  if ($gradleVersionExit -ne 0) { Stop-Verification "Gradle --version failed (exit $gradleVersionExit)" $gradleVersionExit }
  $gradleVersion=Get-Content -Raw (Join-Path $evidence 'gradle-version.log')
  if ($gradleVersion -notmatch '(?mi)^\s*(?:Launcher JVM|JVM):\s*17(?:[.\+\-\s]|$)') {
    Stop-Verification 'Gradle JVM is not Java17. Set Gradle JVM and JAVA_HOME to JDK17.'
  }
  Write-Host 'Running genuine JDK17 Gradle clean test jar...'
  & cmd.exe /d /c 'gradlew.bat --no-daemon clean test jar 2>&1' | Tee-Object -FilePath (Join-Path $evidence 'gradle-clean-test-jar.log')
  $gradleExit=$LASTEXITCODE
  if ($gradleExit -ne 0) { Stop-Verification "Gradle build failed (exit $gradleExit). See captured log." $gradleExit }
  $gradleText=Get-Content -Raw (Join-Path $evidence 'gradle-clean-test-jar.log')
  if ($gradleText -notmatch 'BUILD SUCCESSFUL') { Stop-Verification 'Gradle exited zero without a captured BUILD SUCCESSFUL.' }
  $testDir=Join-Path $root 'build\test-results\test'
  $reports=@(Get-ChildItem -Path $testDir -Filter 'TEST-*.xml' -ErrorAction SilentlyContinue)
  if ($reports.Count -eq 0) { Stop-Verification 'No actual JUnit XML reports found.' }
  $summary=[ordered]@{jdk='17';gradle='BUILD SUCCESSFUL';reports=$reports.Count;tests=0;failures=0;errors=0;skipped=0;muspahJUnit=0;tooltipJUnit=0;jars=@()}
  foreach($report in $reports) {
    [xml]$doc=Get-Content -Raw $report.FullName
    $suite=$doc.testsuite
    if ($null -eq $suite) { Stop-Verification "Invalid JUnit XML: $($report.Name)" }
    $summary.tests += [int]$suite.tests
    $summary.failures += [int]$suite.failures
    $summary.errors += [int]$suite.errors
    $summary.skipped += [int]$suite.skipped
    if ($report.Name -match 'MuspahGearJUnitTest') { $summary.muspahJUnit += [int]$suite.tests }
    if ($report.Name -match 'PreparationTooltipJUnitTest') { $summary.tooltipJUnit += [int]$suite.tests }
    Copy-Item -LiteralPath $report.FullName -Destination (Join-Path $evidence $report.Name)
  }
  foreach($jar in @(Get-ChildItem -Path (Join-Path $root 'build\libs') -Filter '*.jar' -ErrorAction SilentlyContinue)) {
    $summary.jars += [ordered]@{file=$jar.Name;bytes=$jar.Length;sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $jar.FullName).Hash.ToLowerInvariant()}
  }
  $summary | ConvertTo-Json -Depth 7 | Set-Content -Encoding UTF8 (Join-Path $evidence 'junit-and-jar-summary.json')
  if ($summary.failures -ne 0 -or $summary.errors -ne 0) { Stop-Verification 'JUnit XML reports contain failures or errors.' }
  if ($summary.tests -lt 1 -or $summary.muspahJUnit -lt 1 -or $summary.tooltipJUnit -lt 1) {
    Stop-Verification 'Required MuspahGearJUnitTest or PreparationTooltipJUnitTest did not execute.'
  }
  if ($summary.jars.Count -lt 1) { Stop-Verification 'No JAR in build/libs after successful Gradle jar task.' }
  'BUILD SUCCESSFUL; JDK17/Gradle/JUnit/JAR verified locally. NATIVE RUNELITE NOT VERIFIED. RELEASE HOLD.' | Set-Content -Encoding UTF8 (Join-Path $evidence 'RESULT.txt')
  Write-Host 'PASS: Actual JDK17 Gradle tests and JAR receipts captured. Native RuneLite still unverified.'
  Seal-Evidence
} catch {
  Stop-Verification ("Unexpected collector error: " + $_.Exception.Message)
}
