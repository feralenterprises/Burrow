#!/usr/bin/env python3
"""BUR-0046 read-only catalog coverage guard. NO production data mutations.

Usage: python3 scripts/audit-bur0046-coverage.py [path-to-source-loadouts-json]
Only checks registered method/tier structure against the independently published
matrix. MISSING is advisory research, never generated profile data.
"""
from collections import defaultdict
from pathlib import Path
import csv
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
DATA = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'src/main/resources/gg/feral/burrow/outfitter/BUR-OUTFITTER-MASTER-FINAL-06-LOADOUTS.json'
MATRIX = ROOT / 'docs/audits/BUR-0046-METHOD-COVERAGE-MATRIX.csv'
records = json.loads(DATA.read_text(encoding='utf8'))['profiles']
assert len(records) == 51, f'Expected 51 original tiers; got {len(records)}'
assert all(len(p['gear']) == 11 and len(p['inventory']) == 28 for p in records)
index = defaultdict(lambda: defaultdict(dict))
for p in records:
    by_tier = index[p['boss']][p['method']]
    assert p['tier'] not in by_tier, f"Duplicate: {p['boss']} / {p['method']} / {p['tier']}"
    by_tier[p['tier']] = p['style']
assert len(index) == 15
assert sum(map(len, index.values())) == 17
assert all(set(tiers) == {'Entry', 'Recommended', 'Optimal'} and len(set(tiers.values())) == 1
           for methods in index.values() for tiers in methods.values())
with MATRIX.open(newline='', encoding='utf8') as f:
    rows = list(csv.DictReader(f))
assert len(rows) == 15 and {r['boss'] for r in rows} == set(index), 'Boss matrix drift'
assert sum(int(r['registered_methods']) for r in rows) == 17
valid = {'PASS', 'MISSING', 'NOT_RECOMMENDED', 'NOT_SUPPORTED'}
for r in rows:
    registered = {next(iter(tiers.values())) for tiers in index[r['boss']].values()}
    assert all(r[style.lower()] in valid for style in ('Melee','Ranged','Magic'))
    matrix_present = {style for style in ('Melee','Ranged','Magic') if r[style.lower()] == 'PASS'}
    assert registered == matrix_present, f"Registered/matrix mismatch for {r['boss']}: {registered} != {matrix_present}"
print('BUR-0046 READ-ONLY STRUCTURE PASS: 15 bosses / 17 methods / 51 profiles / 3 tiers per method')
print('Actual combat-game feasibility requires independent cited research; not proven by this script.')
