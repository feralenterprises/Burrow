#!/usr/bin/env python3
"""Curated quality pass over all 51 R06 profiles, preserving the R06 source."""
import copy, hashlib, importlib.util, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('tier3',ROOT/'scripts/build-tier-r06.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
parent=ROOT/'docs/research/BUR-OUTFITTER-WIKI-TIERS-03-R06.json'
data=json.loads(parent.read_text());assert len(data['profiles'])==51
P=data['profiles']
G=m.G

def gear(row,patch):
    for pos,pair in patch.items():
        row['gear'][pos-1]=G(*pair) if pair else None
def inv(row,recipe):
    items=[]
    for code,count in recipe:
        if code in m.C:
            items.extend(m.I(code) for _ in range(count))
        else:
            name,constant,qty=code
            items.append(G(name,constant,qty))
    assert len(items)<=28,(row['boss'],row['method'],row['tier'],len(items))
    row['inventory']=items+[None]*(28-len(items))
def R(*parts):return parts
def K(row):
    if row['boss']=='Dagannoth Kings':return 'DK '+row['method'].split(',')[0].split(' ')[0]
    return row['boss']

# Each row has an explicit short-trip supply budget. The food quantity is a
# starting recommendation, not a claim of exact Wiki cell placement or kills.
SUP={
'Scurrius':{
 'Entry':R(('str',1),('atk',1),('p',2),('sh',8),('kw',2),('bronze',1),('house',1)),
 'Recommended':R(('sc',1),('p',2),('sh',7),('kw',2),('house',1)),
 'Optimal':R(('sc',1),('p',2),('sh',5),('kw',2),('house',1))},
'Brutus':{
 'Entry':R(('str',1),('tr',10),('cow',1)),
 'Recommended':R(('str',1),('sw',8),('cow',1)),
 'Optimal':R(('str',1),('sw',6),('cow',1))},
'Giant Mole':{
 'Entry':R(('sc',1),('p',4),('en',2),('sh',8),('spade',1),('light',1),('fala',1),('house',1)),
 'Recommended':R(('sc',1),('p',4),('stam',1),('sh',6),('spade',1),('fs3',1),('light',1),('house',1)),
 'Optimal':R(('dsc',1),('p',4),('stam',1),('sh',4),('spade',1),('fs4',1),('light',1),('house',1))},
'Vorkath':{
 'Entry':R((('Diamond bolts (e)','DIAMOND_BOLTS_E',150),1),('saf',1),('av',1),('rng',1),('p',3),('sh',11),('kw',2),('pouch',1),('house',1)),
 'Recommended':R((('Diamond dragon bolts (e)','DIAMOND_DRAGON_BOLTS_E',150),1),('saf',1),('av',1),('rng',1),('p',3),('sh',9),('kw',2),('pouch',1),('house',1)),
 'Optimal':R((('Diamond dragon bolts (e)','DIAMOND_DRAGON_BOLTS_E',150),1),('saf',1),('av',1),('drng',1),('p',3),('sh',7),('kw',2),('pouch',1),('house',1))},
'Phantom Muspah':{
 'Entry':R((('Sapphire bolts (e)','SAPPHIRE_BOLTS_E',150),1),('rng',1),('stam',1),('p',4),('sh',10),('kw',2),('house',1)),
 'Recommended':R(('crystalbow',1),(('Sapphire bolts (e)','SAPPHIRE_BOLTS_E',150),1),('rng',1),('stam',1),('p',4),('sh',8),('kw',2),('house',1)),
 'Optimal':R(('zcb',1),(('Sapphire dragon bolts (e)','SAPPHIRE_DRAGON_BOLTS_E',150),1),('drng',1),('stam',1),('p',4),('sh',7),('kw',2),('house',1))},
'Sarachnis':{
 'Entry':R(('sc',1),('p',3),('sh',10),('kw',2),('wsword',1),('house',1)),
 'Recommended':R(('sc',1),('p',3),('sh',8),('kw',2),('house',1)),
 'Optimal':R(('dsc',1),('p',3),('sh',7),('kw',2),('house',1))},
'Hueycoatl':{
 'Entry':R(('sc',1),('p',3),('sh',9),(('Glacial temotli','GLACIAL_TEMOTLI',1),1),('house',1)),
 'Recommended':R(('sc',1),('p',4),('sh',7),('dual',1),('bmhelm',1),('bmbody',1),('bmlegs',1),('house',1)),
 'Optimal':R(('dsc',1),('p',4),('sh',6),('dual',1),('bmhelm',1),('bmbody',1),('bmlegs',1),('house',1))},
'Amoxliatl':{
 'Entry':R(('sc',1),('p',2),('sh',8),('kw',2),('house',1)),
 'Recommended':R(('sc',1),('p',2),('sh',6),('kw',2),('house',1)),
 'Optimal':R(('dsc',1),('p',2),('sh',5),('kw',2),('house',1))},
'King Black Dragon':{
 'Entry':R((('Diamond bolts (e)','DIAMOND_BOLTS_E',150),1),('anti',1),('af',1),('rng',1),('p',3),('sh',12),('burn',1),('house',1)),
 'Recommended':R((('Diamond bolts (e)','DIAMOND_BOLTS_E',150),1),('anti',1),('af',1),('rng',1),('p',3),('sh',10),('burn',1),('house',1)),
 'Optimal':R((('Diamond dragon bolts (e)','DIAMOND_DRAGON_BOLTS_E',150),1),('anti',1),('af',1),('drng',1),('p',3),('sh',9),('burn',1),('house',1))},
'Grotesque Guardians':{
 'Entry':R(('atlatl',1),(('Atlatl dart','ATLATL_DART',300),1),('sc',1),('rng',1),('p',3),('sh',8),('kw',2),('house',1)),
 'Recommended':R(('atlatl',1),(('Atlatl dart','ATLATL_DART',300),1),('sc',1),('rng',1),('p',3),('sh',7),('kw',2),('house',1)),
 'Optimal':R(('atlatl',1),(('Atlatl dart','ATLATL_DART',300),1),('dsc',1),('drng',1),('p',3),('sh',6),('kw',2),('house',1))},
'Barrows':{
 'Entry':R((('Death rune','DEATH_RUNE',350),1),(('Fire rune','FIRE_RUNE',700),1),('p',2),('sh',8),('spade',1),('house',1)),
 'Recommended':R(('p',2),('sh',7),('spade',1),('house',1)),
 'Optimal':R(('p',2),('sh',6),('spade',1),('house',1))},
'DK Rex':{
 'Entry':R((('Death rune','DEATH_RUNE',350),1),(('Fire rune','FIRE_RUNE',700),1),('anti',2),('p',4),('stam',1),('sh',8),('pet',1),('thrown',1),('house',1)),
 'Recommended':R(('healing',1),('anti',2),('p',4),('stam',1),('sh',6),('pet',1),('thrown',1),('house',1)),
 'Optimal':R(('anti',2),('p',4),('stam',1),('sh',5),('pet',1),('thrown',1),('house',1))},
'Zulrah':{
 'Entry':R((('Death rune','DEATH_RUNE',350),1),(('Fire rune','FIRE_RUNE',700),1),('av',1),('p',2),('sh',10),('ringd',1)),
 'Recommended':R(('av',1),('p',2),('sh',8),('ringd',1),('zul',1)),
 'Optimal':R(('av',1),('p',2),('sh',7),('ringd',1),('zul',1))},
'DK Prime':{
 'Entry':R((('Diamond bolts (e)','DIAMOND_BOLTS_E',150),1),('anti',2),('p',4),('stam',1),('sh',8),('pet',1),('thrown',1),('house',1)),
 'Recommended':R(('anti',2),('p',4),('stam',1),('sh',7),('pet',1),('thrown',1),('house',1)),
 'Optimal':R(('anti',2),('p',4),('stam',1),('sh',6),('pet',1),('thrown',1),('house',1))},
'DK Supreme':{
 'Entry':R(('anti',2),('p',4),('stam',1),('sh',8),('pet',1),('thrown',1),('house',1)),
 'Recommended':R(('anti',2),('p',4),('stam',1),('sh',7),('pet',1),('thrown',1),('house',1)),
 'Optimal':R(('anti',2),('p',4),('stam',1),('sh',6),('pet',1),('thrown',1),('house',1))},
'Obor':{
 'Entry':R(('keyg',1),('str',1),('sw',12)),
 'Recommended':R(('keyg',1),('sc',1),('p',1),('mf',8),('house',1)),
 'Optimal':R(('keyg',1),('sc',1),('p',1),('sh',6),('house',1))},
'Bryophyta':{
 'Entry':R(('keym',1),('axe',1),('str',1),('sw',12)),
 'Recommended':R(('keym',1),('axe',1),('ap',1),('sc',1),('p',2),('mf',8),('house',1)),
 'Optimal':R(('keym',1),('axe',1),('ap',1),('sc',1),('p',2),('sh',6),('house',1))},
}

# One-indexed equipment slots: head, cape, neck, ammo, weapon, body, offhand,
# legs, gloves, boots, ring. Omitted cells inherit R06 then undergo review.
GEAR={
'Scurrius':{
 'Entry':{2:('Red cape','RED_CAPE'),4:None,7:('Rune kiteshield','RUNE_KITESHIELD')},
 'Recommended':{1:('Helm of Neitiznot','HELM_OF_NEITIZNOT'),6:('Fighter torso','FIGHTER_TORSO'),8:('Obsidian platelegs','OBSIDIAN_PLATELEGS'),9:('Barrows gloves','BARROWS_GLOVES')},
 'Optimal':{1:('Neitiznot faceguard','NEITIZNOT_FACEGUARD'),3:('Amulet of torture','AMULET_OF_TORTURE'),6:('Bandos chestplate','BANDOS_CHESTPLATE'),8:('Bandos tassets','BANDOS_TASSETS'),10:('Dragon boots','DRAGON_BOOTS'),11:('Berserker ring (i)','BERSERKER_RING_I')}},
'Brutus':{
 'Entry':{1:('Adamant full helm','ADAMANT_FULL_HELM'),5:('Adamant scimitar','ADAMANT_SCIMITAR'),6:('Adamant chainbody','ADAMANT_CHAINBODY'),7:('Adamant kiteshield','ADAMANT_KITESHIELD'),8:('Adamant plateskirt','ADAMANT_PLATESKIRT')},
 'Recommended':{7:('Rune kiteshield','RUNE_KITESHIELD'),9:('Leather gloves','LEATHER_GLOVES'),10:('Fancy boots','FANCY_BOOTS')},
 'Optimal':{7:('Mooleta','MOOLETA'),9:('Leather gloves','LEATHER_GLOVES'),10:('Fancy boots','FANCY_BOOTS')}},
'Giant Mole':{
 'Entry':{1:('Rune full helm','RUNE_FULL_HELM'),2:('Ardougne cloak 2','ARDOUGNE_CLOAK_2'),4:None,5:('Dragon dagger','DRAGON_DAGGER')},
 'Recommended':{5:('Zombie axe','ZOMBIE_AXE'),6:('Proselyte hauberk','PROSELYTE_HAUBERK'),8:('Proselyte cuisse','PROSELYTE_CUISSE'),11:None},
 'Optimal':{1:('Neitiznot faceguard','NEITIZNOT_FACEGUARD'),2:('Fire cape','FIRE_CAPE'),3:('Amulet of torture','AMULET_OF_TORTURE'),6:('Bandos chestplate','BANDOS_CHESTPLATE'),7:('Dragon defender','DRAGON_DEFENDER'),8:('Bandos tassets','BANDOS_TASSETS'),9:('Barrows gloves','BARROWS_GLOVES'),10:('Dragon boots','DRAGON_BOOTS'),11:('Berserker ring (i)','BERSERKER_RING_I')}},
'Vorkath':{
 'Entry':{1:('Coif','COIF'),11:('Ring of life','RING_OF_LIFE')},
 'Recommended':{1:('Ancient coif','ANCIENT_COIF'),2:("Ava's assembler",'AVAS_ASSEMBLER'),4:('Ruby dragon bolts (e)','RUBY_DRAGON_BOLTS_E',250),5:('Dragon crossbow','DRAGON_CROSSBOW'),6:('Ancient d\'hide body','ANCIENT_DHIDE_BODY'),7:('Anti-dragon shield','ANTIDRAGON_SHIELD'),8:('Ancient d\'hide chaps','ANCIENT_CHAPS'),9:('Barrows gloves','BARROWS_GLOVES'),10:('Dragon boots','DRAGON_BOOTS'),11:('Ring of shadows','RING_OF_SHADOWS')},
 'Optimal':{7:('Dragonfire ward (charged; check 50 charges)','DRAGONFIRE_WARD')}},
'Phantom Muspah':{
 'Entry':{1:('Coif','COIF'),11:('Ring of life','RING_OF_LIFE')},
 'Recommended':{1:('Crystal helm','CRYSTAL_HELM'),2:("Ava's assembler",'AVAS_ASSEMBLER'),3:('Amulet of fury','AMULET_OF_FURY'),4:None,5:('Bow of Faerdhinen (c)','BOW_OF_FAERDHINEN_C'),6:('Crystal body','CRYSTAL_BODY'),7:None,8:('Crystal legs','CRYSTAL_LEGS'),9:('Barrows gloves','BARROWS_GLOVES'),10:('Dragon boots','DRAGON_BOOTS'),11:('Ring of shadows','RING_OF_SHADOWS')},
 'Optimal':{}},
'Sarachnis':{
 'Entry':{2:('Ardougne cloak 2','ARDOUGNE_CLOAK_2')},
 'Recommended':{5:('Sarachnis cudgel','SARACHNIS_CUDGEL'),6:("Black d'hide body",'BLACK_DHIDE_BODY'),8:("Black d'hide chaps",'BLACK_DHIDE_CHAPS'),10:('Aranea boots','ARANEA_BOOTS')},
 'Optimal':{1:('Neitiznot faceguard','NEITIZNOT_FACEGUARD'),2:('Fire cape','FIRE_CAPE'),3:('Amulet of torture','AMULET_OF_TORTURE'),6:('Bandos chestplate','BANDOS_CHESTPLATE'),8:('Bandos tassets','BANDOS_TASSETS'),9:('Barrows gloves','BARROWS_GLOVES'),11:('Berserker ring (i)','BERSERKER_RING_I')}},
'Hueycoatl':{
 'Entry':{11:('Ring of life','RING_OF_LIFE')},
 'Recommended':{1:('Blood Moon helm','BLOOD_MOON_HELM'),2:('Fire cape','FIRE_CAPE'),3:('Amulet of fury','AMULET_OF_FURY'),5:('Dragon mace','DRAGON_MACE'),6:('Blood Moon chestplate','BLOOD_MOON_CHESTPLATE'),7:('Dragon defender','DRAGON_DEFENDER'),8:('Blood Moon tassets','BLOOD_MOON_TASSETS'),9:('Barrows gloves','BARROWS_GLOVES'),10:('Dragon boots','DRAGON_BOOTS'),11:('Berserker ring (i)','BERSERKER_RING_I')},
 'Optimal':{1:('Neitiznot faceguard','NEITIZNOT_FACEGUARD'),2:('Fire cape','FIRE_CAPE'),3:('Amulet of torture','AMULET_OF_TORTURE'),5:('Dragon hunter lance','DRAGON_HUNTER_LANCE'),6:('Bandos chestplate','BANDOS_CHESTPLATE'),7:('Dragon defender','DRAGON_DEFENDER'),8:('Bandos tassets','BANDOS_TASSETS'),9:('Barrows gloves','BARROWS_GLOVES'),10:('Dragon boots','DRAGON_BOOTS'),11:('Berserker ring (i)','BERSERKER_RING_I')}},
'Amoxliatl':{
 'Entry':{2:('Ardougne cloak 2','ARDOUGNE_CLOAK_2'),1:('Helm of Neitiznot','HELM_OF_NEITIZNOT'),3:('Amulet of strength','AMULET_OF_STRENGTH'),5:('Dragon mace','DRAGON_MACE'),6:('Fighter torso','FIGHTER_TORSO'),7:('Dragon defender','DRAGON_DEFENDER'),8:('Obsidian platelegs','OBSIDIAN_PLATELEGS'),9:('Rune gloves','RUNE_GLOVES'),11:None},
 'Recommended':{1:('Blood Moon helm','BLOOD_MOON_HELM'),2:('Fire cape','FIRE_CAPE'),3:('Amulet of fury','AMULET_OF_FURY'),5:('Dual macuahuitl','DUAL_MACUAHUITL'),6:('Blood Moon chestplate','BLOOD_MOON_CHESTPLATE'),7:None,8:('Blood Moon tassets','BLOOD_MOON_TASSETS'),9:('Barrows gloves','BARROWS_GLOVES'),10:('Dragon boots','DRAGON_BOOTS'),11:('Berserker ring (i)','BERSERKER_RING_I')},
 'Optimal':{}},
'King Black Dragon':{
 'Entry':{1:('Coif','COIF'),11:('Ring of life','RING_OF_LIFE')},
 'Recommended':{2:("Ava's assembler",'AVAS_ASSEMBLER'),3:('Amulet of fury','AMULET_OF_FURY'),4:('Ruby bolts (e)','RUBY_BOLTS_E',250),5:('Rune crossbow','RUNE_CROSSBOW'),6:('Ancient d\'hide body','ANCIENT_DHIDE_BODY'),7:('Anti-dragon shield','ANTIDRAGON_SHIELD'),8:('Ancient d\'hide chaps','ANCIENT_CHAPS'),9:('Barrows gloves','BARROWS_GLOVES'),10:('Ancient d\'hide boots','ANCIENT_DHIDE_BOOTS'),11:('Ring of shadows','RING_OF_SHADOWS')},
 'Optimal':{1:('Ancient coif','ANCIENT_COIF'),2:("Ava's assembler",'AVAS_ASSEMBLER'),3:('Necklace of anguish','NECKLACE_OF_ANGUISH'),4:('Ruby dragon bolts (e)','RUBY_DRAGON_BOLTS_E',250),5:('Dragon hunter crossbow','DRAGON_HUNTER_CROSSBOW'),6:('Masori body (f)','MASORI_BODY_F'),7:('Dragonfire ward (charged; check 50 charges)','DRAGONFIRE_WARD'),8:('Masori chaps (f)','MASORI_CHAPS_F'),9:('Barrows gloves','BARROWS_GLOVES'),10:('Ancient d\'hide boots','ANCIENT_DHIDE_BOOTS'),11:('Ring of shadows','RING_OF_SHADOWS')}},
'Grotesque Guardians':{
 'Entry':{2:('Fire cape','FIRE_CAPE'),9:('Barrows gloves','BARROWS_GLOVES')},
 'Recommended':{3:('Amulet of fury','AMULET_OF_FURY'),8:('Verac\'s plateskirt','VERACS_PLATESKIRT')},
 'Optimal':{5:('Scythe of Vitur','SCYTHE_OF_VITUR'),6:('Bandos chestplate','BANDOS_CHESTPLATE'),8:('Bandos tassets','BANDOS_TASSETS'),9:('Barrows gloves','BARROWS_GLOVES'),10:('Dragon boots','DRAGON_BOOTS'),11:('Berserker ring (i)','BERSERKER_RING_I')}},
'Barrows':{
 'Entry':{4:None},
 'Recommended':{3:('Amulet of glory','AMULET_OF_GLORY'),4:None,5:('Trident of the seas (full)','TRIDENT_OF_THE_SEAS_FULL'),6:('Mystic robe top','MYSTIC_ROBE_TOP'),7:('Rune kiteshield','RUNE_KITESHIELD'),8:('Mystic robe bottom','MYSTIC_ROBE_BOTTOM'),9:('Barrows gloves','BARROWS_GLOVES')},
 'Optimal':{1:('Ahrim\'s hood','AHRIMS_HOOD'),2:('Imbued Saradomin cape','IMBUED_SARADOMIN_CAPE'),3:('Occult necklace','OCCULT_NECKLACE'),4:None,5:('Trident of the Swamp','TRIDENT_OF_THE_SWAMP'),6:('Ahrim\'s robetop','AHRIMS_ROBETOP'),7:('Book of the Dead','BOOK_OF_THE_DEAD'),8:('Ahrim\'s robeskirt','AHRIMS_ROBESKIRT'),9:('Tormented bracelet','TORMENTED_BRACELET'),10:('Infinity boots','INFINITY_BOOTS'),11:('Ring of dueling(8)','RING_OF_DUELING8')}},
'DK Rex':{
 'Entry':{2:('God cape','SARADOMIN_CAPE')},
 'Recommended':{},
 'Optimal':{}},
'Zulrah':{
 'Entry':{2:('God cape','SARADOMIN_CAPE'),5:("Iban's staff (u)",'IBANS_STAFF_U'),7:None,10:('Mystic boots','MYSTIC_BOOTS')},
 'Recommended':{5:('Trident of the Swamp','TRIDENT_OF_THE_SWAMP'),7:('Book of the Dead','BOOK_OF_THE_DEAD')}},
'DK Prime':{
 'Entry':{1:('Coif','COIF'),10:('Climbing boots','CLIMBING_BOOTS')},
 'Recommended':{},
 'Optimal':{}},
'DK Supreme':{
 'Recommended':{5:('Abyssal whip','ABYSSAL_WHIP'),6:('Proselyte hauberk','PROSELYTE_HAUBERK'),8:('Proselyte cuisse','PROSELYTE_CUISSE'),11:('Berserker ring (i)','BERSERKER_RING_I')},
 'Optimal':{1:('Neitiznot faceguard','NEITIZNOT_FACEGUARD'),2:('Fire cape','FIRE_CAPE'),3:('Amulet of torture','AMULET_OF_TORTURE'),6:('Bandos chestplate','BANDOS_CHESTPLATE'),8:('Bandos tassets','BANDOS_TASSETS'),9:('Barrows gloves','BARROWS_GLOVES'),10:('Dragon boots','DRAGON_BOOTS'),11:('Berserker ring (i)','BERSERKER_RING_I')}},
'Obor':{
 'Entry':{6:('Rune chainbody','RUNE_CHAINBODY')},
 'Recommended':{1:('Helm of Neitiznot','HELM_OF_NEITIZNOT'),2:('Ardougne cloak 2','ARDOUGNE_CLOAK_2'),3:('Amulet of strength','AMULET_OF_STRENGTH'),5:('Dragon scimitar','DRAGON_SCIMITAR'),6:('Fighter torso','FIGHTER_TORSO'),7:('Dragon defender','DRAGON_DEFENDER'),8:('Rune plateskirt','RUNE_PLATESKIRT'),9:('Rune gloves','RUNE_GLOVES'),10:('Climbing boots','CLIMBING_BOOTS'),11:None},
 'Optimal':{1:('Neitiznot faceguard','NEITIZNOT_FACEGUARD'),2:('Fire cape','FIRE_CAPE'),3:('Amulet of fury','AMULET_OF_FURY'),5:('Abyssal whip','ABYSSAL_WHIP'),6:('Fighter torso','FIGHTER_TORSO'),7:('Dragon defender','DRAGON_DEFENDER'),8:('Obsidian platelegs','OBSIDIAN_PLATELEGS'),9:('Barrows gloves','BARROWS_GLOVES'),10:('Dragon boots','DRAGON_BOOTS'),11:('Berserker ring (i)','BERSERKER_RING_I')}},
'Bryophyta':{
 'Entry':{2:('Red cape','RED_CAPE'),3:('Amulet of power','AMULET_OF_POWER'),7:('Rune kiteshield','RUNE_KITESHIELD'),9:('Leather gloves','LEATHER_GLOVES'),10:('Fancy boots','FANCY_BOOTS'),11:None},
 'Recommended':{1:('Helm of Neitiznot','HELM_OF_NEITIZNOT'),2:('Ardougne cloak 2','ARDOUGNE_CLOAK_2'),3:('Amulet of fury','AMULET_OF_FURY'),5:('Dragon scimitar','DRAGON_SCIMITAR'),6:("Green d'hide body",'GREEN_DHIDE_BODY'),7:('Rune kiteshield','RUNE_KITESHIELD'),8:("Green d'hide chaps",'GREEN_DHIDE_CHAPS'),9:('Barrows gloves','BARROWS_GLOVES'),10:('Climbing boots','CLIMBING_BOOTS'),11:None},
 'Optimal':{1:('Neitiznot faceguard','NEITIZNOT_FACEGUARD'),2:('Fire cape','FIRE_CAPE'),3:('Amulet of fury','AMULET_OF_FURY'),5:('Abyssal whip','ABYSSAL_WHIP'),6:('Bandos chestplate','BANDOS_CHESTPLATE'),7:('Dragon defender','DRAGON_DEFENDER'),8:('Bandos tassets','BANDOS_TASSETS'),9:('Barrows gloves','BARROWS_GLOVES'),10:('Dragon boots','DRAGON_BOOTS'),11:('Berserker ring (i)','BERSERKER_RING_I')}},
}

RATIONALE={
'Scurrius':'Rat-bone weapon is the progression pivot; no Torva required. Fast tag weapon is only needed before Bone mace.',
'Brutus':'F2P tiers use progressively stronger attainable gear; Rune scimitar overlaps because it is the best listed F2P melee weapon. Mooleta is a boss drop, not an Entry prerequisite.',
'Giant Mole':'Stab preference and Protect from Melee; Dragon dagger is a low-cost stab entry, Zombie axe is a practical mid-step and Fang is the Wiki melee kill-rate leader. Shield/light/spade are conditional tools.',
'Vorkath':'Crossbow tiers progress Rune crossbow to Dragon crossbow to Dragon hunter crossbow. Salve(ei), protection and Crumble Undead remain important.',
'Phantom Muspah':'Ranged camp is slower on melee form. Entry bolt shield; Bowfa plus crystal mid-progression; Tbow/ZCB late shield switch.',
'Sarachnis':'Crush and magic defence matter; Dragon mace to Cudgel to Scythe. Aranea boots reduce web burden.',
'Hueycoatl':'Crush body, multi-hit tail: Glacial temotli makes Entry attainable, full Blood Moon is the mid-step, and Dragon hunter lance is Wiki-ranked best for body in Optimal.',
'Amoxliatl':'Low defence and crush/multiple hits: Dragon mace entry, full Blood Moon dual mid-step, Inquisitor mace/full set high end. Prayer can be restored with moths outside.',
'King Black Dragon':'Wilderness risk matters. Rune crossbow/anti-dragon shield is practical through Recommended; DHCB/Masori/charged ward reserved for Optimal with explicit risk warning.',
'Grotesque Guardians':'Slayer-gated melee plus Dawn ranged switch; Granite hammer overlap is encounter-justified. Scythe is Wiki-ranked high end, not a generic price upgrade.',
'Barrows':'Iban to trident seas to swamp is a deliberate spell progression; Shadow is not required to clear Barrows.',
'DK Rex':'Safe-spot mage progresses Iban to Trident with Guthan sustain to Sanguinesti; pet rock and thrownaxe are route tools.',
'Zulrah':'Magic-only caveat persists on Tanzanite; Wiki-ranked Iban staff, Trident swamp, then Shadow span an attainable Ironman entry and high-end mage progression.',
'DK Prime':'Crossbow to Bowfa full crystal to Tbow; two-handed offhand is empty. Single-king safespot and cave access tools.',
'DK Supreme':'Melee progresses Dragon scimitar, whip, Scythe with safe isolation; avoid treating a tribrid DPS rank as a generic solo guarantee.',
'Obor':'F2P Rune scimitar entry then Dragon scimitar/whip members-world upgrades, avoiding Torva/Scythe; first-entry key is conditional and reusable until chest.',
'Bryophyta':'F2P Rune scimitar entry, members Dragon scimitar/whip later; an actual woodcutting axe finishes growthlings. Slower hits can avoid extra spawns.',
}

assert set(SUP)==set(GEAR)==set(RATIONALE)
changed=[]
for row in P:
    key=K(row);t=row['tier'];old=copy.deepcopy(row)
    assert key in SUP and t in SUP[key]
    gear(row,GEAR[key].get(t,{}));inv(row,SUP[key][t])
    if t=='Entry' and row['gear'][3] and row['gear'][3]['item_id']==m.IDS['RADAS_BLESSING_4']:
        row['gear'][3]=G('Peaceful blessing','PEACEFUL_BLESSING')
    # Fully charged is a preparation requirement; RuneLite's charged item ID
    # covers charges 1–50 and cannot by itself prove a full 50.
    for item in row['gear']:
        if item and item['item_id']==m.IDS['DRAGONFIRE_WARD']:
            item['role']='TPT_SELECTED_CHARGED_WARD_CHECK_50'
    row['authority']='TPT_CURATED_WIKI_AND_COMMUNITY' if key in ('Obor','Bryophyta') else 'TPT_CURATED_WIKI_STRATEGY'
    row['trip_plan']='Short trip, typically one to several kills; adjust food/prayer after observed consumption.'
    row['notes']=[RATIONALE[key],row['trip_plan']]
    if key in ('Obor','Bryophyta'):
        row['notes'].append('Key unlocks the gate once and is not consumed there; bring it on the first visit or for the optional reward chest. On later normal visits, leave it behind.')
    if key=='Bryophyta':row['notes'].append('Activate Protect from Magic before entering; only an axe or secateurs can finish growthlings. F2P Entry omits members-only poison/prayer potions; members should use poison protection.')
    if key=='King Black Dragon':row['notes'].append('Wilderness transit: check item protection and teleport route. Stay in melee distance and pray melee with crossbow/shield; top tier takes more value at risk.')
    if key=='Vorkath':row['notes'].append('Use Protect from Missiles with shield; put Crumble Undead runes in the rune pouch. Charged ward, if used, must show 50 charges on Check.')
    if key=='Grotesque Guardians':row['notes'].append('Eclipse atlatl needs darts. It is two-handed; consume or leave a free inventory cell before storing a defender on switch.')
    if key=='Hueycoatl':row['notes'].append('Use Glacial temotli at Entry or full Blood Moon dual macuahuitl at higher tiers for the tail. Leave a free inventory cell to store the defender when switching.')
    if key=='DK Prime' and t=='Recommended':
        row['notes'].append('Bowfa wears full crystal and no arrows; no crossbow switch is required for Prime.')
    if key=='Phantom Muspah' and t=='Recommended':
        row['inventory'][0]=G('Rune crossbow','RUNE_CROSSBOW')
        row['inventory'][1]=G('Sapphire bolts (e)','SAPPHIRE_BOLTS_E',150)
        row['notes'].append('Bowfa no arrows; regular Sapphire bolts with Rune crossbow for shield. Empty slots accommodate switch.')
    if any(x and x['item_id']==m.IDS['DRAGONFIRE_WARD'] for x in row['gear']):
        row['notes'].append('Dragonfire ward ID 22002 is the charged variant; use Check to verify a full 50 charges before departure.')
    assert len(row['gear'])==11 and len(row['inventory'])==28
    changed.append((key,t,old,row))

data['checkpoint']='BUR-OUTFITTER-QUALITY-04-Q07'
data['parent_r06_sha256']=hashlib.sha256(parent.read_bytes()).hexdigest()
data['policy']='TPT-curated three tiers from official Wiki strategy/mechanics, short-trip supply budgets; R04/R06 remain preserved historic snapshots. ItemID 22002 is charged ward, Check must show 50 charges. Community leads are separate.'
target=ROOT/'docs/research/BUR-OUTFITTER-QUALITY-04-Q07.json'
target.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
m.generate_java(P)
java=ROOT/'src/main/java/gg/feral/burrow/core/TieredOutfitterCatalog.java'
java.write_text(java.read_text().replace('Generated from BUR-OUTFITTER-WIKI-TIERS-03-R06.json','Generated from BUR-OUTFITTER-QUALITY-04-Q07.json'))
print('Q07',len(P),'profiles',hashlib.sha256(target.read_bytes()).hexdigest())
