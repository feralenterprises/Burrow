#!/usr/bin/env python3
"""Build TPT curated tiers from the authenticated R04 source, with explicit provenance.

Only the R04 literal source is authoritative for its exact cells. All other
selected gear, dose states, inventory positions and counts are product choices.
"""
import copy, hashlib, json, pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
PARENT=ROOT/'docs/research/BUR-OUTFITTER-S01-R04-LOADOUTS.json'
RAW=PARENT.read_bytes(); R04=json.loads(RAW)
IDFILE=ROOT/'docs/research/BUR-RUNELITE-1.13.4-ITEMIDS.txt'
IDS={k:int(v) for k,v in (line.strip().split('=') for line in IDFILE.read_text().splitlines())}

def item(name, constant, amount=1, role='TPT_CURATED'):
    assert constant in IDS,constant
    return {'name':name,'item_id':IDS[constant],'quantity':amount,'id_evidence':'RuneLite 1.13.4 ItemID.'+constant,'role':role}
def gear(base, changes):
    out=copy.deepcopy(base)
    for index, value in changes.items():out[index-1]=value
    assert len(out)==11
    return out
# Codes for intentionally selected variants; each token occupies one inventory
# cell unless repeat counts specify more. Runes and ammo are explicit stacks.
C={
'p':('Prayer potion(4)','PRAYER_POTION4'), 'sr':('Super restore(4)','SUPER_RESTORE4'),
'sc':('Super combat potion(4)','SUPER_COMBAT_POTION4'), 'dsc':('Divine super combat potion(4)','DIVINE_SUPER_COMBAT_POTION4'),
'str':('Strength potion(4)','STRENGTH_POTION4'), 'atk':('Super attack(4)','SUPER_ATTACK4'),
'rng':('Ranging potion(4)','RANGING_POTION4'), 'drng':('Divine ranging potion(4)','DIVINE_RANGING_POTION4'),
'stam':('Stamina potion(4)','STAMINA_POTION4'), 'en':('Energy potion(4)','ENERGY_POTION4'),
'sh':('Shark','SHARK'), 'kw':('Cooked karambwan','COOKED_KARAMBWAN'), 'mf':('Monkfish','MONKFISH'),
'dc':('Dark crab','DARK_CRAB'), 'tr':('Trout','TROUT'), 'sw':('Swordfish','SWORDFISH'),
'anti':('Antidote++(4)','ANTIDOTE4_5952'), 'ap':('Antipoison(4)','ANTIPOISON4'),
'av':('Extended anti-venom+(4)','EXTENDED_ANTIVENOM4'), 'af':('Extended antifire(4)','EXTENDED_ANTIFIRE4'),
'saf':('Extended super antifire(4)','EXTENDED_SUPER_ANTIFIRE4'),
'brew':('Saradomin brew(4)','SARADOMIN_BREW4'), 'rest':('Guthix rest(4)','GUTHIX_REST4'),
'house':('Teleport to house (tablet)','TELEPORT_TO_HOUSE'), 'var':('Varrock teleport (tablet)','VARROCK_TELEPORT'),
'fala':('Falador teleport (tablet)','FALADOR_TELEPORT'), 'spade':('Spade','SPADE'),
'light':('Bullseye lantern','BULLSEYE_LANTERN'), 'fs3':('Falador shield 3','FALADOR_SHIELD_3'),
'fs4':('Falador shield 4','FALADOR_SHIELD_4'), 'keyg':('Giant key','GIANT_KEY'),
'keym':('Mossy key','MOSSY_KEY'), 'axe':('Rune axe','RUNE_AXE'),
'pet':('Pet rock','PET_ROCK'), 'thrown':('Rune thrownaxe','RUNE_THROWNAXE'),
'pouch':('Rune pouch','RUNE_POUCH'), 'divpouch':('Divine rune pouch','DIVINE_RUNE_POUCH'),
'book':('Book of the Dead','BOOK_OF_THE_DEAD'), 'zul':('Zul-andra teleport','ZULANDRA_TELEPORT'),
'burn':('Burning amulet(5)','BURNING_AMULET5'), 'dagger':('Dragon dagger','DRAGON_DAGGER'), 'bronze':('Bronze knife','BRONZE_KNIFE'),
'claws':('Dragon claws','DRAGON_CLAWS'), 'atlatl':('Eclipse atlatl','ECLIPSE_ATLATL'),
'atldart':('Atlatl dart','ATLATL_DART'), 'avas':("Ava's assembler",'AVAS_ASSEMBLER'),
'bmhelm':('Blood Moon helm','BLOOD_MOON_HELM'), 'bmbody':('Blood Moon chestplate','BLOOD_MOON_CHESTPLATE'),
'bmlegs':('Blood Moon tassets','BLOOD_MOON_TASSETS'), 'dual':('Dual macuahuitl','DUAL_MACUAHUITL'),
'ruby':('Ruby bolts (e)','RUBY_BOLTS_E'), 'diamond':('Diamond bolts (e)','DIAMOND_BOLTS_E'),
'rubyd':('Ruby dragon bolts (e)','RUBY_DRAGON_BOLTS_E'), 'diamondd':('Diamond dragon bolts (e)','DIAMOND_DRAGON_BOLTS_E'),
'sapphire':('Sapphire bolts (e)','SAPPHIRE_BOLTS_E'), 'sapphired':('Sapphire dragon bolts (e)','SAPPHIRE_DRAGON_BOLTS_E'),
'zcb':('Zaryte crossbow','ZARYTE_CROSSBOW'), 'torso':('Fighter torso','FIGHTER_TORSO'),
'crystalbow':('Crystal bow','CRYSTAL_BOW'), 'ringd':('Ring of dueling(8)','RING_OF_DUELING8'),
'herb':('Herb sack','HERB_SACK'), 'cow':('Cowbell amulet (charged)','COWBELL_AMULET_33104'),
'healing':("Guthan's warspear",'GUTHANS_WARSPEAR'), 'tele':('Ectophial','ECTOPHIAL'),
'surge':('Surge potion(4)','SURGE_POTION4'), 'heart':('Saturated heart','SATURATED_HEART'),
'regen':('Prayer regeneration potion(4)','PRAYER_REGENERATION_POTION4'),
'ectoplasm':('Ectoplasmator','ECTOPLASMATOR'), 'xeric':("Xeric's talisman",'XERICS_TALISMAN'),
'wsword':('Wilderness sword 1','WILDERNESS_SWORD_1'), 'slayerring':('Slayer ring(8)','SLAYER_RING_8'),
'karil':("Karil's crossbow",'KARILS_CROSSBOW'), 'msb':('Magic shortbow (i)','MAGIC_SHORTBOW_I'), 'whip':('Abyssal whip','ABYSSAL_WHIP'), 'shield':('Anti-dragon shield','ANTIDRAGON_SHIELD'),
}
# Some API constants use unusual spelling; names and IDs are checked before generation.
def I(code, amount=1):
    name,constant=C[code];return item(name,constant,amount)
def inventory(groups, runes=()):
    out=[]
    for code, count in groups:
        out.extend(I(code) for _ in range(count))
    for name,constant,amount in runes:out.append(item(name,constant,amount,'TPT_CURATED_STACK'))
    assert len(out)<=28,('inventory overflow',len(out),groups)
    return out+[None]*(28-len(out))

def G(name,constant,amount=1):return item(name,constant,amount,'TPT_CURATED_WIKI_INFORMED')
# Equipment slot order: head, cape, neck, ammo, weapon, body, offhand,
# legs, hands, feet, ring. NULL is intentionally unequipped by TPT.
base={r['boss']:r for r in R04['records'] if r['verification_status']=='VERIFIED'}

def from_r04(r):
    def convert(c):
        v=c.get('item')
        if v is None:return None
        name,id,qty=v['name'],v['item_id'],v['quantity']
        if id is None:
            choices={
                'Cowbell amulet':('Cowbell amulet (charged)','COWBELL_AMULET_33104'),
                'Super combat potion':('Super combat potion(4)','SUPER_COMBAT_POTION4'),
                'Prayer potion':('Prayer potion(4)','PRAYER_POTION4'),
                'Antidote++':('Antidote++(4)','ANTIDOTE4_5952'),
                'Extended antifire':('Extended antifire(4)','EXTENDED_ANTIFIRE4'),
                'Extended anti-venom+':('Extended anti-venom+(4)','EXTENDED_ANTIVENOM4'),
                'Guthix rest':('Guthix rest(4)','GUTHIX_REST4'),
                'Divine ranging potion':('Divine ranging potion(4)','DIVINE_RANGING_POTION4'),
                'Stamina potion':('Stamina potion(4)','STAMINA_POTION4'),
                'Surge potion':('Surge potion(4)','SURGE_POTION4'),
                'Divine super combat potion':('Divine super combat potion(4)','DIVINE_SUPER_COMBAT_POTION4'),
                'Saradomin brew':('Saradomin brew(4)','SARADOMIN_BREW4'),
                'Slayer ring':('Slayer ring(8)','SLAYER_RING_8'),
                'Ring of dueling':('Ring of dueling(8)','RING_OF_DUELING8'),
            }
            if name=='Dragonfire ward':
                # R04 does not establish charge state; keep this specific cell unresolved.
                return {'name':name,'item_id':None,'quantity':1,'role':'R04_CHARGE_STATE_UNRESOLVED'}
            assert name in choices,name
            n,k=choices[name];return item(n,k,1,'TPT_SELECTED_VARIANT_OF_R04_ITEM')
        if qty=='variable':qty=500 if c.get('slot')=='Ammunition' else 1000
        out={'name':name,'item_id':id,'quantity':qty,'role':'R04_WIKI_RENDERED'}
        if v['quantity']=='variable':out['role']='TPT_SELECTED_STACK_AMOUNT_OF_R04_ITEM'
        return out
    return [convert(c) for c in r['equipment']],[convert(c) for c in r['inventory']]

# Products use exact dose/charge choices where the R04 Wiki cell was generic.
# Source notes below distinguish these from literal rendered recommendations.

def spec(changes, groups, notes, runes=()):return changes,groups,notes,runes
# The following equipment is editorially selected for each encounter. The
# corresponding official strategy URL is stored with every generated profile.
# "entry" and "optimal" never claim a literal Wiki 28-cell template.
S={
'Scurrius':{
 'Entry':spec({1:G('Rune full helm','RUNE_FULL_HELM'),2:G('Team-7 cape','TEAM7_CAPE'),3:G('Amulet of strength','AMULET_OF_STRENGTH'),5:G('Rune scimitar','RUNE_SCIMITAR'),6:G('Rune platebody','RUNE_PLATEBODY'),7:G('Rune defender','RUNE_DEFENDER'),8:G('Rune plateskirt','RUNE_PLATESKIRT'),9:G('Combat bracelet(4)','COMBAT_BRACELET4'),10:G('Climbing boots','CLIMBING_BOOTS'),11:None},[('str',1),('atk',1),('p',4),('sh',12),('kw',5),('bronze',1),('dagger',1)],['No spine needed for Rune scimitar. Use a fast weapon against summoned rats. The lower-ranked gear is a TPT combination.']),
 'Optimal':spec({1:G('Torva full helm','TORVA_FULL_HELM'),3:G('Amulet of rancour','AMULET_OF_RANCOUR'),5:G('Bone mace','BONE_MACE'),6:G('Torva platebody','TORVA_PLATEBODY'),7:G('Avernic defender','AVERNIC_DEFENDER'),8:G('Torva platelegs','TORVA_PLATELEGS'),9:G('Ferocious gloves','FEROCIOUS_GLOVES'),10:G('Avernic treads (max)','AVERNIC_TREADS_MAX'),11:G('Ultor ring','ULTOR_RING_28307')},[('dsc',2),('p',8),('sr',2),('sh',7),('kw',6),('dagger',1)],['Bone mace gains its rat-specific bonus. High-strength gear is a TPT selection; bring more prayer as avoidance improves.'])},
'Brutus':{
 'Entry':spec({5:G('Barronite mace','BARRONITE_MACE'),7:G('Rune kiteshield','RUNE_KITESHIELD'),9:G('Leather gloves','LEATHER_GLOVES'),10:G('Fancy boots','FANCY_BOOTS')},[('str',2),('sw',22),('cow',1)],['F2P alternatives avoid Mooleta and costly gilded gloves. The charged cowbell amulet is a TPT variant selection.']),
 'Optimal':spec({},[('str',3),('sw',20),('cow',1)],['Wiki-ranked F2P top gear is retained. Swordfish and potion counts are TPT choices; Mooleta is a post-quest boss drop.'])},
'Giant Mole':{
 'Entry':spec({2:G('Obsidian cape','OBSIDIAN_CAPE'),3:G('Amulet of glory','AMULET_OF_GLORY'),5:G('Dragon sword','DRAGON_SWORD'),6:G('Proselyte hauberk','PROSELYTE_HAUBERK'),7:G('Rune defender','RUNE_DEFENDER'),8:G('Proselyte cuisse','PROSELYTE_CUISSE'),9:G('Combat bracelet(4)','COMBAT_BRACELET4'),10:G('Climbing boots','CLIMBING_BOOTS'),11:None},[('sc',1),('p',8),('en',4),('sh',7),('spade',1),('light',1),('fs3',1),('fala',1),('house',1)],['Stab with Dragon sword; Protect from Melee. Falador shield 3 marks dig location. A closed lantern is retained unless Fire of Eternal Light is unlocked.']),
 'Optimal':spec({1:G('Torva full helm','TORVA_FULL_HELM'),2:G('Infernal cape','INFERNAL_CAPE'),3:G('Amulet of rancour','AMULET_OF_RANCOUR'),5:G("Osmumten's fang",'OSMUMTENS_FANG'),6:G('Torva platebody','TORVA_PLATEBODY'),7:G('Avernic defender','AVERNIC_DEFENDER'),8:G('Torva platelegs','TORVA_PLATELEGS'),9:G('Ferocious gloves','FEROCIOUS_GLOVES'),10:G('Avernic treads (max)','AVERNIC_TREADS_MAX'),11:G('Ultor ring','ULTOR_RING_28307')},[('dsc',3),('p',13),('stam',4),('sh',2),('spade',1),('fs4',1),('light',1),('house',1),('fala',1)],['Wiki identifies Fang as the high-kill-rate melee option. Stab, protect melee, and use the shield locator. TPT chose 13 prayers and four stamina potions.'])},
'Vorkath':{
 'Entry':spec({1:G('Blessed coif','ANCIENT_COIF'),2:G("Ava's accumulator",'AVAS_ACCUMULATOR'),4:G('Ruby bolts (e)','RUBY_BOLTS_E',500),5:G('Rune crossbow','RUNE_CROSSBOW'),6:G("Black d'hide body",'BLACK_DHIDE_BODY'),7:G('Anti-dragon shield','ANTIDRAGON_SHIELD'),8:G("Black d'hide chaps",'BLACK_DHIDE_CHAPS'),9:G('Barrows gloves','BARROWS_GLOVES'),10:G('Climbing boots','CLIMBING_BOOTS'),11:G('Ring of shadows','RING_OF_SHADOWS')},[('diamond',1),('saf',1),('av',1),('rng',1),('p',4),('sh',12),('kw',5),('pouch',1),('house',1)],['Rune crossbow uses standard Ruby/Diamond bolts, not dragon bolts. Crumble Undead runes must be placed in the pouch before the trip; use Protect from Missiles.']),
 'Optimal':spec({},[('diamondd',1),('saf',1),('av',1),('drng',1),('p',4),('dc',11),('kw',5),('zcb',1),('divpouch',1),('house',1)],['Dragon hunter crossbow and Salve(ei) synergy is source-ranked. Swap Ruby to Diamond bolts at low HP; rune pouch needs Crumble Undead runes. Ward charge state remains unresolved.'])},
'Phantom Muspah':{
 'Entry':spec({1:G('Blessed coif','ANCIENT_COIF'),2:G("Ava's accumulator",'AVAS_ACCUMULATOR'),3:G('Amulet of fury','AMULET_OF_FURY'),4:G('Ruby bolts (e)','RUBY_BOLTS_E',500),5:G('Rune crossbow','RUNE_CROSSBOW'),6:G("Black d'hide body",'BLACK_DHIDE_BODY'),7:None,8:G("Black d'hide chaps",'BLACK_DHIDE_CHAPS'),9:G('Barrows gloves','BARROWS_GLOVES'),10:G('Dragon boots','DRAGON_BOOTS'),11:G('Ring of shadows','RING_OF_SHADOWS')},[('sapphire',1),('rng',1),('stam',2),('p',5),('sh',12),('kw',3),('book',1),('pouch',1),('house',1)],['Ruby bolts for damage, Sapphire bolts for prayer shield. TPT budgets stamina, prayer and food; pouch runes for thralls are an optional prepared utility.']),
 'Optimal':spec({},[('zcb',1),('sapphired',1),('rubyd',1),('drng',1),('stam',2),('surge',1),('p',5),('dc',11),('book',1),('divpouch',1),('house',1)],['Twisted bow is two-handed; offhand stays empty. Zaryte crossbow and Sapphire bolts handle prayer shield; leave space when switching.'])},
'Sarachnis':{
 'Entry':spec({2:G('Mythical cape','MYTHICAL_CAPE'),3:G('Amulet of glory','AMULET_OF_GLORY'),5:G('Dragon mace','DRAGON_MACE'),6:G("Black d'hide body",'BLACK_DHIDE_BODY'),7:G('Rune defender','RUNE_DEFENDER'),8:G("Black d'hide chaps",'BLACK_DHIDE_CHAPS'),9:G('Rune gloves','RUNE_GLOVES'),10:G('Rune boots','RUNE_BOOTS'),11:None},[('sc',1),('p',5),('sh',16),('kw',3),('wsword',1),('xeric',1),('house',1)],['Dragon mace uses crush. Without Aranea boots bring a slash weapon for webs and switch protection prayers.']),
 'Optimal':spec({1:G('Torva full helm','TORVA_FULL_HELM'),2:G('Infernal cape','INFERNAL_CAPE'),3:G('Amulet of rancour','AMULET_OF_RANCOUR'),5:G('Scythe of Vitur','SCYTHE_OF_VITUR'),6:G('Masori body (f)','MASORI_BODY_F'),7:None,8:G('Masori chaps (f)','MASORI_CHAPS_F'),9:G('Ferocious gloves','FEROCIOUS_GLOVES'),10:G('Aranea boots','ARANEA_BOOTS'),11:G('Ultor ring','ULTOR_RING_28307')},[('dsc',2),('p',6),('brew',2),('sr',3),('sh',10),('kw',2),('house',1),('xeric',1)],['Scythe is two-handed, so no offhand. Magic defence from Masori and Aranea web immunity follow encounter strategy.'])},
'Hueycoatl':{
 'Entry':spec({1:G('Helm of Neitiznot','HELM_OF_NEITIZNOT'),2:G('Fire cape','FIRE_CAPE'),3:G('Amulet of fury','AMULET_OF_FURY'),5:G('Dragon mace','DRAGON_MACE'),6:G('Fighter torso','FIGHTER_TORSO'),7:G('Dragon defender','DRAGON_DEFENDER'),8:G('Obsidian platelegs','OBSIDIAN_PLATELEGS'),9:G('Barrows gloves','BARROWS_GLOVES'),10:G('Dragon boots','DRAGON_BOOTS'),11:G('Berserker ring (i)','BERSERKER_RING_I')},[('sc',1),('p',6),('sh',12),('kw',3),('dual',1),('bmhelm',1),('bmbody',1),('bmlegs',1),('house',1)],['Crush body/head with Dragon mace; swap to Blood Moon/dual macuahuitl at tail. Consume a supply before a two-handed tail switch.']),
 'Optimal':spec({},[('dsc',2),('regen',1),('p',7),('sh',7),('kw',3),('dual',1),('bmhelm',1),('bmbody',1),('bmlegs',1),('claws',1),('house',1)],['The Inquisitor mace and full set stay paired. Tail switch is two-handed; free a slot before storing the defender.'])},
'Amoxliatl':{
 'Entry':spec({1:G('Blood Moon helm','BLOOD_MOON_HELM'),2:G('Fire cape','FIRE_CAPE'),3:G('Amulet of fury','AMULET_OF_FURY'),5:G('Dual macuahuitl','DUAL_MACUAHUITL'),6:G('Blood Moon chestplate','BLOOD_MOON_CHESTPLATE'),7:None,8:G('Blood Moon tassets','BLOOD_MOON_TASSETS'),9:G('Barrows gloves','BARROWS_GLOVES'),10:G('Dragon boots','DRAGON_BOOTS'),11:G('Berserker ring (i)','BERSERKER_RING_I')},[('sc',1),('p',7),('sh',10),('kw',5),('house',1),('book',1),('pouch',1)],['Dual macuahuitl require full Blood Moon set for the cited synergy and leave the offhand empty.']),
 'Optimal':spec({},[('dsc',2),('p',9),('sh',7),('kw',5),('claws',1),('ectoplasm',1),('book',1),('divpouch',1)],['Full Inquisitor and one-handed mace remain paired with Avernic defender. TPT selected more prayer and food; no claim of a separate Wiki tier.'])},
'King Black Dragon':{
 'Entry':spec({1:G('Ancient coif','ANCIENT_COIF'),3:G('Amulet of fury','AMULET_OF_FURY'),4:G('Ruby bolts (e)','RUBY_BOLTS_E',500),5:G('Rune crossbow','RUNE_CROSSBOW'),6:G("Black d'hide body",'BLACK_DHIDE_BODY'),7:G('Anti-dragon shield','ANTIDRAGON_SHIELD'),8:G("Black d'hide chaps",'BLACK_DHIDE_CHAPS'),9:G('Barrows gloves','BARROWS_GLOVES'),10:G('Dragon boots','DRAGON_BOOTS'),11:G('Ring of shadows','RING_OF_SHADOWS')},[('diamond',1),('anti',1),('af',1),('rng',1),('p',4),('sh',15),('kw',3),('burn',1),('house',1)],['Wilderness entry: protect valuables and bring a teleport. Rune crossbow needs regular enchanted bolts. Antidote and antifire are TPT four-dose choices.']),
 'Optimal':spec({4:G('Ruby dragon bolts (e)','RUBY_DRAGON_BOLTS_E',500)},[('diamondd',1),('anti',1),('af',1),('drng',1),('sr',5),('dc',16),('burn',1),('house',1)],['Dragon hunter crossbow retains anti-dragon protection. Dragonfire ward charge variant is unresolved in R04; do not infer bank ownership.'])},
'Grotesque Guardians':{
 'Entry':spec({3:G('Amulet of glory','AMULET_OF_GLORY'),7:G('Rune defender','RUNE_DEFENDER'),8:G('Rune plateskirt','RUNE_PLATESKIRT'),9:G('Rune gloves','RUNE_GLOVES'),10:G('Climbing boots','CLIMBING_BOOTS'),11:None},[('atlatl',1),('avas',1),('sc',1),('rng',1),('p',5),('sh',12),('kw',3),('dagger',1),('house',1)],['Granite hammer avoids a separate rock hammer. Eclipse atlatl is a two-handed Dawn switch; keep inventory room.']),
 'Optimal':spec({2:G('Infernal cape','INFERNAL_CAPE'),3:G('Amulet of rancour','AMULET_OF_RANCOUR'),5:G('Soulreaper axe','SOULREAPER_AXE'),6:G('Torva platebody','TORVA_PLATEBODY'),7:None,8:G('Torva platelegs','TORVA_PLATELEGS'),9:G('Ferocious gloves','FEROCIOUS_GLOVES'),10:G('Avernic treads (max)','AVERNIC_TREADS_MAX'),11:G('Ultor ring','ULTOR_RING_28307')},[('atlatl',1),('avas',1),('dsc',1),('drng',1),('p',7),('sr',3),('sh',8),('kw',3),('house',1)],['Soulreaper axe is two-handed and requires minimising downtime to retain stacks. Atlatl switch is two-handed; two slots remain free.'])},
'Barrows':{
 'Entry':spec({5:G("Iban's staff (u)",'IBANS_STAFF_U'),9:G('Rune gloves','RUNE_GLOVES')},[('p',5),('sh',12),('kw',4),('spade',1),('var',1),('dagger',1)],['Iban Blast requires death and fire runes; bring them separately. Protect against dangerous brothers and use the spade.'],[('Death rune','DEATH_RUNE',500),('Fire rune','FIRE_RUNE',1000)]),
 'Optimal':spec({1:G('Ancestral hat','ANCESTRAL_HAT'),2:G('Imbued Saradomin cape','IMBUED_SARADOMIN_CAPE'),3:G('Occult necklace','OCCULT_NECKLACE'),5:G("Tumeken's shadow",'TUMEKENS_SHADOW'),6:G('Ancestral robe top','ANCESTRAL_ROBE_TOP'),7:None,8:G('Ancestral robe bottom','ANCESTRAL_ROBE_BOTTOM'),9:G('Tormented bracelet','TORMENTED_BRACELET'),10:G('Eternal boots','ETERNAL_BOOTS'),11:G('Magus ring','MAGUS_RING_28313')},[('sr',4),('sh',10),('kw',6),('spade',1),('house',1),('pouch',1),('msb',1),('whip',1),('avas',1)],['Shadow is two-handed: offhand empty. Melee and ranged switches are packed for resistant brothers; TPT reserves one empty slot.'])},
'Dagannoth Kings Rex':{
 'Entry':spec({1:G('Rune full helm','RUNE_FULL_HELM'),2:G('God cape','SARADOMIN_CAPE'),3:G('Amulet of glory','AMULET_OF_GLORY'),5:G("Iban's staff (u)",'IBANS_STAFF_U'),6:G('Rune platebody','RUNE_PLATEBODY'),7:G('Rune kiteshield','RUNE_KITESHIELD'),8:G('Rune plateskirt','RUNE_PLATESKIRT'),9:G('Combat bracelet(4)','COMBAT_BRACELET4'),10:G('Dragon boots','DRAGON_BOOTS'),11:None},[('anti',3),('p',6),('stam',1),('sh',10),('kw',3),('pet',1),('thrown',1),('house',1),('pouch',1)],['Rex safespot. Iban Blast needs death and fire runes in pouch; pet rock and rune thrownaxe enable cave access.']),
 'Optimal':spec({1:G('Justiciar faceguard','JUSTICIAR_FACEGUARD'),5:G('Sanguinesti staff','SANGUINESTI_STAFF'),6:G('Justiciar chestguard','JUSTICIAR_CHESTGUARD'),8:G('Justiciar legguards','JUSTICIAR_LEGGUARDS')},[('anti',4),('p',7),('stam',1),('sh',8),('kw',3),('pet',1),('thrown',1),('house',1),('pouch',1)],['Sanguinesti staff sustains Rex safespot; Justiciar defence is a TPT selection. Weapon charge and shield charge must be checked in RuneLite.'])},
'Zulrah':{
 'Entry':spec({1:G('Mystic hat','MYSTIC_HAT'),3:G('Amulet of glory','AMULET_OF_GLORY'),5:G('Trident of the seas (full)','TRIDENT_OF_THE_SEAS_FULL'),6:G('Mystic robe top','MYSTIC_ROBE_TOP'),7:G('Book of the Dead','BOOK_OF_THE_DEAD'),8:G('Mystic robe bottom','MYSTIC_ROBE_BOTTOM'),9:G('Barrows gloves','BARROWS_GLOVES'),10:G('Infinity boots','INFINITY_BOOTS'),11:G('Ring of recoil','RING_OF_RECOIL')},[('av',1),('p',3),('sh',11),('kw',9),('zul',1),('ringd',1),('pouch',1)],['Magic-only entry is slower on Tanzanite phase. A full trident is explicitly selected; the ring of recoil handles snakelings.']),
 'Optimal':spec({1:G('Ancestral hat','ANCESTRAL_HAT'),5:G("Tumeken's shadow",'TUMEKENS_SHADOW'),6:G('Ancestral robe top','ANCESTRAL_ROBE_TOP'),7:None,8:G('Ancestral robe bottom','ANCESTRAL_ROBE_BOTTOM'),9:G('Tormented bracelet','TORMENTED_BRACELET'),10:G('Eternal boots','ETERNAL_BOOTS')},[('av',1),('p',2),('sh',11),('kw',9),('zul',1),('heart',1),('pouch',1),('ringd',1)],['Shadow is two-handed; offhand empty. Magic-only remains weaker on Tanzanite, so food and positioning matter.'])},
}
# New methods: the community Ironman Path key-gear leads for Obor/Bryophyta
# and R04 Prime ranked equipment are retained as evidence, not portrayed as
# complete official Wiki plans. The 11/28 layout below is TPT construction.
NEW={
'Obor':{
 'method':'Melee, standard','style':'Melee',
 'wiki':'https://oldschool.runescape.wiki/w/Obor',
 'community':'https://ironmanpath.app/en/bosses/obor/ (R04 partial key gear and reconstructed inventory)',
 'base':[G('Helm of Neitiznot','HELM_OF_NEITIZNOT'),G('Fire cape','FIRE_CAPE'),G('Amulet of glory','AMULET_OF_GLORY'),None,G('Dragon scimitar','DRAGON_SCIMITAR'),G('Rune platebody','RUNE_PLATEBODY'),G('Rune defender','RUNE_DEFENDER'),G('Rune plateskirt','RUNE_PLATESKIRT'),G('Barrows gloves','BARROWS_GLOVES'),G('Climbing boots','CLIMBING_BOOTS'),G('Ring of life','RING_OF_LIFE')],
 'tiers':{
  'Entry':spec({1:G('Rune full helm','RUNE_FULL_HELM'),2:G('Red cape','RED_CAPE'),3:G('Amulet of strength','AMULET_OF_STRENGTH'),5:G('Rune scimitar','RUNE_SCIMITAR'),7:G('Rune kiteshield','RUNE_KITESHIELD'),9:G('Leather gloves','LEATHER_GLOVES'),10:G('Fancy boots','FANCY_BOOTS'),11:None},[('str',2),('sw',24),('var',1)],['Accessible melee; TPT-selected F2P gear and food. Giant key is needed for first gate access or optional reward chest, not every fight.']),
  'Recommended':spec({},[('keyg',1),('sc',1),('p',3),('mf',18),('kw',3),('var',1)],['Community key-gear lead supplemented by TPT-selected slots and supplies. Giant key slot is for first access or optional reward chest; remove later.']),
  'Optimal':spec({1:G('Torva full helm','TORVA_FULL_HELM'),2:G('Infernal cape','INFERNAL_CAPE'),3:G('Amulet of rancour','AMULET_OF_RANCOUR'),5:G('Scythe of Vitur','SCYTHE_OF_VITUR'),6:G('Torva platebody','TORVA_PLATEBODY'),7:None,8:G('Torva platelegs','TORVA_PLATELEGS'),9:G('Ferocious gloves','FEROCIOUS_GLOVES'),10:G('Avernic treads (max)','AVERNIC_TREADS_MAX'),11:G('Ultor ring','ULTOR_RING_28307')},[('dsc',2),('p',3),('sh',17),('kw',3),('var',1)],['High-end melee with a two-handed weapon; offhand remains empty. Key is only for first access or optional chest.'])}
},
'Bryophyta':{
 'method':'Melee, standard','style':'Melee',
 'wiki':'https://oldschool.runescape.wiki/w/Bryophyta',
 'community':'https://ironmanpath.app/en/bosses/bryophyta/ (R04 partial key gear and reconstructed inventory)',
 'base':[G('Rune full helm','RUNE_FULL_HELM'),G('Fire cape','FIRE_CAPE'),G('Amulet of glory','AMULET_OF_GLORY'),None,G('Dragon scimitar','DRAGON_SCIMITAR'),G("Green d'hide body",'GREEN_DHIDE_BODY'),G('Rune defender','RUNE_DEFENDER'),G("Green d'hide chaps",'GREEN_DHIDE_CHAPS'),G('Barrows gloves','BARROWS_GLOVES'),G('Climbing boots','CLIMBING_BOOTS'),G('Ring of life','RING_OF_LIFE')],
 'tiers':{
  'Entry':spec({2:G('Red cape','RED_CAPE'),3:G('Amulet of strength','AMULET_OF_STRENGTH'),5:G('Rune scimitar','RUNE_SCIMITAR'),7:G('Rune kiteshield','RUNE_KITESHIELD'),9:G('Leather gloves','LEATHER_GLOVES'),10:G('Fancy boots','FANCY_BOOTS'),11:None},[('axe',1),('ap',1),('p',2),('sw',20),('kw',2),('var',1)],['Axe is needed for growthlings; poison protection is a TPT supply choice. Mossy key is first gate access or optional reward chest.']),
  'Recommended':spec({},[('keym',1),('axe',1),('ap',1),('p',4),('mf',16),('kw',3),('var',1)],['Community key-gear lead with TPT-selected empty slots and supplies. Chop growthlings with axe; key use is conditional.']),
  'Optimal':spec({1:G('Torva full helm','TORVA_FULL_HELM'),2:G('Infernal cape','INFERNAL_CAPE'),3:G('Amulet of rancour','AMULET_OF_RANCOUR'),5:G('Scythe of Vitur','SCYTHE_OF_VITUR'),6:G('Torva platebody','TORVA_PLATEBODY'),7:None,8:G('Torva platelegs','TORVA_PLATELEGS'),9:G('Ferocious gloves','FEROCIOUS_GLOVES'),10:G('Avernic treads (max)','AVERNIC_TREADS_MAX'),11:G('Ultor ring','ULTOR_RING_28307')},[('axe',1),('ap',1),('dsc',1),('p',4),('sh',15),('kw',4),('var',1)],['Scythe is two-handed. The axe growthling switch needs room; inventory leaves a slot open.'])}
},
'Dagannoth Kings Prime':{
 'method':'Prime, ranged','style':'Ranged',
 'wiki':'https://oldschool.runescape.wiki/w/Dagannoth_Kings/Strategies',
 'community':'https://www.osrsbestinslot.com/boss-gear-and-guides/dagannoth-prime/ (R04 unverified lead; not used as an official layout)',
 'base':[G('Crystal helm','CRYSTAL_HELM'),G("Ava's assembler",'AVAS_ASSEMBLER'),G('Necklace of anguish','NECKLACE_OF_ANGUISH'),None,G('Bow of Faerdhinen (c)','BOW_OF_FAERDHINEN_C'),G('Crystal body','CRYSTAL_BODY'),None,G('Crystal legs','CRYSTAL_LEGS'),G('Barrows gloves','BARROWS_GLOVES'),G('Dragon boots','DRAGON_BOOTS'),G('Archers ring (i)','ARCHERS_RING_I')],
 'tiers':{
  'Entry':spec({1:G('Ancient coif','ANCIENT_COIF'),2:G("Ava's accumulator",'AVAS_ACCUMULATOR'),3:G('Amulet of fury','AMULET_OF_FURY'),4:G('Ruby bolts (e)','RUBY_BOLTS_E',500),5:G('Rune crossbow','RUNE_CROSSBOW'),6:G("Black d'hide body",'BLACK_DHIDE_BODY'),8:G("Black d'hide chaps",'BLACK_DHIDE_CHAPS'),9:G("Black d'hide vambraces",'BLACK_DHIDE_VAMBRACES'),11:None},[('diamond',1),('anti',3),('p',7),('stam',1),('sh',10),('kw',3),('pet',1),('thrown',1),('house',1)],['Prime ranged only. Protect from Magic and stay out of other kings. Crossbow uses regular bolts; cave access needs pet rock/thrownaxe.']),
  'Recommended':spec({},[('anti',3),('p',8),('stam',1),('sh',10),('kw',3),('pet',1),('thrown',1),('house',1)],['Crystal armour is paired with Bowfa. Bowfa is two-handed and requires no arrows; inventory is TPT-curated for Prime.']),
  'Optimal':spec({1:G('Masori mask (f)','MASORI_MASK_F'),2:G("Dizana's quiver",'DIZANAS_QUIVER'),3:G('Necklace of rupture','NECKLACE_OF_RUPTURE'),4:G('Seeking dragon arrow','SEEKING_DRAGON_ARROW',500),5:G('Twisted bow','TWISTED_BOW'),6:G('Masori body (f)','MASORI_BODY_F'),7:None,8:G('Masori chaps (f)','MASORI_CHAPS_F'),9:G('Zaryte vambraces','ZARYTE_VAMBRACES'),10:G('Avernic treads (max)','AVERNIC_TREADS_MAX'),11:G('Venator ring','VENATOR_RING')},[('anti',4),('p',8),('stam',1),('sh',9),('kw',3),('pet',1),('thrown',1),('house',1)],['Twisted bow is two-handed. R04 Prime lead incorrectly paired it with Elysian shield; TPT intentionally clears offhand.'])}
},
'Dagannoth Kings Supreme':{
 'method':'Supreme, melee','style':'Melee',
 'wiki':'https://oldschool.runescape.wiki/w/Dagannoth_Kings/Strategies',
 'community':'https://www.osrsbestinslot.com/boss-gear-and-guides/dagannoth-supreme/ (R04 unverified lead; not used as an official layout)',
 'base':[G('Helm of Neitiznot','HELM_OF_NEITIZNOT'),G('Fire cape','FIRE_CAPE'),G('Amulet of fury','AMULET_OF_FURY'),G("Rada's blessing 4",'RADAS_BLESSING_4'),G("Osmumten's fang",'OSMUMTENS_FANG'),G('Fighter torso','FIGHTER_TORSO'),G('Dragon defender','DRAGON_DEFENDER'),G('Obsidian platelegs','OBSIDIAN_PLATELEGS'),G('Barrows gloves','BARROWS_GLOVES'),G('Dragon boots','DRAGON_BOOTS'),G('Berserker ring (i)','BERSERKER_RING_I')],
 'tiers':{
  'Entry':spec({1:G('Rune full helm','RUNE_FULL_HELM'),2:G('Obsidian cape','OBSIDIAN_CAPE'),3:G('Amulet of glory','AMULET_OF_GLORY'),5:G('Dragon scimitar','DRAGON_SCIMITAR'),6:G('Rune platebody','RUNE_PLATEBODY'),7:G('Rune defender','RUNE_DEFENDER'),8:G('Rune plateskirt','RUNE_PLATESKIRT'),9:G('Rune gloves','RUNE_GLOVES'),10:G('Climbing boots','CLIMBING_BOOTS'),11:None},[('anti',3),('p',7),('stam',1),('sh',10),('kw',3),('pet',1),('thrown',1),('house',1)],['Supreme melee only; Protect from Missiles and isolate from Rex/Prime. TPT constructs full layout from encounter mechanics.']),
  'Recommended':spec({},[('anti',3),('p',8),('stam',1),('sh',10),('kw',3),('pet',1),('thrown',1),('house',1)],['Fang melee and Dragon defender are TPT-selected; Protect from Missiles and avoid aggro from other kings.']),
  'Optimal':spec({1:G('Torva full helm','TORVA_FULL_HELM'),2:G('Infernal cape','INFERNAL_CAPE'),3:G('Amulet of rancour','AMULET_OF_RANCOUR'),5:G('Scythe of Vitur','SCYTHE_OF_VITUR'),6:G('Torva platebody','TORVA_PLATEBODY'),7:None,8:G('Torva platelegs','TORVA_PLATELEGS'),9:G('Ferocious gloves','FEROCIOUS_GLOVES'),10:G('Avernic treads (max)','AVERNIC_TREADS_MAX'),11:G('Ultor ring','ULTOR_RING_28307')},[('anti',4),('p',8),('stam',1),('sh',9),('kw',3),('pet',1),('thrown',1),('house',1)],['Scythe is two-handed; no offhand. TPT high-end choice needs a client check for cost/effectiveness versus Fang.'])}
}}

def records():
    out=[]
    for r in R04['records']:
        boss=r['boss']; old_method=r['encounter_method']; status=r['verification_status']
        if boss in NEW and boss!='Dagannoth Kings':continue
        if boss=='Dagannoth Kings' and old_method!='Rex safespot with Guthan healing switch':continue
        assert status=='VERIFIED'
        base_gear,base_inv=from_r04(r)
        key='Dagannoth Kings Rex' if boss=='Dagannoth Kings' else boss
        for tier in ('Entry','Recommended','Optimal'):
            if tier=='Recommended':
                g=copy.deepcopy(base_gear);v=copy.deepcopy(base_inv)
                variant=any(i and i['role'].startswith('TPT_') for i in g+v)
                auth='WIKI_LAYOUT_WITH_TPT_EXPLICIT_VARIANTS' if variant else 'OFFICIAL_WIKI_RENDERED_LAYOUT'
                notes=['R04 Wiki arrangement retained; any selected dose/quantity is a TPT choice, not a Wiki-specified variant.']
            else:
                changes,groups,notes,runes=S[key][tier]
                g=gear(base_gear,changes);v=inventory(groups,runes)
                auth='TPT_CURATED_WIKI_STRATEGY'
            out.append({'boss':boss,'method':old_method,'style':r['combat_style'],'tier':tier,
                'authority':auth,'official_wiki':r['source']['pinned_raw_url'],
                'source_revision':r['source']['revision_id'],'community_source':None,
                'gear':g,'inventory':v,'notes':notes})
    for key in ('Dagannoth Kings Prime','Dagannoth Kings Supreme','Obor','Bryophyta'):
        x=NEW[key]
        boss='Dagannoth Kings' if key.startswith('Dagannoth Kings ') else key
        for tier in ('Entry','Recommended','Optimal'):
            changes,groups,notes,runes=x['tiers'][tier]
            out.append({'boss':boss,'method':x['method'],'style':x['style'],'tier':tier,
                'authority':'TPT_CURATED_WIKI_AND_COMMUNITY' if boss in ('Obor','Bryophyta') else 'TPT_CURATED_WIKI_STRATEGY',
                'official_wiki':x['wiki'],'source_revision':None,'community_source':x['community'],
                'gear':gear(x['base'],changes),'inventory':inventory(groups,runes),'notes':notes})
    return out

def js(s):return json.dumps(s,ensure_ascii=False)
def java_item(v):
    return 'null' if v is None else f'new Item({v["item_id"] if v["item_id"] is not None else -1},{js(v["name"])},{v["quantity"]})'
def java_list(vals):return 'Arrays.asList('+','.join(java_item(v) for v in vals)+')'
def generate_java(rows):
    lines=['package gg.feral.burrow.core;','import java.util.*;','import gg.feral.burrow.core.VerifiedOutfitterCatalog.*;',
      '/** Generated from BUR-OUTFITTER-WIKI-TIERS-03-R06.json. Keep its source and tier provenance. */',
      'public final class TieredOutfitterCatalog {','  private TieredOutfitterCatalog() {}',
      '  public enum Tier { ENTRY("Entry"), RECOMMENDED("Recommended"), OPTIMAL("Optimal");',
      '    private final String label; Tier(String label){this.label=label;} public String label(){return label;} }',
      '  public enum Authority { OFFICIAL_WIKI_RENDERED_LAYOUT, WIKI_LAYOUT_WITH_TPT_EXPLICIT_VARIANTS, TPT_CURATED_WIKI_STRATEGY, TPT_CURATED_WIKI_AND_COMMUNITY }',
      '  public record Selection(Profile profile, Authority authority, String provenance) {}',
      '  private static final Map<String,Selection> DATA;','  private static final Map<String,List<String>> METHODS;',
      '  private static String key(String boss,String method,Tier tier){return boss+"\\u0000"+method+"\\u0000"+tier.name();}',
      '  static {Map<String,Selection> data=new LinkedHashMap<>(); Map<String,List<String>> methods=new LinkedHashMap<>();']
    for row in rows:
        b,m,t=row['boss'],row['method'],row['tier'].upper()
        provenance=row['official_wiki']+((' | Community lead: '+row['community_source']) if row['community_source'] else '')
        all_notes=row['notes']
        lines.append('    put(data,methods,'+js(b)+','+js(m)+',Tier.'+t+',Authority.'+row['authority']+',\n'
            + '      new Profile('+js(b)+','+js(m)+','+js(row['style'])+','+js(row['official_wiki'])+',\n'
            + '        '+java_list(row['gear'])+',\n        '+java_list(row['inventory'])+',\n        List.of('+','.join(js(n) for n in all_notes)+')),\n      '+js(provenance)+');')
    lines+=['    DATA=Collections.unmodifiableMap(data);',
      '    Map<String,List<String>> frozen=new LinkedHashMap<>();methods.forEach((k,v)->frozen.put(k,List.copyOf(v)));METHODS=Collections.unmodifiableMap(frozen);}',
      '  private static void put(Map<String,Selection> data,Map<String,List<String>> methods,String boss,String method,Tier tier,Authority authority,Profile profile,String provenance){',
      '    if(data.put(key(boss,method,tier),new Selection(profile,authority,provenance))!=null)throw new IllegalStateException("duplicate tier");',
      '    var list=methods.computeIfAbsent(boss,k->new ArrayList<>());if(!list.contains(method))list.add(method);}',
      '  public static Selection find(String boss,String method,Tier tier){return DATA.get(key(boss,method,tier));}',
      '  public static List<String> methods(String boss){return METHODS.getOrDefault(boss,List.of());}',
      '  public static String style(String boss,String method){var s=find(boss,method,Tier.RECOMMENDED);return s==null?"Unavailable":s.profile().style();}',
      '}']
    target=ROOT/'src/main/java/gg/feral/burrow/core/TieredOutfitterCatalog.java'
    target.write_text('\n'.join(lines)+'\n')

if __name__=='__main__':
    rows=records()
    assert len(rows)==51
    assert len({r['boss'] for r in rows})==15
    assert all(len(r['gear'])==11 and len(r['inventory'])==28 for r in rows)
    data={'checkpoint':'BUR-OUTFITTER-WIKI-TIERS-03-R06','parent_r04_sha256':hashlib.sha256(RAW).hexdigest(),
       'parent_tiers02_sha256':'3bb297ae2f479cd42e1384ac446edbf6a39342280be25c5c0ad044e672aced45',
       'release':'HOLD','date':'2026-10-30','policy':'Three TPT product tiers; only R04 literal cells are official Wiki layouts. New cells, exact dose/charge variants, quantities and arrangements are TPT curation. Community leads are named separately.',
       'methods':17,'profiles':rows}
    target=ROOT/'docs/research/BUR-OUTFITTER-WIKI-TIERS-03-R06.json'
    target.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
    generate_java(rows)
    print('R06',len(rows),'profiles',hashlib.sha256(target.read_bytes()).hexdigest())
