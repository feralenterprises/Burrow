#!/usr/bin/env python3
"""Make the complete 51-plan audit and five exact 11/28 reviews."""
import json,collections
from pathlib import Path
r=Path(__file__).resolve().parents[1];d=r/'docs/research'
old=json.loads((d/'BUR-OUTFITTER-WIKI-TIERS-03-R06.json').read_text())['profiles']
new=json.loads((d/'BUR-OUTFITTER-QUALITY-04-Q07.json').read_text())['profiles']
def key(p):return p['boss'],p['method'],p['tier']
prior={key(p):p for p in old}
def short(p):return p['boss']+(' — '+p['method'].split(',')[0] if p['boss']=='Dagannoth Kings' else '')
def occupied(p):return sum(x is not None for x in p['inventory'])
def weapon(p):return p['gear'][4]['name'] if p['gear'][4] else 'empty'
def changes(a,b):
 return [str(i+1)+': '+(a['gear'][i]['name'] if a['gear'][i] else 'empty')+' → '+(b['gear'][i]['name'] if b['gear'][i] else 'empty') for i in range(11) if a['gear'][i]!=b['gear'][i]]
lines=['# BUR-OUTFITTER-QUALITY-04 — all 51 loadouts audited','','Release **HOLD**. Q07 is a TrashPanda Tracker curated recommendation set. The official OSRS Wiki supports combat mechanics and ranked item choices; it does not prescribe the exact Q07 28-cell budgets. R04 and R06 remain immutable comparison sources. Community leads for Obor/Bryophyta stay distinct.','','**Inventory budget:** one to several kills, not a guaranteed kill count. The table shows occupied cells before and after; every plan retains exactly 28 positions and explicit empty cells. Items normally have quantity 1 per cell; bolts and runes are identified as stacks in Q07. The complete 11/28 slot data and item IDs are in JSON.','','| Boss/method | Tier | Weapon before → after | Gear changes | Inventory cells before → after | Official strategy/mechanics |','|---|---|---|---:|---:|---|']
for p in new:
 a=prior[key(p)];url=p['official_wiki'].split('?')[0]
 lines.append(f"| {short(p)} | {p['tier']} | {weapon(a)} → {weapon(p)} | {len(changes(a,p))} | {occupied(a)} → {occupied(p)} | [Wiki]({url}) |")
lines+=['','## Significant corrections and justified overlaps','']
seen=set()
for p in new:
 label=short(p)
 if label in seen:continue
 seen.add(label)
 lines.append(f"- **{label}:** {p['notes'][0]}")
lines+=['','## Charge and provenance decisions','',
'- The [Dragonfire ward Wiki page](https://oldschool.runescape.wiki/w/Dragonfire_ward) identifies item ID 22003 as uncharged and 22002 as charged. The charged ID does **not** prove 50 stored charges; inspect the shield in game before departure. Q07 retains it only in KBD and Vorkath Optimal. Their Recommended tiers instead use an anti-dragon shield. This resolves all four prior placeholders by changing two to the practical shield and giving the other two charged ID 22002.',
'- No Q07 plan claims its curated food counts or exact inventory cells are verbatim Wiki templates. Obor/Bryophyta have first-gate keys in all three tiers, labeled conditional; the Wiki says gate unlock does not consume the key and later entry does not require one. Bryophyta has a woodcutting axe, not a battleaxe. F2P Entry omits members-only antipoison/prayer potions.',
'- The official pages consulted on 2026-10-30 were Obor, Bryophyta and 13 strategy pages: Scurrius, Brutus, Giant Mole, Vorkath, Phantom Muspah, Sarachnis, The Hueycoatl, Amoxliatl, KBD, Grotesque Guardians, Zulrah, Barrows and Dagannoth Kings. Source URLs are embedded per profile. The R04 pinned rendered layout remains separately preserved.',
'','## Open owner judgments','','- **KBD Optimal:** DHCB, Masori and charged ward are high value through Wilderness transit. The Wiki discusses risk limits; a player may prefer Recommended for protected-item safety. No automatic account/risk adaptation is implemented.',
'- **Hueycoatl Entry:** the Wiki lists Glacial temotli as a tail multi-hit option; practical kill rate depends on team size and player levels. The Q07 food/prayer budget is a starting point.',
'- **Brutus:** Rune scimitar remains Recommended and Optimal because the F2P ranking favors it; the late tier changes shield/food rather than inventing a stronger F2P melee weapon. Mooleta is a boss drop.',
'- **Scurrius and Grotesque Guardians:** Bone mace and Granite hammer overlap across tiers because their encounter roles persist; armour/accessories and supply budgets distinguish tiers.',
'- **Zulrah:** the supported method is magic-only, with slower Tanzanite phases. A hybrid method needs separate research and approval.',
'- **All supply budgets:** TPT starting quantities have not been measured in native RuneLite for Zokeroth or any other account. Adjust after observed kill count and consumption; account-aware balancing is outside this ticket.',
'- **All item sprites:** IDs were validated against RuneLite 1.13.4 constants, but native sprite appearance and ward 50-charge Check require owner client proof.','']
(d/'BUR-OUTFITTER-QUALITY-04-AUDIT.md').write_text('\n'.join(lines))

five=['Obor','Bryophyta','Amoxliatl','Giant Mole','King Black Dragon']
slot=['Head','Cape','Neck','Ammunition','Weapon','Body','Offhand','Legs','Hands','Feet','Ring']
out=['# BUR-OUTFITTER-QUALITY-04 — five full three-tier reviews','','These are TPT curated short-trip loadouts. All equipment and inventory cells are shown; `—` is intentionally empty. Numbered inventory positions are UI positions, not a promise that every item is consumed. Wiki mechanic/ranking links are provided for each encounter.','']
for boss in five:
 ps={p['tier']:p for p in new if p['boss']==boss}
 assert len(ps)==3
 a,b,c=(ps[t] for t in ('Entry','Recommended','Optimal'))
 out += [f'## {boss}', '', f"Official reference: {a['official_wiki'].split('?')[0]}", '',a['notes'][0], '', '| Equipment slot | Entry | Recommended | Optimal |','|---|---|---|---|']
 for i,name in enumerate(slot):
  vals=[ps[t]['gear'][i]['name'] if ps[t]['gear'][i] else '—' for t in ('Entry','Recommended','Optimal')]
  out.append('| '+' | '.join([name,*vals])+' |')
 out += ['','| Inventory position | Entry | Recommended | Optimal |','|---:|---|---|---|']
 for i in range(28):
  vals=[]
  for t in ('Entry','Recommended','Optimal'):
   x=ps[t]['inventory'][i];vals.append('—' if x is None else x['name']+(f" ×{x['quantity']}" if x['quantity']!=1 else ''))
  out.append('| '+' | '.join([str(i+1),*vals])+' |')
 out+=['',f"**Occupied slots:** Entry {occupied(a)}, Recommended {occupied(b)}, Optimal {occupied(c)}. Keys are first-gate/optional-chest items on Obor/Bryophyta and should be removed on repeat normal visits.",'']
(d/'BUR-OUTFITTER-QUALITY-04-FIVE-REVIEWS.md').write_text('\n'.join(out))
print('Audit',len(new),'profiles; five full reviews',len((d/'BUR-OUTFITTER-QUALITY-04-FIVE-REVIEWS.md').read_text().splitlines()),'lines')
