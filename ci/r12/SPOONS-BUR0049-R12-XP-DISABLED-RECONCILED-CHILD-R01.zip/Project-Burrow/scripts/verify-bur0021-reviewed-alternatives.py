#!/usr/bin/env python3
"""R08 offline-only proof: reviewed conditional supply alternatives are NOT a live catalog rebase."""
import json,hashlib,pathlib,collections,csv
ROOT=pathlib.Path(__file__).resolve().parents[1]
RS=ROOT/'src/main/resources/gg/feral/burrow/outfitter'
PROPOSAL=RS/'BUR-0021-REVIEWED-SUPPLIES-R02.json'
BASE=RS/'BUR-OUTFITTER-MASTER-FINAL-06-LOADOUTS.json'
CONTRACT=ROOT/'docs/coordination/SPOONS-BUR-0021-R08/CONDITIONAL-ALTERNATIVES-CONTRACT.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(BASE)=='165f0781ab4e0e738235833e51dee04c21f30825cc8b3ab421c051e48e6dbe98','canonical dataset was changed'
assert sha(PROPOSAL)=='db073789da709f5c08287f044f1237355ca7c6057135268975a930094291c068','not Noodles reviewed proposal'
data=json.loads(BASE.read_text());proposal=json.loads(PROPOSAL.read_text());contract=json.loads(CONTRACT.read_text());counts=0
assert len(data['profiles'])==51 and len(proposal['patches'])==len(contract['options'])==5
assert proposal['production_autoload'] is False and contract['production_autoload'] is False
assert all(x['allow_promotion_to_production'] is False for x in contract['options'])
by_id={p['profile_id']:p for p in data['profiles']};by_option={o['profile_id']:o for o in contract['options']}
assert len(by_id)==51 and len(by_option)==5
assert len({p['boss'] for p in data['profiles']})==15
assert len({(p['boss'],p['method']) for p in data['profiles']})==17
assert all(len(p['gear'])==11 and len(p['inventory'])==28 for p in data['profiles'])
assert all(p['final_verdict']=='APPROVED WITH CONDITIONS' for p in data['profiles'])
expected={'sarachnis-entry','sarachnis-recommended','sarachnis-optimal','kbd-entry','vork-entry'}
assert set(by_option)==expected

def ids(a):return collections.Counter((v['item_id'],v['quantity']) for v in a if v is not None)
def trusted_synthetic_preview(patch,opt,actual_eq,actual_inv,synthetic_verified):
    # TEST-ONLY fixture. NOT a production trust decision or RuneLite bank observation.
    if not synthetic_verified:return patch['before_inventory']
    g=opt['guard'];key=g['item_id']
    have=(key in actual_inv) if g['guard_type']=='INVENTORY_CONTAINS_ITEM' else (actual_eq.get(g['equipment_slot'])==key)
    return patch['after_inventory'] if have else patch['before_inventory']

for patch in proposal['patches']:
    pid=patch['profile_id'];opt=by_option[pid];p=by_id[pid];b=patch['before_inventory'];a=patch['after_inventory']
    assert b==p['inventory'],(pid,'baseline divergence')
    assert len(a)==len(b)==28
    assert opt['boss']==p['boss'] and opt['method']==p['method'] and opt['tier']==p['tier']
    hasher=lambda x: hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    assert opt['expected_baseline_inventory_sha256']==hasher(b)
    assert opt['expected_conditional_inventory_sha256']==hasher(a)
    eq=p['gear']; inv=p['inventory']; g=opt['guard']; iid=g['item_id']
    if g['guard_type']=='EQUIPMENT_SLOT_EQUALS_ITEM':
        assert eq[g['equipment_slot']] is not None and eq[g['equipment_slot']]['item_id']==iid,pid
    else:
        assert any(item and item['item_id']==iid for item in inv),pid
    assert ids(b)-ids(a)==collections.Counter({(g['remove_item_id'],1):1}),pid
    add=ids(a)-ids(b)
    assert add==(collections.Counter() if g['replacement_item_id'] is None else collections.Counter({(g['replacement_item_id'],1):1})),pid
    expected_eq={i:v['item_id'] for i,v in enumerate(eq) if v};expected_inv={v['item_id'] for v in inv if v}
    assert trusted_synthetic_preview(patch,opt,expected_eq,expected_inv,False)==b,'unverified observation MUST fail closed'
    assert trusted_synthetic_preview(patch,opt,expected_eq,expected_inv,True)==a,'correct controlled synthetic guard should match'
    missing_eq={i:x for i,x in expected_eq.items() if x!=iid};missing_inv=expected_inv-{iid}
    assert trusted_synthetic_preview(patch,opt,missing_eq,missing_inv,True)==b,'missing guard MUST fail closed'
    if pid.startswith('sarachnis'):
        assert g['remove_item_id']==946 and g['replacement_item_id'] is None
    else:
        assert g['remove_item_id']==11951 and g['replacement_item_id']==2452 and g['duration_minutes']==6
        assert eq[6] and eq[6]['item_id']==1540
        # All poison/venom protection rows survive the substitution unchanged.
        for item_id in (5952,2446):
            assert ids(b)[(item_id,1)]==ids(a)[(item_id,1)]
    counts+=1

muspah=by_id['muspah-optimal'];assert any(v and v['item_id']==561 and v['quantity']>=20 for v in muspah['inventory']),'unsafe nature rune removal'
assert {v['profile_id'] for v in proposal['explicit_rejections']}=={'muspah-optimal'}
assert contract['mode']=='RESEARCH_CATALOG_RESOURCE_STAGED_NO_RUNTIME_REBASE'
assert contract['current_dataset_sha256']==sha(BASE)
print('R08 SAFE CONDITIONAL RESOURCE PASS: 5/5 conditional candidates; 5/5 unverified and 5/5 missing-gear negatives blocked')
print('FINAL06 unchanged: 15 bosses, 17 methods, 51 profiles, 561 gear cells, 1428 inventory cells; 20 Muspah Nature runes retained')
print('PRODUCTION REBASE BLOCKED: no authenticated gear-aware host integration or approved default antifire substitution')
