#!/usr/bin/env python3
"""Research-artifact identity & static profile geometry checks (not game runtime tests)."""
import pathlib,json,hashlib,collections,sys
root=pathlib.Path(__file__).resolve().parents[1]
file=root/'src/main/resources/gg/feral/burrow/outfitter/BUR-OUTFITTER-MASTER-FINAL-06-LOADOUTS.json'
expected='165f0781ab4e0e738235833e51dee04c21f30825cc8b3ab421c051e48e6dbe98'
actual=hashlib.sha256(file.read_bytes()).hexdigest();assert actual==expected,(actual,expected)
p=json.loads(file.read_text())['profiles'];assert len(p)==51
methods=set();bosses=set();keys=set();cells=collections.Counter()
for x in p:
  k=(x['boss'],x['method'],x['tier']);assert k not in keys,k;keys.add(k)
  assert x['final_verdict']=='APPROVED WITH CONDITIONS'
  assert len(x['gear'])==11 and len(x['inventory'])==28,k
  assert x['final_verdict_conditions'] and x['quest_equipment_prerequisites']
  for field in ('gear','inventory'):
    for index,item in enumerate(x[field]):
      cells[field]+=1
      if item is not None:
        assert isinstance(item['item_id'],int) and item['item_id']>0,(k,field,index,item)
        assert isinstance(item['quantity'],int) and item['quantity']>0,(k,field,index,item)
  methods.add((x['boss'],x['method']));bosses.add(x['boss'])
assert len(methods)==17 and len(bosses)==15 and cells=={'gear':561,'inventory':1428}
for boss,method in methods:
  assert {tier for b,m,tier in keys if b==boss and m==method}=={'Entry','Recommended','Optimal'}
print('FINAL06 RESEARCH INPUT PASS: SHA-256='+actual+'; 15 bosses, 17 methods, 51 profiles, 561+1428 positions; all positive selected IDs')
print('NOTE: This is data identity/geometry, not Java 17, gameplay, or native RuneLite validation.')
