#!/usr/bin/env python3
"""Spoons-only frozen-base / isolated-lane preflight and staged merge.

This does not compile Java, verify RuneLite behavior, or approve any equipment.
It never writes to the source ZIP or canonical project. Assemble only after
reviewing three handbacks; the new output remains RELEASE HOLD.
"""
import argparse
import copy
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
import tempfile
import zipfile

BASE_SHA = '82acd195e2a273e6a55760f05cfe64c8611e175128acbf5126a9fb561d8e9075'
P = 'Project-Burrow/'
DATA = P + 'src/main/resources/gg/feral/burrow/outfitter/BUR-OUTFITTER-MASTER-FINAL-06-LOADOUTS.json'
REG = P + 'BURROW-TICKETS.json'
GENERATED = (
    P + 'src/main/java/gg/feral/burrow/core/TieredOutfitterCatalog.java',
    P + 'src/main/java/gg/feral/burrow/core/Final06ProfileMetadata.java',
    P + 'src/test/resources/gg/feral/burrow/outfitter/final06-expected.tsv',
)
SPORKS_ALLOWED = {
    P + 'src/main/java/gg/feral/burrow/ui/BurrowPanel.java',
    P + 'src/test/java/gg/feral/burrow/ui/OutfitterStyleInteractionTest.java',
    P + 'src/test/java/gg/feral/burrow/ui/OutfitterStyleInteractionJUnitTest.java',
}
NOODLES_ALLOWED = set(GENERATED) | {
    DATA,
    P + 'scripts/generate-final06.py',
    P + 'scripts/verify-final06.py',
    P + 'scripts/VERIFY-BUR-0039-JAVA17-WINDOWS.ps1',
    P + 'src/test/java/gg/feral/burrow/core/Final06CatalogTest.java',
}
TONGS_ALLOWED = {
    P + 'docs/audits/BUR-0046-INDEPENDENT-COVERAGE.md',
    P + 'docs/audits/BUR-0046-METHOD-COVERAGE-MATRIX.csv',
    P + 'scripts/audit-bur0046-coverage.py',
    P + 'src/test/java/gg/feral/burrow/ui/BUR0046CombatStyleCoverageTest.java',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_zip(path):
    result = {}
    with zipfile.ZipFile(path) as z:
        if z.testzip() is not None:
            raise ValueError(f'Corrupt archive: {path}')
        for info in z.infolist():
            name = info.filename.replace('\\', '/')
            if info.is_dir():
                continue
            parts = pathlib.PurePosixPath(name).parts
            if (name.startswith('/') or '..' in parts or '.' in parts or
                    not parts or '\x00' in name or ':' in parts[0] or name in result):
                raise ValueError(f'Unsafe or duplicate ZIP path: {name}')
            result[name] = z.read(info)
    return result


def allowed(role, name):
    # Explicit allowlists for actual, inspected handbacks. No wildcard modifications.
    return name in {'sporks': SPORKS_ALLOWED, 'noodles': NOODLES_ALLOWED,
                    'tongs': TONGS_ALLOWED}.get(role, set())


def inspect_manifest(role, patch, source):
    import json
    manifests = {
      'sporks': 'BUR-0040-PATCH-MANIFEST.json',
      'noodles': 'PATCH-MANIFEST.json',
      'tongs': 'PATCH-MANIFEST.json',
    }
    manifest = json.loads(patch[manifests[role]])
    claimed = manifest.get('candidate_sha256') or manifest.get('baseline_archive_sha256') or manifest.get('baseline_sha256')
    if claimed != BASE_SHA:
        raise ValueError(f'{role}: wrong base identity in manifest')
    expected = {'sporks': SPORKS_ALLOWED, 'noodles': NOODLES_ALLOWED,
                'tongs': TONGS_ALLOWED}[role]
    missing = expected.difference(patch)
    if missing:
        raise ValueError(f'{role}: required patch sources missing: {sorted(missing)}')
    # Every contributor's exact source files are verified against published hashes.
    records = manifest.get('modified_files_sha256') if role == 'sporks' else (
        {x['path']: x['patched_sha256'] for x in manifest['source_modified_paths']} if role == 'noodles'
        else manifest.get('files', {}))
    for path in expected:
        if sha(patch[path]) != records.get(path):
            raise ValueError(f'{role}: source file checksum mismatch: {path}')
    if role == 'noodles':
        for x in manifest['source_modified_paths']:
            if sha(source[x['path']]) != x['baseline_sha256']:
                raise ValueError('Noodles baseline source mismatch: '+x['path'])


def diff(role, source, patch):
    changed = {}
    for name, contents in patch.items():
        if name == REG:
            if contents != source.get(name):
                raise ValueError(f'{role}: canonical ticket register is Spoons-only')
            continue
        if contents == source.get(name):
            continue
        if not name.startswith(P):
            # A contributor's standalone handback is intake evidence, not source.
            if name.endswith(('.md', '.json', '.txt', '.csv', '.patch', '.log', '.png')) and '/' not in name:
                continue
            raise ValueError(f'{role}: unexpected outside-project path {name}')
        if not allowed(role, name):
            raise ValueError(f'{role}: out-of-lane modification: {name}')
        changed[name] = contents
    if role == 'sporks' and not any('/src/' in n for n in changed):
        raise ValueError('sporks: no changed UI source/test artifact to integrate')
    if role == 'tongs' and not changed:
        raise ValueError('tongs: no independent read-only research artifact')
    return changed


def invariant_register(before, after):
    a = json.loads(before)
    b = json.loads(after)
    original = {t['id']: t for t in a['tickets']}
    updated = {t['id']: t for t in b['tickets']}
    if len(original) != 47 or len(updated) != 48 or len(set(updated)) != 48:
        raise ValueError('Ticket cardinality/uniqueness changed')
    if not all(k in updated for k in original):
        raise ValueError('Existing permanent ticket ID missing')
    if set(updated) != set(original) | {'BUR-0048'} or b['next_unused_id'] != 'BUR-0049':
        raise ValueError('Vorkath ticket mapping or next-unused ID changed')
    if b['release_gate'] != 'HOLD':
        raise ValueError('Release HOLD was changed')
    for k, orig in original.items():
        if k not in {'BUR-0039', 'BUR-0040', 'BUR-0046'} and orig != updated[k]:
            raise ValueError(f'Unauthorized existing ticket alteration: {k}')
    if updated['BUR-0048']['feature'] != 'Outfitter / Vorkath / Gear Quality':
        raise ValueError('BUR-0048 was repurposed')


def invariant_profiles(before, after):
    a = json.loads(before)
    b = json.loads(after)
    pa, pb = a['profiles'], b['profiles']
    key = lambda x: (x['boss'], x['method'], x['tier'])
    aa, bb = {key(x): x for x in pa}, {key(x): x for x in pb}
    if (len(pa), len(pb), len(aa), len(bb)) != (51, 51, 51, 51) or set(aa) != set(bb):
        raise ValueError('Existing 51 profile identities changed')
    if len({(x[0], x[1]) for x in bb}) != 17 or len({x[0] for x in bb}) != 15:
        raise ValueError('Boss/method count changed')
    for k, x in bb.items():
        if len(x['gear']) != 11 or len(x['inventory']) != 28:
            raise ValueError(f'Profile slot geometry changed: {k}')
        if k[0] != 'Vorkath' and x != aa[k]:
            raise ValueError(f'Gear lane modified a non-Vorkath profile: {k}')
    # P1 authorization is precisely Recommended Ranged Vorkath boots, no other change.
    differences = [(k, aa[k], bb[k]) for k in aa if aa[k] != bb[k]]
    if differences:
        if len(differences) != 1 or differences[0][0] != ('Vorkath', 'Ranged crossbow', 'Recommended'):
            raise ValueError('Unapproved profile change beyond Vorkath Recommended Ranged')
        _, old, new = differences[0]
        for field in old.keys() | new.keys():
            if field not in {'gear', 'item_acquisition_conditions'} and old.get(field) != new.get(field):
                raise ValueError('Unapproved Vorkath field change: '+field)
        if len(old['gear']) != len(new['gear']) or any(old['gear'][i] != new['gear'][i] for i in range(11) if i != 9):
            raise ValueError('Unapproved Vorkath gear slot change')
        if (old['gear'][9].get('item_id'),new['gear'][9].get('item_id')) != (11840, 19921):
            raise ValueError('Incorrect Vorkath boot substitution')
        if not new.get('item_acquisition_conditions'):
            raise ValueError('Boot acquisition conditions missing')
    if a == b:
        return 'NO_DATA_CHANGE'
    ac = copy.deepcopy(a)
    bc = copy.deepcopy(b)
    ac.pop('profiles')
    bc.pop('profiles')
    if ac != bc:
        raise ValueError('Dataset top-level metadata changed; needs separately reviewed Spoons exception')
    return 'VORKATH_ONLY_DATA_CHANGE'


def write_zip(path, files):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=7) as z:
        for name, data in sorted(files.items()):
            z.writestr(name, data)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base', required=True, type=pathlib.Path)
    p.add_argument('--spoons-patch', required=True, type=pathlib.Path)
    p.add_argument('--sporks', type=pathlib.Path)
    p.add_argument('--noodles', type=pathlib.Path)
    p.add_argument('--tongs', type=pathlib.Path)
    p.add_argument('--output', type=pathlib.Path, help='Write isolated integrated HOLD candidate (requires all three lanes)')
    p.add_argument('--report', type=pathlib.Path, help='Write staging / preflight JSON receipt')
    args = p.parse_args()
    if sha(args.base.read_bytes()) != BASE_SHA:
        raise ValueError('Base SHA mismatch; refusing all merges')
    source = read_zip(args.base)
    coordinator = read_zip(args.spoons_patch)
    expected = {REG, P+'scripts/verify-parallel-f06.py'}
    if not expected.issubset(coordinator) or not all(k.startswith(P) for k in coordinator):
        raise ValueError('Spoons coordination patch structure invalid')
    if any(k not in source and k.startswith(P+'src/') for k in coordinator):
        raise ValueError('Coordinator patch illegally adds gameplay code/data')
    invariant_register(source[REG], coordinator[REG])
    # Spoons may update register, instructions, and this stand-alone preflight tool only.
    for name, data in coordinator.items():
        if data != source.get(name) and name != REG and name != P+'scripts/verify-parallel-f06.py' and not name.startswith(P+'docs/coordination/BUR-P1-PARALLEL-F06/'):
            raise ValueError(f'Unexpected coordinator modification: {name}')
    stages = {role: getattr(args,role) for role in ('sporks','noodles','tongs')}
    edits = {}
    report = {'base_sha256': BASE_SHA,'release': 'HOLD', 'status':'PREFLIGHT_ONLY', 'lane_status':{}, 'coordinator_ticket_count':48,
              'native_run': 'NOT_TESTED', 'integrated_java17_build':'NOT_RUN'}
    occupied = {}
    for role, file in stages.items():
        if file is None:
            report['lane_status'][role] = {'status':'AWAITING_HANDOFF'}
            continue
        patch = read_zip(file)
        inspect_manifest(role, patch, source)
        changes = diff(role, source, patch)
        if set(changes) != {'sporks':SPORKS_ALLOWED,'noodles':NOODLES_ALLOWED,'tongs':TONGS_ALLOWED}[role]:
            raise ValueError(f'{role}: unexpected missing or extra source changes')
        for name in changes:
            if name in occupied:
                raise ValueError(f'Overlapping contributor edits: {name} ({role} vs {occupied[name]})')
            occupied[name] = role
        edits.update(changes)
        report['lane_status'][role] = {'status':'SCOPE_PREFLIGHT_PASS','sha256':sha(file.read_bytes()), 'changed_paths':sorted(changes)}
    mode='NOT_CHECKED'
    if args.noodles:
        proposed = edits.get(DATA,source[DATA]); mode=invariant_profiles(source[DATA],proposed)
        report['profile_verdict'] = mode
    if args.output:
        if not all(stages.values()):
            raise ValueError('Refusing integrated output: all three current handbacks required')
        candidate = dict(source)
        candidate.update(coordinator)
        candidate.update(edits)
        invariant_profiles(source[DATA],candidate[DATA])
        if mode == 'VORKATH_ONLY_DATA_CHANGE':
            # Generator regenerates the two Java source files plus TSV. Verify byte identity.
            with tempfile.TemporaryDirectory(prefix='burrow-f06-merge-') as tmp:
                dest = pathlib.Path(tmp)
                for name, contents in candidate.items():
                    path = dest/name
                    path.parent.mkdir(parents=True,exist_ok=True)
                    path.write_bytes(contents)
                root = dest/'Project-Burrow'
                for script in ('scripts/generate-final06.py','scripts/verify-final06.py'):
                    r=subprocess.run([sys.executable,str(root/script)],cwd=root,text=True,capture_output=True)
                    if r.returncode:
                        raise ValueError(f'{script} FAILED (no integration): {r.stdout[-1600:]} {r.stderr[-1600:]}')
                for name in GENERATED:
                    actual = (dest/name).read_bytes()
                    if actual != candidate[name]:
                        raise ValueError(f'Generated file drift: {name} (do not auto-repair)')
        else:
            # Unchanged dataset still needs valid pinned identity.
            with tempfile.TemporaryDirectory(prefix='burrow-f06-verify-') as tmp:
                dest=pathlib.Path(tmp)
                for name in (DATA,P+'scripts/verify-final06.py'):
                    path=dest/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(candidate[name])
                r=subprocess.run([sys.executable,str(dest/(P+'scripts/verify-final06.py'))],text=True,capture_output=True)
                if r.returncode:
                    raise ValueError('FINAL06 verifier failed: '+r.stderr[-1600:])
        report['status']='STATIC_STAGED_CANDIDATE_REQUIRES_JDK17_AND_TARGETED_NATIVE'
        if args.output.resolve()==args.base.resolve():
            raise ValueError('Never overwrite frozen starting candidate')
        if args.output.exists():
            raise ValueError('Integrated output exists; refusing overwrite')
        args.output.parent.mkdir(parents=True,exist_ok=True)
        write_zip(args.output,candidate)
        report['integrated_zip_sha256']=sha(args.output.read_bytes())
        report['integrated_file_count']=len(candidate)
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        if args.report.exists():
            raise ValueError('Report already exists; refusing overwrite')
        args.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, OSError, zipfile.BadZipFile) as e:
        sys.exit('HOLD: '+str(e))
