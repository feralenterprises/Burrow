#!/usr/bin/env python3
"""Validate every Q07 item, slot, supply and critical boss pairing."""
import hashlib,json
from collections import Counter,defaultdict
from pathlib import Path
r=Path(__file__).resolve().parents[1]
data=json.loads((r/'docs/research/BUR-OUTFITTER-QUALITY-04-Q07.json').read_text())
old=(r/'docs/research/BUR-OUTFITTER-WIKI-TIERS-03-R06.json').read_bytes()
assert hashlib.sha256(old).hexdigest()==data['parent_r06_sha256']
ids={a:int(b) for a,b in (s.split('=') for s in (r/'docs/research/BUR-RUNELITE-1.13.4-ITEMIDS.txt').read_text().splitlines())}
methods=defaultdict(set);counts=Counter();wards=[]
twohand={ids[k] for k in ('TWISTED_BOW','BOW_OF_FAERDHINEN_C','SCYTHE_OF_VITUR','SOULREAPER_AXE','DUAL_MACUAHUITL','TUMEKENS_SHADOW')}
regular={ids[k] for k in ('RUBY_BOLTS_E','DIAMOND_BOLTS_E')}
dragon={ids[k] for k in ('RUBY_DRAGON_BOLTS_E','DIAMOND_DRAGON_BOLTS_E')}
for p in data['profiles']:
 key=(p['boss'],p['method']);tier=p['tier'];methods[key].add(tier);counts[tier]+=1
 assert len(p['gear'])==11 and len(p['inventory'])==28,(key,tier,'geometry')
 assert p['authority'].startswith('TPT_CURATED') and p['official_wiki'].startswith('https://oldschool.runescape.wiki/w/')
 assert p['trip_plan'].startswith('Short trip')
 for place,items in (('gear',p['gear']),('inventory',p['inventory'])):
  for i,x in enumerate(items,1):
   if x is None:continue
   assert isinstance(x['item_id'],int) and x['item_id']>0 and x['quantity']>0,(key,tier,place,i,x)
   if 'id_evidence' in x:
    const=x['id_evidence'].removeprefix('RuneLite 1.13.4 ItemID.')
    assert ids[const]==x['item_id'],(key,tier,place,i,x)
   else:assert x['item_id'] in ids.values(),(key,tier,place,i,x)
   if x['item_id']==ids['DRAGONFIRE_WARD']:
    assert place=='gear' and i==7 and '50 charges' in ' '.join(p['notes'])
    wards.append((key,tier))
 w=p['gear'];weapon=w[4]['item_id'] if w[4] else None
 assert weapon not in twohand or w[6] is None,(key,tier,'two-hand/offhand')
 if weapon==ids['RUNE_CROSSBOW']:assert w[3] and w[3]['item_id'] in regular,(key,tier,'rune bolts')
 if weapon in (ids['DRAGON_CROSSBOW'],ids['DRAGON_HUNTER_CROSSBOW']):assert w[3] and w[3]['item_id'] in dragon,(key,tier,'dragon bolts')
 if weapon==ids['BOW_OF_FAERDHINEN_C']:
  assert [w[i]['item_id'] for i in (0,5,7)]==[ids[k] for k in ('CRYSTAL_HELM','CRYSTAL_BODY','CRYSTAL_LEGS')]
  assert w[3] is None
 if weapon==ids['DUAL_MACUAHUITL']:
  assert [w[i]['item_id'] for i in (0,5,7)]==[ids[k] for k in ('BLOOD_MOON_HELM','BLOOD_MOON_CHESTPLATE','BLOOD_MOON_TASSETS')]
 # All product switch plans must have room to store the equipped weapon and
 # defender; consuming a supply is not relied upon.
 switches={ids[k] for k in ('ECLIPSE_ATLATL','DUAL_MACUAHUITL','GLACIAL_TEMOTLI')}
 if any(x and x['item_id'] in switches for x in p['inventory']):
  free=sum(x is None for x in p['inventory'])
  assert free>=(2 if w[6] else 1),(key,tier,'switch capacity',free)
 # Quantity sanity: one short trip, with explicit spare space for drops.
 assert sum(x is not None for x in p['inventory'])<=23,(key,tier,'supply clutter')
 if p['boss']=='Bryophyta':assert any(x and x['item_id']==ids['RUNE_AXE'] for x in p['inventory'])
 if p['boss']=='Brutus':assert any(x and x['item_id']==ids['COWBELL_AMULET_33104'] for x in p['inventory'])
 if p['boss']=='Dagannoth Kings':assert any(x and x['item_id']==ids['PET_ROCK'] for x in p['inventory'])
 if p['boss'] in ('King Black Dragon','Vorkath') and tier=='Optimal':assert w[6]['item_id']==22002
 if p['boss'] in ('King Black Dragon','Vorkath') and tier=='Recommended':assert w[6]['item_id']==1540
assert len(data['profiles'])==51 and len(methods)==17 and len({b for b,m in methods})==15
assert all(t=={'Entry','Recommended','Optimal'} for t in methods.values())
assert counts=={'Entry':17,'Recommended':17,'Optimal':17}
assert len(wards)==2 and all(t=='Optimal' for _,t in wards),wards
print('Q07 PASS: 51/51 plans, all exact IDs, 11/28 slots, capacity, crossbow bolts, 2-handed pairings, F2P/encounter items; 2 charged ward IDs 22002 (check 50 charges)')
