#!/usr/bin/env python3
"""Validate R06 source lineage, item IDs, geometry and equipment pairings."""
import hashlib, json
from collections import Counter, defaultdict
from pathlib import Path

root=Path(__file__).resolve().parents[1]
research=root/'docs/research'
data=json.loads((research/'BUR-OUTFITTER-WIKI-TIERS-03-R06.json').read_text())
parent=(research/'BUR-OUTFITTER-S01-R04-LOADOUTS.json').read_bytes()
assert data['parent_r04_sha256']==hashlib.sha256(parent).hexdigest()
ids={k:int(v) for k,v in (line.split('=') for line in
    (research/'BUR-RUNELITE-1.13.4-ITEMIDS.txt').read_text().splitlines())}
by_method=defaultdict(set);unknown=[];counts=Counter()
two_handed={ids[k] for k in ('TWISTED_BOW','BOW_OF_FAERDHINEN_C','SCYTHE_OF_VITUR',
    'SOULREAPER_AXE','DUAL_MACUAHUITL','TUMEKENS_SHADOW')}
crossbows={ids[k] for k in ('RUNE_CROSSBOW','DRAGON_HUNTER_CROSSBOW')}
regular_bolts={ids[k] for k in ('RUBY_BOLTS_E','DIAMOND_BOLTS_E','SAPPHIRE_BOLTS_E')}
dragon_bolts={ids[k] for k in ('RUBY_DRAGON_BOLTS_E','DIAMOND_DRAGON_BOLTS_E','SAPPHIRE_DRAGON_BOLTS_E')}
for p in data['profiles']:
    key=(p['boss'],p['method']);by_method[key].add(p['tier']);counts[p['tier']]+=1
    assert p['official_wiki'].startswith('https://oldschool.runescape.wiki/w/')
    assert len(p['gear'])==11 and len(p['inventory'])==28
    for location,items in (('gear',p['gear']),('inventory',p['inventory'])):
        for position,item in enumerate(items,1):
            if item is None:continue
            assert item['quantity']>0,(key,p['tier'],location,position)
            if item['item_id'] is None:
                unknown.append((key,p['tier'],location,position,item['name']))
                assert item['name']=='Dragonfire ward' and position==7 and location=='gear'
            elif 'id_evidence' in item:
                name=item['id_evidence'].removeprefix('RuneLite 1.13.4 ItemID.')
                assert ids[name]==item['item_id'],(key,p['tier'],location,position)
            else:
                assert item['item_id'] in ids.values(),(key,p['tier'],location,position)
    worn=p['gear'];weapon=worn[4]['item_id'] if worn[4] else None
    assert weapon not in two_handed or worn[6] is None,(key,p['tier'],'2h offhand')
    if weapon==ids['BOW_OF_FAERDHINEN_C']:
        assert worn[0]['item_id']==ids['CRYSTAL_HELM'] and worn[5]['item_id']==ids['CRYSTAL_BODY'] and worn[7]['item_id']==ids['CRYSTAL_LEGS']
        assert worn[3] is None
    if weapon==ids['RUNE_CROSSBOW']:
        assert worn[3]['item_id'] in regular_bolts
        assert all(i['item_id'] not in dragon_bolts for i in p['inventory'] if i)
    if weapon==ids['DRAGON_HUNTER_CROSSBOW']:
        assert worn[3]['item_id'] in dragon_bolts
    if weapon==ids['DUAL_MACUAHUITL']:
        assert [worn[i]['item_id'] for i in (0,5,7)]==[ids[k] for k in ('BLOOD_MOON_HELM','BLOOD_MOON_CHESTPLATE','BLOOD_MOON_TASSETS')]
    if p['authority'].startswith('TPT_CURATED'):
        switches={ids['DUAL_MACUAHUITL'],ids['ECLIPSE_ATLATL']}
        if worn[6] is not None and any(i and i['item_id'] in switches for i in p['inventory']):
            assert None in p['inventory'],(key,p['tier'],'switch capacity')
assert len(data['profiles'])==51 and len(by_method)==17
assert all(v=={'Entry','Recommended','Optimal'} for v in by_method.values())
assert counts=={'Entry':17,'Recommended':17,'Optimal':17}
assert len({b for b,m in by_method})==15
assert len(unknown)==4 and all(x[-1]=='Dragonfire ward' for x in unknown)
rex=next(x for x in data['profiles'] if x['boss']=='Dagannoth Kings' and x['method'].startswith('Rex') and x['tier']=='Recommended')
assert all(rex['inventory'][i-1]['item_id']==5952 for i in (4,8,11,12,16,20))
print('R06 PASS: 51 plans, 15 bosses, 17 methods, 11/28 geometry, ID constants and equipment pairings; 4 ward charge cells unresolved')
