#!/usr/bin/env python3
"""Fail closed on R05 provenance, parent preservation, and tier geometry."""
import hashlib, json
from pathlib import Path

root=Path(__file__).resolve().parents[1]/'docs/research'
parent_bytes=(root/'BUR-OUTFITTER-S01-R04-LOADOUTS.json').read_bytes()
parent=json.loads(parent_bytes)
dataset=json.loads((root/'BUR-OUTFITTER-WIKI-TIERS-02-R05.json').read_bytes())
assert dataset['parent_sha256']==hashlib.sha256(parent_bytes).hexdigest()
baseline={(r['boss'],r['encounter_method']):r for r in parent['records']}
assert len(dataset['profiles'])==len(baseline)*3==51
available={'Entry':0,'Recommended':0,'Optimal':0}
for row in dataset['profiles']:
    source=baseline[(row['boss'],row['method'])]
    if row['status']=='UNAVAILABLE':
        assert row['equipment'] is None and row['inventory'] is None
        continue
    available[row['tier']]+=1
    assert source['verification_status']=='VERIFIED'
    assert len(row['equipment'])==11 and len(row['inventory'])==28
    assert row['inventory']==source['inventory']
    if row['tier']=='Recommended':
        assert row['equipment']==source['equipment']
    else:
        assert row['tier']=='Entry' and row['boss'] in ('Scurrius','Brutus')
        assert row['source_authority']=='PRODUCT_COMBINATION_OF_WIKI_RANKED_ALTERNATIVES_WITH_R04_INVENTORY'
    if row['boss']=='Dagannoth Kings' and row['tier']=='Recommended':
        for position in (4,8,11,12,16,20):
            assert row['inventory'][position-1]['item']['item_id']==5952
    for cell in row['equipment']+row['inventory']:
        item=cell.get('item')
        assert item is None or item['item_id'] is None or isinstance(item['item_id'],int)
assert available=={'Entry':2,'Recommended':13,'Optimal':0}
print('R05 RESEARCH PASS: 51 method/tier records, 15 available; all R04 layouts and Rex IDs retained')
