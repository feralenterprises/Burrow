package gg.feral.burrow.runelite;

import gg.feral.burrow.core.Outfitter;
import java.util.Arrays;

/** Burrow's existing resolved positions; no stock reads, ranking or ownership inference. */
final class L01LayoutSpecification {
    private final int[] ids;
    private L01LayoutSpecification(int[] ids) { this.ids=ids.clone(); }
    int[] itemIds() { return ids.clone(); }
    static L01LayoutSpecification from(Outfitter.Plan plan) {
        if (plan == null) throw new IllegalArgumentException("No vetted loadout for selected boss");
        int[] ids=new int[56]; Arrays.fill(ids,-1);
        for (var cell:plan.cells()) if(cell.requirement()!=null)
            ids[cell.position()]=cell.requirement().itemId();
        return new L01LayoutSpecification(ids);
    }
}
