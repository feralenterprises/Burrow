package gg.feral.burrow.runelite;

import gg.feral.burrow.core.BurrowModel;
import java.util.function.Supplier;
import net.runelite.api.*;
import net.runelite.api.events.*;
import net.runelite.api.widgets.WidgetInfo;
import net.runelite.client.plugins.PluginManager;
import net.runelite.client.plugins.banktags.BankTagsPlugin;
import net.runelite.client.plugins.banktags.BankTagsService;

/** Client-thread-only ownership. O toggles one temporary Bank Tags layout. */
final class OutfitterBank {
    private final Client client;
    private final PluginManager plugins;
    private final Supplier<BurrowModel.Selection> selection;
    private final BankWidgetAdapter button;
    private final Supplier<L01BankLayout.Provider> providers;
    private BankWidgetAdapter.Entry bound;
    private L01BankLayout layout;
    private BurrowModel.Selection shown;
    private boolean active=true;

    OutfitterBank(Client client, PluginManager plugins, Supplier<BurrowModel.Selection> selection) {
        this.client=client;this.plugins=plugins;this.selection=selection;
        button=new BankWidgetAdapter(client);
        providers=this::findProvider;
    }
    // Test seam supplies a provider, while using real RuneLite widget/API types.
    OutfitterBank(Client client, Supplier<BurrowModel.Selection> selection,
                  Supplier<L01BankLayout.Provider> providers) {
        this.client=client;this.plugins=null;this.selection=selection;this.providers=providers;
        button=new BankWidgetAdapter(client);
    }
    private boolean bankOpen() {
        var root=client.getWidget(WidgetInfo.BANK_CONTAINER);
        var items=client.getWidget(WidgetInfo.BANK_ITEM_CONTAINER);
        var pin=client.getWidget(WidgetInfo.BANK_PIN_CONTAINER);
        return active && client.getGameState()==GameState.LOGGED_IN && root!=null && !root.isHidden()
            && items!=null && !items.isHidden() && (pin==null || pin.isHidden());
    }
    void refresh() {
        if(!bankOpen()) { clear();return; }
        if(layout!=null) {
            if(!layout.selected() || shown!=selection.get()) closeLayout();
            else layout.maintain();
        }
        var next=button.refresh();
        if(next!=null && next!=bound) {
            bound=next;
            button.bind(next,()->{if(active && bankOpen() && button.current(next))toggle();});
        } else if(next==null) bound=null;
    }
    private void toggle() {
        if(layout!=null && layout.selected()) { closeLayout();return; }
        closeLayout();
        var selected=selection.get();
        if(selected==null || selected.plan()==null) { status("No vetted loadout for the selected boss.");return; }
        var provider=providers.get();
        if(provider==null)return;
        var owned=new L01BankLayout(provider);
        layout=owned;shown=selected;
        try {
            owned.open(L01LayoutSpecification.from(selected.plan()),
                ()->bankOpen() && layout==owned && selection.get()==selected);
            status(selected.boss()+" Wiki plan: equipment left, supplies right. Unspecified variants are omitted. O or All items returns to bank. Highlighting OFF.");
        } catch(RuntimeException e) { closeLayout();status("Layout unavailable: "+e.getMessage()); }
    }
    private L01BankLayout.Provider findProvider() {
        BankTagsPlugin provider=null;
        for(var plugin:plugins.getPlugins()) if(plugins.isPluginEnabled(plugin)) {
            if(plugin instanceof BankTagsService tags && tags.getActiveTag()!=null) {
                status("Close the active Bank Tags / Inventory Setups view first.");return null;
            }
            if(plugin.getClass().getName().equals("com.questhelper.QuestHelperPlugin")) {
                try { if(Boolean.TRUE.equals(plugin.getClass().getMethod("isBankTabOpen").invoke(plugin))) {
                    status("Close the Quest Helper bank view first.");return null;
                }} catch(ReflectiveOperationException e) { status("Quest Helper bank-view state unavailable.");return null; }
            }
            if(plugin instanceof BankTagsPlugin tags) provider=tags;
        }
        if(provider==null) { status("Enable RuneLite's Bank Tags plugin, then click O again.");return null; }
        return new RuneLiteL01BankTags(plugins,provider);
    }
    /** Immutable published rectangle; overlay never dereferences live RuneLite widgets. */
    java.awt.Rectangle chestBounds() { return active?button.pressBounds():null; }
    boolean chestHasPlan() {
        var current=selection.get();
        return active && current!=null && current.plan()!=null;
    }
    void menuAdded(MenuEntryAdded e) { if(active)button.routeMenu(e.getMenuEntry()); }
    void menuClicked(MenuOptionClicked e) { if(active)button.selectMenu(e); }
    void clear() { closeLayout();bound=null;button.clear(); }
    void stop() { active=false;clear(); }
    private void closeLayout() {
        var old=layout;layout=null;shown=null;
        if(old!=null)old.close();
    }
    private void status(String message) {
        client.addChatMessage(ChatMessageType.GAMEMESSAGE,"","Burrow Outfitter: "+message,null);
    }
}
