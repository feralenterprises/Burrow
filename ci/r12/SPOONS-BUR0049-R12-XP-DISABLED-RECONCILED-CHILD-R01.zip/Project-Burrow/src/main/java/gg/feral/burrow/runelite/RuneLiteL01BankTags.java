package gg.feral.burrow.runelite;

import net.runelite.client.plugins.PluginManager;
import net.runelite.client.plugins.banktags.BankTagsPlugin;
import net.runelite.client.plugins.banktags.TagManager;
import net.runelite.client.plugins.banktags.tabs.Layout;
import net.runelite.client.plugins.banktags.tabs.LayoutManager;

/** Public upstream APIs only. Optional dependency discovered from the actual enabled plugin instance. */
final class RuneLiteL01BankTags implements L01BankLayout.Provider {
    interface Store {
        Object profile();
        String tab();
        void tab(String value);
        Layout load(String name);
        void remove(String name);
        boolean hasTaggedItems(String name);
    }
    private final java.util.function.BooleanSupplier enabled;
    private final Store store;
    private final BankTagsPlugin plugin;
    private Layout owned;
    private Object originalProfile;
    private String previousTab;
    RuneLiteL01BankTags(PluginManager manager, BankTagsPlugin plugin) {
        this(plugin,new Store() {
            private <T> T api(Class<T> type){return plugin.getInjector().getInstance(type);}
            public Object profile(){return api(net.runelite.client.config.ConfigManager.class).getProfile();}
            public String tab(){return api(net.runelite.client.plugins.banktags.BankTagsConfig.class).tab();}
            public void tab(String value){api(net.runelite.client.plugins.banktags.BankTagsConfig.class).tab(value);}
            public Layout load(String name){return api(LayoutManager.class).loadLayout(name);}
            public void remove(String name){api(LayoutManager.class).removeLayout(name);}
            public boolean hasTaggedItems(String name){return !api(TagManager.class).getItemsForTag(name).isEmpty();}
        },()->manager.isPluginEnabled(plugin));
    }
    RuneLiteL01BankTags(BankTagsPlugin plugin, Store store, java.util.function.BooleanSupplier enabled) {
        this.plugin=plugin;this.store=store;this.enabled=enabled;
    }
    public boolean available() { return enabled.getAsBoolean(); }
    public String activeTag() { return plugin.getActiveTag(); }
    public Layout activeLayout() { return plugin.getActiveLayout(); }
    public boolean nameInUse(String name) {
        return store.load(name)!=null || store.hasTaggedItems(name);
    }
    public void open(String name,Layout layout) {
        // openBankTag loads a persisted LayoutManager layout. The public concrete overload accepts
        // an explicit Layout and reaches the identical TabInterface + bank script lifecycle without saving it.
        // An empty tag is intentional: LayoutManager draws all specified exact IDs, including untagged
        // items. It therefore does not fuzzily replace an exact variant from a broad membership filter.
        if(owned==null) { originalProfile=store.profile();previousTab=store.tab(); }
        owned=layout;
        plugin.openTag(name,layout,net.runelite.client.plugins.banktags.BankTagsService.OPTION_HIDE_TAG_NAME);
    }
    public void maintain() {
        if(owned==null || store.profile()!=originalProfile)return;
        var saved=store.load(owned.getTag());
        if(saved!=null && java.util.Arrays.equals(saved.getLayout(),owned.getLayout()))
            store.remove(owned.getTag()); // Native dragging can save even with OPTION_ALLOW_MODIFICATIONS off.
        // An independently replaced saved layout is left untouched.
    }
    public void close() {
        if(owned==null || plugin.getActiveLayout()!=owned || !owned.getTag().equals(plugin.getActiveTag())) {
            owned=null;previousTab=null;originalProfile=null;return;
        }
        maintain();
        String current=store.tab();
        String restore=owned!=null && owned.getTag().equals(current)
            ? (store.profile()==originalProfile?previousTab:"") : current;
        plugin.closeBankTag();
        // closeBankTag normally clears remembered tab; preserve the current profile's prior value.
        if(store.tab().isEmpty() && restore!=null && !restore.isEmpty())store.tab(restore);
        owned=null;previousTab=null;originalProfile=null;
    }
}
