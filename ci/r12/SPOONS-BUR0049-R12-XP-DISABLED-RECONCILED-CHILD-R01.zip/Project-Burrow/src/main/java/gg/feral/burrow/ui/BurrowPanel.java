package gg.feral.burrow.ui;

import gg.feral.burrow.core.*;
import gg.feral.burrow.core.Outfitter.*;
import gg.feral.burrow.core.TieredOutfitterCatalog.Tier;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.function.IntFunction;
import javax.swing.*;
import java.util.*;

/** 225px native-scale, single-pass Swing painter. No nested BoxLayout or reentrant UI mutation. */
public final class BurrowPanel extends JPanel {
    public static final int WIDTH=225, HEIGHT=1390;
    private static final Color BG=new Color(13,17,18), PANEL=new Color(30,29,26);
    private static final Color LINE=new Color(92,75,48), GOLD=new Color(245,177,65);
    private static final Color MINT=new Color(128,198,125), TEXT=new Color(240,230,207);
    private static final Color MUTED=new Color(173,164,146), BAD=new Color(219,134,116);
    private final BurrowModel model;
    private final IntFunction<BufferedImage> itemImage;
    private final boolean illustrativePreview;
    private int hoveredNav = -1;
    // BUR-0019: render a local item label on ordinary mouse movement. Swing's
    // native tooltip routing can be suppressed by the RuneLite host, so this
    // does not depend on a modifier key or ToolTipManager delays.
    private String hoveredItemText;
    private int hoveredItemX, hoveredItemY;
    private int hoveredViewportY;
    String hoveredItemTextForTest() { return model.view()==BurrowModel.View.OUTFITTER ? hoveredItemText : null; }
    // BUR-0040: UI-only explanation for a style with no verified method.
    private String styleFeedback;
    String styleFeedbackForTest() { return styleFeedback; }
    private String availableMethodForStyle(String style) {
        for (String method : model.methods())
            if (style.equals(TieredOutfitterCatalog.style(model.boss(), method))) return method;
        return null;
    }
    private static final int CONTENT_SHIFT = 65;
    private static final int PREPARATION_Y = 1014;
    private static final Font PREPARATION_FONT = new Font("Dialog", Font.PLAIN, 10);
    // BUR-0035: make PvP travel risk visible without relying on a tooltip.
    private static final int KBD_WARNING_SHIFT = 72;
    static boolean showsWildernessTravelWarning(String boss) {
        return "King Black Dragon".equals(boss);
    }
    private boolean showsWildernessTravelWarning() {
        return showsWildernessTravelWarning(model.boss());
    }
    private static final String KBD_WARNING_TOOLTIP =
        "Usual routes to King Black Dragon cross PvP Wilderness; " +
        "the King Black Dragon's lair itself is outside the Wilderness.";
    // This is intentionally NOT part of the recommendation plan or demo bank snapshot.
    private LiveWeapon observedWeapon = LiveWeapon.offline();
    private LiveCombat observedCombat = LiveCombat.offline();
    private QuestRecommendation observedQuest = QuestRecommendation.offline();
    public QuestRecommendation observedQuest() { return observedQuest; }
    public void setObservedQuest(QuestRecommendation quest) {
        if (!SwingUtilities.isEventDispatchThread())
            throw new IllegalStateException("Quest display requires Swing EDT");
        observedQuest = Objects.requireNonNull(quest, "quest");
        repaint();
    }
    public LiveCombat observedCombat() { return observedCombat; }
    public void setObservedCombat(LiveCombat snapshot) {
        if (!SwingUtilities.isEventDispatchThread())
            throw new IllegalStateException("Live combat display requires Swing EDT");
        observedCombat = Objects.requireNonNull(snapshot, "snapshot");
        repaint();
    }
    public void setObservedWeapon(LiveWeapon observed) {
        if (!SwingUtilities.isEventDispatchThread())
            throw new IllegalStateException("Equipment display requires Swing EDT");
        observedWeapon = Objects.requireNonNull(observed);
        repaint();
    }
    public LiveWeapon observedWeapon() { return observedWeapon; }

    // BUR-0031: UI-only intake contract. Spoons must authenticate the source,
    // logical login epoch and event provenance BEFORE dispatching these records.
    // A Java record alone is not proof that a game event occurred.
    public enum SessionOrigin { VERIFIED_BRIDGE, SYNTHETIC_FIXTURE }
    public enum SessionState { OFFLINE, ACTIVE, SUSPENDED }
    public enum SessionFeed { XP, BOSS_KC, DROPS, SUPPLIES }
    public enum FeedStatus { NOT_CONNECTED, AVAILABLE, UNAVAILABLE }
    public record SessionScope(String accountToken, String loginEpoch) {
        public SessionScope {
            if (accountToken == null || accountToken.isBlank() || loginEpoch == null || loginEpoch.isBlank())
                throw new IllegalArgumentException("authenticated scope required");
        }
    }
    public sealed interface SessionEvent permits SessionStart, SessionStop, SessionPause,
        SessionResume, SessionFeedStatus, SessionXpGain, SessionBossKcGain, SessionDrop, SessionSupplyUsed {
        SessionScope scope();
        String eventId();
        SessionOrigin origin();
    }
    public record SessionStart(SessionScope scope, String eventId, SessionOrigin origin) implements SessionEvent {}
    /** Only a confirmed final authenticated logout, NOT a world-hop/loading transition. */
    public record SessionStop(SessionScope scope, String eventId, SessionOrigin origin) implements SessionEvent {}
    public record SessionPause(SessionScope scope, String eventId, SessionOrigin origin) implements SessionEvent {}
    public record SessionResume(SessionScope scope, String eventId, SessionOrigin origin) implements SessionEvent {}
    public record SessionFeedStatus(SessionScope scope, String eventId, SessionOrigin origin,
                                    SessionFeed feed, FeedStatus status) implements SessionEvent {}
    /** Positive already-baselined same-login delta; never raw absolute skill XP. */
    public record SessionXpGain(SessionScope scope, String eventId, SessionOrigin origin,
                                String skill, long delta, String sourceEvidence) implements SessionEvent {}
    /** Positive already-baselined BUR-0025 delta; never a raw KC or fictional kill. */
    public record SessionBossKcGain(SessionScope scope, String eventId, SessionOrigin origin,
                                    String boss, long delta, String sourceEvidence) implements SessionEvent {}
    /** Boss may be null: unproven attribution MUST stay Unassigned. */
    public record SessionDrop(SessionScope scope, String eventId, SessionOrigin origin,
                              int itemId, String itemName, long amount, String boss,
                              String sourceEvidence) implements SessionEvent {}
    /** Verified consumption only; item-container withdrawals are NOT use evidence. */
    public record SessionSupplyUsed(SessionScope scope, String eventId, SessionOrigin origin,
                                    int itemId, String itemName, long amount, String sourceEvidence) implements SessionEvent {}
    public record SessionItem(int itemId, String itemName, String attribution, long quantity) {}
    public record SessionReadout(SessionState state, boolean synthetic, long totalXp,
                                 Map<String,Long> xpBySkill, Map<String,Long> kcByBoss,
                                 java.util.List<SessionItem> drops, java.util.List<SessionItem> supplies,
                                 Map<SessionFeed,FeedStatus> feeds) {}

    private SessionScope activeSessionScope;
    private SessionOrigin activeSessionOrigin;
    private SessionState activeSessionState=SessionState.OFFLINE;
    private final Set<SessionScope> retiredSessionScopes=new HashSet<>();
    private final Set<String> acceptedSessionEventIds=new HashSet<>();
    private final EnumMap<SessionFeed,FeedStatus> sessionFeeds=new EnumMap<>(SessionFeed.class);
    private final Map<String,Long> sessionXp=new LinkedHashMap<>();
    private final Map<String,Long> sessionKc=new LinkedHashMap<>();
    private final Map<String,SessionItem> sessionDrops=new LinkedHashMap<>();
    private final Map<String,SessionItem> sessionSupplies=new LinkedHashMap<>();
    private long sessionTotalXp;

    /** Immutable defensive projection; never persists or reads another login's activity. */
    public SessionReadout sessionReadout() {
        return new SessionReadout(activeSessionState,activeSessionOrigin==SessionOrigin.SYNTHETIC_FIXTURE,
            sessionTotalXp,Map.copyOf(sessionXp),Map.copyOf(sessionKc),
            java.util.List.copyOf(sessionDrops.values()),java.util.List.copyOf(sessionSupplies.values()),
            Map.copyOf(sessionFeeds));
    }
    private void wipeSessionData() {
        sessionTotalXp=0;
        sessionXp.clear();sessionKc.clear();sessionDrops.clear();sessionSupplies.clear();
        acceptedSessionEventIds.clear();sessionFeeds.clear();
        for(SessionFeed feed:SessionFeed.values())sessionFeeds.put(feed,FeedStatus.NOT_CONNECTED);
    }
    /** EDT-only, source-validated typed input. This patch does NOT register any RuneLite event handler. */
    public boolean ingestSessionEvent(SessionEvent event) {
        if (!SwingUtilities.isEventDispatchThread())
            throw new IllegalStateException("Session UI intake requires Swing EDT");
        Objects.requireNonNull(event,"event");
        Objects.requireNonNull(event.scope(),"scope");
        Objects.requireNonNull(event.origin(),"origin");
        if(event.eventId()==null || event.eventId().isBlank())throw new IllegalArgumentException("event identity required");
        if(event instanceof SessionStart) {
            if(retiredSessionScopes.contains(event.scope()))return false;
            if(activeSessionScope!=null && activeSessionScope.equals(event.scope()))return false;
            if(activeSessionScope!=null)retiredSessionScopes.add(activeSessionScope);
            wipeSessionData();
            activeSessionScope=event.scope();activeSessionOrigin=event.origin();
            activeSessionState=SessionState.ACTIVE;
            acceptedSessionEventIds.add(event.eventId());
            revalidate();repaint();return true;
        }
        // Wrong-account callbacks and late old-epoch Swing events are ignored.
        if(activeSessionScope==null || !activeSessionScope.equals(event.scope()) ||
            activeSessionOrigin!=event.origin() || acceptedSessionEventIds.contains(event.eventId()))return false;
        if(event instanceof SessionStop) {
            retiredSessionScopes.add(activeSessionScope);
            wipeSessionData();activeSessionScope=null;activeSessionOrigin=null;
            activeSessionState=SessionState.OFFLINE;
        } else if(event instanceof SessionPause) {
            if(activeSessionState!=SessionState.ACTIVE)return false;
            activeSessionState=SessionState.SUSPENDED;
        } else if(event instanceof SessionResume) {
            if(activeSessionState!=SessionState.SUSPENDED)return false;
            activeSessionState=SessionState.ACTIVE;
        } else {
            if(activeSessionState!=SessionState.ACTIVE)return false;
            if(event instanceof SessionFeedStatus e) {
                Objects.requireNonNull(e.feed(),"feed");Objects.requireNonNull(e.status(),"status");
                sessionFeeds.put(e.feed(),e.status());
            } else if(event instanceof SessionXpGain e) {
                checkSessionRow(e.skill(),e.delta(),e.sourceEvidence());
                sessionTotalXp=Math.addExact(sessionTotalXp,e.delta());
                sessionXp.merge(e.skill(),e.delta(),Math::addExact);
                sessionFeeds.put(SessionFeed.XP,FeedStatus.AVAILABLE);
            } else if(event instanceof SessionBossKcGain e) {
                checkSessionRow(e.boss(),e.delta(),e.sourceEvidence());
                sessionKc.merge(e.boss(),e.delta(),Math::addExact);
                sessionFeeds.put(SessionFeed.BOSS_KC,FeedStatus.AVAILABLE);
            } else if(event instanceof SessionDrop e) {
                checkSessionItem(e.itemId(),e.itemName(),e.amount(),e.sourceEvidence());
                String boss=e.boss()==null || e.boss().isBlank()?"Unassigned":e.boss();
                addSessionItem(sessionDrops,e.itemId(),e.itemName(),boss,e.amount());
                sessionFeeds.put(SessionFeed.DROPS,FeedStatus.AVAILABLE);
            } else if(event instanceof SessionSupplyUsed e) {
                checkSessionItem(e.itemId(),e.itemName(),e.amount(),e.sourceEvidence());
                addSessionItem(sessionSupplies,e.itemId(),e.itemName(),"Confirmed use",e.amount());
                sessionFeeds.put(SessionFeed.SUPPLIES,FeedStatus.AVAILABLE);
            } else throw new IllegalArgumentException("unsupported event");
        }
        acceptedSessionEventIds.add(event.eventId());
        revalidate();repaint();return true;
    }
    private static void checkSessionRow(String name,long delta,String proof) {
        if(name==null||name.isBlank()||delta<=0||proof==null||proof.isBlank())
            throw new IllegalArgumentException("positive sourced delta required");
    }
    private static void checkSessionItem(int id,String name,long qty,String proof) {
        if(id<=0)throw new IllegalArgumentException("actual item ID required");
        checkSessionRow(name,qty,proof);
    }
    private static void addSessionItem(Map<String,SessionItem> map,int id,String name,String attribution,long amount) {
        String key=id+"/"+attribution;
        SessionItem prior=map.get(key);
        long count=prior==null?amount:Math.addExact(prior.quantity(),amount);
        map.put(key,new SessionItem(id,name,attribution,count));
    }

    public BurrowPanel(BurrowModel m) { this(m, false, id -> null); }
    public BurrowPanel(BurrowModel m, IntFunction<BufferedImage> itemImage) { this(m, false, itemImage); }
    /** Used only by offline owner-review renderer; NEVER constructed by RuneLite plugin. */
    public BurrowPanel(BurrowModel m, boolean illustrativePreview) { this(m, illustrativePreview, id -> null); }
    private BurrowPanel(BurrowModel m, boolean illustrativePreview, IntFunction<BufferedImage> itemImage) {
        this.illustrativePreview=illustrativePreview;
        this.itemImage=Objects.requireNonNull(itemImage);
        this.model=Objects.requireNonNull(m); wipeSessionData(); setMinimumSize(new Dimension(WIDTH,880));
        setOpaque(true); setBackground(BG);
        setToolTipText(" ");
        addMouseListener(new MouseAdapter(){
            public void mouseReleased(MouseEvent e) {
                if(!SwingUtilities.isLeftMouseButton(e))return;
                int y=e.getY()-CONTENT_SHIFT;
                if(isShowing() && model.view()==BurrowModel.View.OUTFITTER && inside(e.getX(),y,13,203,199,33)) {
                    JPopupMenu menu=new JPopupMenu();
                    for(String boss:VerifiedOutfitterCatalog.BOSSES) {
                        JMenuItem choice=new JMenuItem(boss);
                        choice.addActionListener(event->{model.chooseBoss(boss);styleFeedback=null;clearItemHover();revalidate();repaint();});
                        menu.add(choice);
                    }
                    menu.show(BurrowPanel.this,e.getX(),e.getY());
                } else if (model.view()==BurrowModel.View.OUTFITTER &&
                           inside(e.getX(),y,13,244,199,27)) {
                    // BUR-0038: a real strategy menu, never hidden click-to-cycle.
                    if(isShowing()) methodMenu().show(BurrowPanel.this,13,CONTENT_SHIFT+273);
                } else clickAt(e.getX(),e.getY());
            }
            public void mouseEntered(MouseEvent e) { updateItemHover(e); }
            public void mouseExited(MouseEvent e) {
                hoveredNav=-1; clearItemHover(); repaint();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter(){
            public void mouseDragged(MouseEvent e) { clearItemHover(); repaint(); }
            public void mouseMoved(MouseEvent e) {
                int next=navAt(e.getX(),e.getY());
                if(next!=hoveredNav) {hoveredNav=next;repaint();}
                updateItemHover(e);
            }
        });
    }
    /** BUR-0038: complete, source-backed method names in a native Swing dropdown.
     *  Package-private so focused UI tests can activate the same actual menu actions
     *  without displaying a window or manufacturing a new game method. */
    JPopupMenu methodMenu() {
        JPopupMenu menu=new JPopupMenu();
        menu.getAccessibleContext().setAccessibleName("Choose boss method");
        ButtonGroup group=new ButtonGroup();
        for (String method : model.methods()) {
            JRadioButtonMenuItem choice=new JRadioButtonMenuItem(method, method.equals(model.method()));
            choice.setToolTipText(method);
            group.add(choice);
            choice.addActionListener(event -> {
                model.chooseMethod(method);
                styleFeedback=null;
                clearItemHover();
                revalidate();
                repaint();
            });
            menu.add(choice);
        }
        return menu;
    }
    public BurrowModel model() { return model; }

    // The outer RuneLite JScrollPane owns the vertical scroll. Make the entire
    // preparation card as tall as its content instead of truncating the notes.
    @Override public Dimension getPreferredSize() {
        if(model!=null && model.view()==BurrowModel.View.SESSIONS)
            return new Dimension(WIDTH, Math.max(880,CONTENT_SHIFT+sessionContentBottom()+24));
        if (model == null || model.view() != BurrowModel.View.OUTFITTER)
            return new Dimension(WIDTH, 880);
        int shift=showsWildernessTravelWarning()?KBD_WARNING_SHIFT:0;
        int bottom=CONTENT_SHIFT + shift + PREPARATION_Y + preparationLayout().height() + 12;
        return new Dimension(WIDTH, Math.max(HEIGHT, bottom));
    }

    private PreparationNotesLayout.Layout preparationLayout() {
        VerifiedOutfitterCatalog.Profile profile=model.profile();
        if (profile==null) return PreparationNotesLayout.empty();
        var metadata=Final06ProfileMetadata.find(model.boss(),model.method(),model.tier());
        return PreparationNotesLayout.layout(profile.notes(),
            metadata==null?Collections.emptyList():SwitchNoteFormatter.formatSwitches(metadata.switches(), profile),
            getFontMetrics(PREPARATION_FONT), 183);
    }

    private void clearItemHover() { hoveredItemText=null; }

    private String itemHoverAt(int x, int y) {
        if(model.view()!=BurrowModel.View.OUTFITTER || model.profile()==null) return null;
        int contentY=y-CONTENT_SHIFT-(showsWildernessTravelWarning()?KBD_WARNING_SHIFT:0);
        int gear=gearIndex(x,contentY), inventory=inventoryIndex(x,contentY);
        VerifiedOutfitterCatalog.Item item=gear>=0?model.profile().gear().get(gear):
            inventory>=0?model.profile().inventory().get(inventory):null;
        return item==null?null:item.name()+(item.amount()>1?" × "+item.amount():
            item.amount()<0?" · quantity unspecified":"");
    }

    private void updateItemHover(MouseEvent event) {
        String next=itemHoverAt(event.getX(),event.getY());
        if(!Objects.equals(hoveredItemText,next) ||
                next!=null && (hoveredItemX!=event.getX() || hoveredItemY!=event.getY())) {
            hoveredItemText=next;
            hoveredItemX=event.getX(); hoveredItemY=event.getY();
            hoveredViewportY=getVisibleRect().y;
            repaint();
        }
    }

    /** Drawn inside the sidebar, so no Ctrl key, host popup or screen-wide tooltip. */
    private void paintItemHover(Graphics2D g) {
        if(hoveredItemText==null || model.view()!=BurrowModel.View.OUTFITTER) return;
        g.setFont(new Font("Dialog",Font.PLAIN,11));
        FontMetrics fm=g.getFontMetrics();
        Rectangle visible=getVisibleRect();
        // A scroll moved the item beneath a stationary mouse: discard stale text.
        if(visible.y!=hoveredViewportY) return;
        int availableWidth=visible.width>0?Math.min(WIDTH,visible.width):WIDTH;
        java.util.List<String> lines=wrapItemName(hoveredItemText,fm,Math.max(60,availableWidth-23));
        int width=0;
        for(String line:lines)width=Math.max(width,fm.stringWidth(line));
        width=Math.min(availableWidth-6,width+16);
        int height=lines.size()*15+10;
        int top=visible.height>0?visible.y:0;
        int bottom=visible.height>0?visible.y+visible.height:HEIGHT;
        int left=visible.width>0?visible.x:0;
        int x=Math.max(left+3,Math.min(hoveredItemX+10,left+Math.min(visible.width,WIDTH)-width-3));
        int y=hoveredItemY+15;
        if(y+height>bottom-3)y=hoveredItemY-height-12;
        y=Math.max(top+3,Math.min(y,Math.max(top+3,bottom-height-3)));
        g.setColor(new Color(11,15,16,245));g.fillRoundRect(x,y,width,height,5,5);
        g.setColor(GOLD);g.drawRoundRect(x,y,width-1,height-1,5,5);
        g.setColor(TEXT);
        for(int i=0;i<lines.size();i++)g.drawString(lines.get(i),x+8,y+16+i*15);
    }

    /** Splits long item names rather than truncating their identifying words. */
    private static java.util.List<String> wrapItemName(String text,FontMetrics fm,int maxWidth) {
        java.util.List<String> lines=new ArrayList<>();
        StringBuilder line=new StringBuilder();
        for(String word:text.split(" ")) {
            String candidate=line.length()==0?word:line+" "+word;
            if(line.length()>0 && fm.stringWidth(candidate)>maxWidth) {
                lines.add(line.toString()); line.setLength(0);
            }
            if(line.length()>0)line.append(' ');
            // Unusually long single-token names are broken without losing characters.
            for(int i=0;i<word.length();i++) {
                String attempt=line.toString()+word.charAt(i);
                if(fm.stringWidth(attempt)>maxWidth && line.length()>0) {
                    lines.add(line.toString()); line.setLength(0);
                }
                line.append(word.charAt(i));
            }
        }
        if(line.length()>0)lines.add(line.toString());
        return lines.isEmpty()?java.util.List.of(text):lines;
    }
    private static int navAt(int x,int y) {
        for(int i=0;i<4;i++) {
            int cx=8+(i%2)*106, cy=76+(i/2)*60;
            if(inside(x,y,cx,cy,103,56)) return i;
        }
        return -1;
    }
    @Override public String getToolTipText(MouseEvent e) {
        if(model.view()==BurrowModel.View.OUTFITTER) {
            int x=e.getX(), y=e.getY()-CONTENT_SHIFT;
            if(inside(x,y,13,203,199,33)) return "Select boss: " + model.boss();
            if(inside(x,y,13,244,199,27)) return model.method().isBlank()?"No registered method":
                "Choose method (" + model.methods().size() + " available): " + model.method();
            if(inside(x,y,13,299,199,31)) {
                Tier tier=Tier.values()[Math.min(2,(x-13)/66)];
                return TieredOutfitterCatalog.find(model.boss(),model.method(),tier)==null?
                    tier.label()+" setup unavailable":tier.label()+" · select setup";
            }
            if(inside(x,y,13,345,199,32)) {
                int style=Math.min(2,(x-13)/66);
                String selected=new String[]{"Melee","Ranged","Magic"}[style];
                String supportedMethod=availableMethodForStyle(selected);
                if(supportedMethod==null)
                    return "No verified " + selected + " method for " + model.boss() + "; choose an available style";
                return selected.equals(model.selectedStyle())
                    ? selected + " selected: " + model.method()
                    : "Switch to " + selected + ": " + supportedMethod;
            }
            if(showsWildernessTravelWarning() && inside(x,y,13,397,199,66))
                return KBD_WARNING_TOOLTIP;
            // Only the equipment/inventory/preparation content moves for KBD.
            // Boss, method, tier and style hitboxes retain their original positions.
            int contentY = y - (showsWildernessTravelWarning() ? KBD_WARNING_SHIFT : 0);
            if(inside(x,contentY,13,1210,199,36) && model.tierSelection()!=null)
                return model.tierSelection().authority()+" · "+model.tierSelection().provenance();
            VerifiedOutfitterCatalog.Profile profile=model.profile();
            if(profile!=null) {
                int gear=gearIndex(x,contentY), inv=inventoryIndex(x,contentY);
                if(gear>=0) return tooltip(profile.gear().get(gear));
                if(inv>=0) return tooltip(profile.inventory().get(inv));
                if(inside(x,contentY,13,1014,199,196)) {
                    var readiness=Final06ProfileMetadata.find(model.boss(),model.method(),model.tier());
                    return PreparationTooltip.render(
                        profile.notes(),
                        readiness == null ? Collections.emptyList() : readiness.questRequirements(),
                        readiness == null ? Collections.emptyList() : readiness.chargedStateRequirements(),
                        readiness == null ? Collections.emptyList() : SwitchNoteFormatter.formatSwitches(readiness.switches(), profile));
                }
            }
        }
        return switch(navAt(e.getX(),e.getY())) {
            case 0 -> "Home - account overview";
            case 1 -> "Pathfinder - progression";
            case 2 -> "Outfitter - boss preparation";
            case 3 -> "Sessions - this login only";
            default -> null;
        };
    }
    private static String tooltip(VerifiedOutfitterCatalog.Item item) {
        return item==null?null:item.name()+(item.id()>0?" · ID "+item.id():" · exact variant unspecified")+
            (item.amount()>1?" × "+item.amount():item.amount()<0?" · quantity unspecified":"");
    }
    private static int gearIndex(int x,int y) {
        int[] columns={1,0,1,2,0,1,2,1,0,1,2};
        int[] rows={0,1,1,1,2,2,2,3,4,4,4};
        for(int i=0;i<11;i++) if(inside(x,y,29+columns[i]*62,419+rows[i]*46,43,42))return i;
        return -1;
    }
    private static int inventoryIndex(int x,int y) {
        for(int i=0;i<28;i++) if(inside(x,y,16+(i%4)*49,698+(i/4)*42,42,39))return i;
        return -1;
    }

    /** Matches the pixel bounds of the controls painted below; no invisible full-width buttons. */
    private static boolean inside(int x, int y, int bx, int by, int bw, int bh) {
        return x >= bx && x < bx + bw && y >= by && y < by + bh;
    }

    /** Testable mouse routing with strict rectangular hitboxes and no hidden actions. */
    public void clickAt(int x, int y) {
        if (!inside(x, y, 0, 0, WIDTH, HEIGHT)) return;
        clearItemHover();
        int navIndex=navAt(x,y);
        if(navIndex>=0) {
            model.show(BurrowModel.View.values()[navIndex]);
            revalidate();
            repaint();
            return;
        }
        int sourceY=y-CONTENT_SHIFT; // Only historic non-Home pages use this coordinate system.
        switch (model.view()) {
            case OUTFITTER -> {
                if (inside(x,sourceY,13,203,199,33)) {
                    int index=VerifiedOutfitterCatalog.BOSSES.indexOf(model.boss());
                    model.chooseBoss(VerifiedOutfitterCatalog.BOSSES.get((index+1)%VerifiedOutfitterCatalog.BOSSES.size()));
                    styleFeedback=null;
                } else if (inside(x,sourceY,13,244,199,27)) {
                    // Method changes are deliberately menu-only; no silent cycling.
                } else if (inside(x,sourceY,13,299,199,31)) {
                    model.chooseTier(Tier.values()[Math.min(2,(x-13)/66)]);
                    styleFeedback=null;
                } else if (inside(x,sourceY,13,345,199,32)) {
                    String style=new String[]{"Melee","Ranged","Magic"}[Math.min(2,(x-13)/66)];
                    String candidate=availableMethodForStyle(style);
                    if(candidate!=null) {
                        // Only an existing verified method may change the selection.
                        model.chooseMethod(candidate);
                        styleFeedback=null;
                    } else {
                        // Keep boss/method/tier/plan intact; explain the rejected click.
                        styleFeedback="No verified " + style + " setup for this boss";
                    }
                }
            }
            case SESSIONS -> { /* Read-only activity feed: no demo buttons or reset shortcut. */ }
            case PATHFINDER -> {
                if (inside(x, sourceY, 17, 339, 190, 25)) model.chooseBoss("Vorkath");
                else if (inside(x, sourceY, 17, 368, 190, 25)) model.chooseBoss("Scurrius");
                else if (inside(x, sourceY, 17, 397, 190, 25)) model.chooseBoss("Barrows");
            }
            case HOME -> { /* A journal, not a shortcut into fake recommendations. */ }
        }
        if(model.view()==BurrowModel.View.OUTFITTER) revalidate();
        repaint();
    }
    @Override public void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g=(Graphics2D)g0.create();
        try {
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setColor(BG);g.fillRect(0,0,WIDTH,Math.max(HEIGHT,getHeight()));
            header(g); navigation(g);
            switch(model.view()) {
                case HOME -> home(g);
                case PATHFINDER -> { Graphics2D content=(Graphics2D)g.create();content.translate(0,CONTENT_SHIFT);pathfinder(content);content.dispose(); }
                case OUTFITTER -> { Graphics2D content=(Graphics2D)g.create();content.translate(0,CONTENT_SHIFT);outfitter(content);content.dispose(); }
                case SESSIONS -> { Graphics2D content=(Graphics2D)g.create();content.translate(0,CONTENT_SHIFT);sessions(content);content.dispose(); }
            }
            // The name label is a local mouse-hover overlay, not a host tooltip popup.
            paintItemHover(g);
            // Session observations are read-only; no demo kill-counter rendering.
        } finally { g.dispose(); }
    }
    // Compact shell: owner-supplied semantic pack icons, no repeated mascot nav tiles.
    private void header(Graphics2D g) {
        g.setPaint(new GradientPaint(0,0,new Color(39,34,27),0,70,new Color(15,20,21)));
        g.fillRect(0,0,WIDTH,70);
        g.setColor(new Color(112,83,45));g.drawLine(4,3,220,3);
        g.setColor(new Color(103,76,42));g.drawLine(6,69,219,69);
        Sprites.packBrand(g,7,6,55,55);
        carved(g,"TrashPanda",65,25,16,new Color(251,196,100));
        carved(g,"Tracker",65,42,17,TEXT);
        label(g,"We dig through your account",65,56,9,MUTED,false);
        label(g,"so you don't have to.",65,67,9,MUTED,false);
    }
    private void navigation(Graphics2D g) {
        String[] names={"Home","Pathfinder","Outfitter","Sessions"};
        g.setColor(new Color(12,17,18));g.fillRect(0,71,225,127);
        for(int i=0;i<4;i++) {
            int x=8+(i%2)*106,y=76+(i/2)*60,w=103,h=56;
            boolean selected=model.view().ordinal()==i,hover=hoveredNav==i;
            g.setPaint(new GradientPaint(x,y,selected?new Color(72,55,30):
                    hover?new Color(46,44,35):new Color(30,32,30),x,y+h,new Color(13,19,20)));
            g.fillRect(x,y,w,h);
            g.setColor(selected?GOLD:hover?new Color(159,129,79):new Color(67,70,65));
            g.drawRect(x,y,w-1,h-1);
            if(selected) {g.setColor(new Color(245,181,74));g.fillRect(x+6,y+1,w-12,2);}
            Sprites.nav(g,i,x+3,y+5,43,43);
            label(g,names[i],x+49,y+32,i==1?9:10,selected?new Color(252,204,117):TEXT,true);
        }
        g.setColor(new Color(126,96,52));g.drawLine(9,202,216,202);
    }
    private void title(Graphics2D g, String t, String s) {label(g,t,11,147,16,TEXT,true);small(g,s,11,165,MUTED);}
    private void card(Graphics2D g,int y,int h) {
        g.setColor(PANEL);g.fillRoundRect(9,y,207,h,9,9);
        g.setColor(LINE);g.drawRoundRect(9,y,207,h,9,9);
    }
    private void button(Graphics2D g,String text,int y,boolean active) {
        g.setColor(active?new Color(77,57,34):new Color(35,43,46));g.fillRoundRect(13,y,199,26,6,6);
        g.setColor(active?GOLD:LINE);g.drawRoundRect(13,y,199,26,6,6);
        small(g,text,24,y+17,active?GOLD:TEXT);
    }
    private void home(Graphics2D g) {
        g.setPaint(new GradientPaint(0,205,new Color(18,25,27),0,HEIGHT,new Color(11,16,18)));
        g.fillRect(0,205,WIDTH,HEIGHT-205);
        // Mountain art comes directly from owner's UI kit, not a generated dashboard texture.
        Sprites.landscape(g,8,210,209,68);
        g.setPaint(new GradientPaint(0,210,new Color(13,18,20,25),0,285,new Color(11,16,18,247)));
        g.fillRect(8,210,209,75);
        carved(g,"THE DEN",16,242,21,new Color(254,196,98));
        label(g,"ACCOUNT JOURNAL",16,259,9,TEXT,true);
        g.setColor(new Color(153,109,49));g.drawLine(11,280,213,280);
        if(illustrativePreview) sampleHome(g); else realHome(g);
    }
    private void realHome(Graphics2D g) {
        sectionBar(g,"CURRENT OBJECTIVE",299);
        // BUR-0017: visual-only waiting state. No fabricated goal or progress.
        waitingObjective(g);
        sectionBar(g,"LIVE FROM RUNELITE",457);
        signalRow(g,470,true);
        signalRow(g,520,false);
        g.setColor(new Color(88,76,53));g.drawLine(13,580,212,580);
        label(g,"Gear and combat update when you log in.",13,602,10,MUTED,false);
        // A small, honest den note fills the previously empty space without
        // inventing a player-stat table or an account-bound goal queue.
        g.setPaint(new GradientPaint(10,626,new Color(40,37,29),211,710,new Color(18,25,26)));
        g.fillRoundRect(10,626,205,87,8,8);
        g.setColor(LINE);g.drawRoundRect(10,626,205,87,8,8);
        Sprites.hero(g,151,641,58,57);
        label(g,"DEN NOTES",20,648,10,GOLD,true);
        label(g,"Only observed account data",20,670,9,TEXT,false);
        label(g,"appears here. Goals are",20,685,9,MUTED,false);
        label(g,"pending integration.",20,699,9,MUTED,false);
    }
    private void waitingObjective(Graphics2D g) {
        int y=313;
        g.setPaint(new GradientPaint(11,y,new Color(48,41,31),214,y+112,new Color(18,28,29)));
        g.fillRoundRect(11,y,203,112,7,7);
        g.setColor(new Color(144,105,52));g.drawRoundRect(11,y,203,112,7,7);
        // The original owner-approved raccoon asset, not a generated substitute.
        Sprites.avatar(g,124,y+13,78,76);
        carved(g,"No goal",19,y+29,15,TEXT);
        carved(g,"pinned",19,y+46,15,TEXT);
        label(g,"Goal tracking is",19,y+66,10,MUTED,false);
        label(g,"not connected yet.",19,y+81,10,MUTED,false);
        g.setColor(new Color(102,79,49));g.drawLine(19,y+94,205,y+94);
        label(g,"WAITING FOR VERIFIED GOAL",19,y+107,9,GOLD,true);
    }
    private void sampleHome(Graphics2D g) {
        g.setColor(new Color(136,51,39));g.fillRect(8,275,209,15);
        label(g,"LAYOUT EXAMPLE - NOT REAL ACCOUNT DATA",13,286,8,Color.WHITE,true);
        sectionBar(g,"CURRENT OBJECTIVE",309);
        focus(g,323,106,"Tombs of Amascut","Hunt the Osmumten's fang","Next: choose a verified loadout",true);
        sectionBar(g,"LATEST MILESTONE",468);
        row(g,482,"Quest completed","Song of the Elves",0);
        sectionBar(g,"LIVE FROM RUNELITE",551);
        signalRow(g,566,true);
        signalRow(g,620,false);
        g.setColor(new Color(150,49,39));g.drawLine(8,685,216,685);
        label(g,"SAMPLE DATA  •  NOT LIVE IN RUNE LITE",14,704,9,GOLD,true);
    }
    private void sectionBar(Graphics2D g,String label,int y) {
        g.setColor(new Color(25,31,30));g.fillRect(9,y-13,207,22);
        g.setColor(new Color(110,82,46));g.drawLine(9,y+9,216,y+9);
        g.setColor(new Color(185,132,59));g.fillRect(9,y-13,3,21);
        label(g,label,19,y+2,10,new Color(243,190,101),true);
    }
    private void focus(Graphics2D g,int y,int height,String title,String sub,String sub2,boolean hasProgress) {
        g.setPaint(new GradientPaint(11,y,new Color(48,41,31),214,y+height,new Color(21,29,29)));
        g.fillRect(11,y,203,height);
        g.setColor(new Color(144,105,52));g.drawRect(11,y,202,height-1);
        carved(g,title,19,y+37,title.length()>21?12:16,TEXT);
        label(g,sub,19,y+60,10,MUTED,false);
        label(g,sub2,19,y+75,10,MUTED,false);
        if(hasProgress) {
            g.setColor(new Color(48,54,47));g.fillRect(19,y+92,181,5);
            g.setColor(new Color(196,141,58));g.fillRect(19,y+92,51,5);
        } else {
            g.setColor(new Color(78,83,72));g.drawLine(19,y+91,199,y+91);
            label(g,"Awaiting verified account data",19,y+105,9,GOLD,false);
        }
    }
    private void row(Graphics2D g,int y,String label,String value,int icon) {
        Sprites.nav(g,icon,14,y,38,38);
        label(g,label,60,y+15,9,GOLD,true);
        clipped(g,value,60,y+31,TEXT,145);
        g.setColor(new Color(70,65,50));g.drawLine(12,y+41,213,y+41);
    }
    private void signalRow(Graphics2D g,int y,boolean weapon) {
        Sprites.signal(g,weapon,15,y,29,29);
        String title=weapon?"EQUIPPED WEAPON":"COMBAT LEVEL";
        String value;
        if(weapon) value=observedWeapon.state()==LiveWeapon.State.OFFLINE?
                "Sign in to inspect":observedWeapon.displayName();
        else {String lv=calculatedCombat();value=lv==null?
                (observedCombat.state()==LiveCombat.State.OFFLINE?"Sign in to inspect":observedCombat.status()):"Level "+lv;}
        label(g,title,54,y+10,9,GOLD,true);
        clipped(g,value,54,y+26,observedCombat.state()==LiveCombat.State.OBSERVED?MINT:TEXT,148);
        g.setColor(new Color(74,66,50));g.drawLine(13,y+42,212,y+42);
    }
    private void leather(Graphics2D g,int x,int y,int w,int h) {
        g.setPaint(new GradientPaint(x,y,new Color(48,43,32),x+w,y+h,new Color(23,28,28)));
        g.fillRect(x,y,w,h);
        g.setColor(new Color(177,121,51));g.drawRect(x,y,w-1,h-1);
        g.setColor(new Color(73,58,40));g.drawRect(x+3,y+3,w-7,h-7);
        g.setColor(new Color(224,159,70));
        for(int i=0;i<2;i++) {g.fillRect(x+6+i*(w-14),y+6,2,2);g.fillRect(x+6+i*(w-14),y+h-8,2,2);}
        g.setColor(new Color(73,59,38));g.drawLine(x+11,y+29,x+w-11,y+29);
    }
    private void section(Graphics2D g,String text,int baseline) {
        label(g,text,13,baseline,11,GOLD,true);
        g.setColor(new Color(125,89,43));
        FontMetrics fm=g.getFontMetrics();int x=Math.min(217,19+fm.stringWidth(text));
        g.drawLine(x,baseline-4,215,baseline-4);
    }
    private void chapter(Graphics2D g,String number,String text,int x,int y) {
        g.setColor(new Color(134,90,38));g.fillRect(x,y-13,24,18);
        label(g,number,x+5,y,10,new Color(252,221,154),true);
        label(g,text,x+30,y,11,GOLD,true);
    }
    private void progress(Graphics2D g,int x,int y,int w,int h,double ratio) {
        g.setColor(new Color(11,14,14));g.fillRect(x,y,w,h);
        g.setColor(new Color(116,88,47));g.drawRect(x,y,w-1,h-1);
        g.setPaint(new GradientPaint(x,y,new Color(92,174,112),x,y+h,new Color(43,101,80)));
        g.fillRect(x+2,y+2,(int)Math.round((w-4)*Math.max(0,Math.min(1,ratio))),h-4);
    }
    private void liveBox(Graphics2D g,int y) {
        leather(g,7,y,211,112);
        drawSignal(g,18,y+26,"WEAPON",observedWeapon.state()==LiveWeapon.State.OFFLINE?"Sign in to inspect":observedWeapon.displayName(),
                observedWeapon.state()==LiveWeapon.State.EQUIPPED);
        g.setColor(new Color(90,70,44));g.drawLine(17,y+53,208,y+53);
        String level=calculatedCombat();
        drawSignal(g,18,y+81,"COMBAT",level==null?(observedCombat.state()==LiveCombat.State.OFFLINE?"Sign in to inspect":observedCombat.status()):"Level " + level + "  •  observed",
                level!=null);
    }
    private String calculatedCombat() {
        if(observedCombat.state()!=LiveCombat.State.OBSERVED)return null;
        int atk=observedCombat.level(0),str=observedCombat.level(1),def=observedCombat.level(2);
        int hp=observedCombat.level(3),rng=observedCombat.level(4),mag=observedCombat.level(5),pray=observedCombat.level(6);
        double base=0.25*(def+hp+Math.floor(pray/2.0));
        double style=0.325*Math.max(atk+str,Math.max(Math.floor(rng*1.5),Math.floor(mag*1.5)));
        return Integer.toString((int)Math.floor(base+style));
    }
    private void drawSignal(Graphics2D g,int x,int y,String title,String value,boolean live) {
        g.setColor(new Color(23,28,28));g.fillRect(x,y-17,29,29);
        g.setColor(new Color(111,88,47));g.drawRect(x,y-17,28,28);
        Sprites.nav(g,title.equals("WEAPON")?2:3,x+2,y-16,25,25);
        label(g,title,x+38,y-8,9,GOLD,true);
        clipped(g,value,x+38,y+8,live?MINT:TEXT,151);
    }
    private void carved(Graphics2D g,String word,int x,int y,int fontSize,Color color) {
        g.setFont(new Font("Serif",Font.BOLD,fontSize));
        g.setColor(Color.BLACK);g.drawString(word,x+1,y+1);
        g.setColor(color);g.drawString(word,x,y);
    }
    private void frame(Graphics2D g,int x,int y,int w,int h,boolean hero) {
        g.setColor(hero?new Color(39,34,27):new Color(30,32,30));g.fillRect(x,y,w,h);
        g.setColor(new Color(114,80,39));g.drawRect(x,y,w-1,h-1);
        g.setColor(new Color(65,54,36));g.drawRect(x+2,y+2,w-5,h-5);
        g.setColor(hero?GOLD:new Color(160,110,46));g.drawLine(x+5,y+1,x+w-6,y+1);
    }
    private void tag(Graphics2D g,String s,int x,int y) {
        g.setColor(new Color(125,90,39));g.fillRect(x,y-13,3,13);
        label(g,s,x+9,y,11,GOLD,true);
    }
    private void pathfinder(Graphics2D g) {
        title(g,"PATHFINDER","Verified quest signal / preview tools");
        // BUR-0018: visual refinement only. One observed quest signal; the
        // independent goal-state helper is NOT wired to this UI yet.
        card(g,177,112);
        small(g,"QUEST SIGNAL  •  READ ONLY",20,195,GOLD);
        Sprites.avatar(g,170,178,38,39);
        QuestRecommendation q=observedQuest;
        clipped(g,q.headline(),20,222,q.eligible()?MINT:TEXT,188);
        small(g,q.explanation(),20,244,MUTED);
        small(g,q.eligible()?"CANDIDATE  •  COOK'S ASSISTANT":
                q.state()==QuestRecommendation.State.FINISHED?"COMPLETED  •  NO ACTIVE GOAL":
                "NO QUEST GOAL VERIFIED",20,269,q.eligible()?GOLD:MUTED);

        card(g,305,128);
        small(g,"BOSS PREVIEW  •  DEMO",20,325,GOLD);
        Sprites.nav(g,1,180,308,26,26);
        String[] names={"Vorkath","Scurrius","Barrows"};
        for(int i=0;i<3;i++) {
            int yy=339+i*29; boolean chosen=names[i].equals(model.boss());
            g.setColor(chosen?new Color(90,68,40):new Color(38,46,47));
            g.fillRoundRect(17,yy,190,25,5,5);
            g.setColor(chosen?GOLD:new Color(65,69,64));g.drawRoundRect(17,yy,190,25,5,5);
            if(chosen) { g.setColor(GOLD);g.fillRect(18,yy+4,3,17); }
            small(g,names[i],27,yy+17,chosen?GOLD:TEXT);
            small(g,chosen?"VIEWING":"PREVIEW",147,yy+17,chosen?GOLD:MUTED);
        }
        card(g,445,166);
        small(g,"DROP CHANCE  •  DEMO ONLY",20,463,GOLD);
        Sprites.hero(g,152,472,52,51);
        label(g,model.boss(),20,489,15,TEXT,true);
        small(g,"Illustration: 1 in 50 per kill",20,518,MUTED);
        String probability=String.format(Locale.ROOT,"%.1f%%",100*BurrowModel.cumulativeChance(1.0/50,20));
        label(g,probability,20,561,30,MINT,true);
        small(g,"At least one by 20 kills*",20,583,MUTED);
        small(g,"* Independent rolls. Demo odds.",20,601,MUTED);
        // Placeholder for the separate BUR-0032 integration lane; explicitly
        // NOT a real goal list, and no controls or model mutations are added.
        card(g,625,99);
        Sprites.avatar(g,151,643,54,52);
        small(g,"GOAL QUEUE  •  NOT LINKED",20,646,GOLD);
        label(g,"Recommendations will",20,670,10,TEXT,false);
        label(g,"appear after account",20,686,10,MUTED,false);
        label(g,"goal wiring is verified.",20,702,10,MUTED,false);
    }
    private void outfitter(Graphics2D g) {
        var profile=model.profile();
        title(g,"OUTFITTER",model.outfitterSubtitle());
        card(g,178,99);
        small(g,"BOSS  •  CLICK TO CHANGE",20,197,GOLD);
        g.setColor(new Color(43,43,38));g.fillRoundRect(13,203,199,33,5,5);
        g.setColor(LINE);g.drawRoundRect(13,203,199,33,5,5);
        clipped(g,model.boss()+"  ▸",21,225,TEXT,181);
        small(g,"METHOD  •  SELECT",20,241,GOLD);
        g.setColor(new Color(43,43,38));g.fillRoundRect(13,244,199,27,5,5);
        g.setColor(LINE);g.drawRoundRect(13,244,199,27,5,5);
        // Long names are readable in full inside methodMenu(), with no cycling.
        clipped(g,model.method().isBlank()?"Unavailable":model.method(),21,262,TEXT,164);
        label(g,"▾",193,263,13,GOLD,true);
        small(g,model.methods().size()>1?model.methods().size()+" methods  •  click to choose":
              "Only one registered method",20,276,MUTED);
        card(g,284,105);
        small(g,"WIKI RECOMMENDED  •  TIERS",20,297,GOLD);
        for(int i=0;i<3;i++) {
            Tier tier=Tier.values()[i];int xx=13+i*66;
            boolean available=TieredOutfitterCatalog.find(model.boss(),model.method(),tier)!=null;
            boolean selected=model.tier()==tier;
            g.setColor(selected?new Color(77,57,34):available?PANEL:new Color(28,31,31));
            g.fillRoundRect(xx,299,64,31,5,5);
            g.setColor(selected?GOLD:available?LINE:new Color(62,65,64));g.drawRoundRect(xx,299,64,31,5,5);
            label(g,tier.label(),xx+(i==1?2:8),319,i==1?9:10,available?TEXT:MUTED,selected);
        }
        small(g,styleFeedback==null?"Dimmed style = no verified method":styleFeedback,
              16,340,styleFeedback==null?MUTED:BAD);
        String[] styles={"Melee","Ranged","Magic"};
        for(int i=0;i<3;i++) {
            int xx=13+i*66;
            boolean available=availableMethodForStyle(styles[i])!=null;
            boolean selected=styles[i].equals(model.selectedStyle());
            g.setColor(selected?new Color(79,59,35):available?new Color(38,43,42):new Color(28,31,31));
            g.fillRoundRect(xx,345,64,32,5,5);
            g.setColor(selected?GOLD:available?LINE:new Color(62,65,64));g.drawRoundRect(xx,345,64,32,5,5);
            label(g,styles[i],xx+5,available?365:358,10,available?TEXT:MUTED,selected);
            if(!available) label(g,"NO SETUP",xx+5,371,8,BAD,false);
        }
        if(showsWildernessTravelWarning()) {
            // The warning occupies its own section above equipment: never draw
            // it on top of gear, inventories, instructions or hit targets.
            kbdWildernessWarning(g);
            g.translate(0,KBD_WARNING_SHIFT);
        }
        if(profile==null) {
            card(g,407,161);
            small(g,"SETUP UNAVAILABLE",20,433,GOLD);
            clipped(g,model.boss(),20,463,TEXT,185);
            small(g,"No complete sourced tier and inventory.",20,491,MUTED);
            small(g,"Gear and supplies are hidden.",20,511,MUTED);
            small(g,"No bank projection for this selection.",20,544,BAD);
            return;
        }
        card(g,397,260);
        small(g,"EQUIPMENT  •  11 SLOTS",20,414,GOLD);
        String[] slotNames={"HEAD","CAPE","NECK","AMMO","WEAPON","BODY","SHIELD","LEGS","GLOVES","BOOTS","RING"};
        int[] columns={1,0,1,2,0,1,2,1,0,1,2};
        int[] rows={0,1,1,1,2,2,2,3,4,4,4};
        for(int i=0;i<11;i++)
            itemCell(g,profile.gear().get(i),29+columns[i]*62,419+rows[i]*46,43,42,slotNames[i]);
        card(g,668,335);
        small(g,"INVENTORY  •  28 POSITIONS",20,688,GOLD);
        for(int i=0;i<28;i++)
            itemCell(g,profile.inventory().get(i),16+(i%4)*49,698+(i/4)*42,42,39,null);
        PreparationNotesLayout.Layout preparation=preparationLayout();
        card(g,PREPARATION_Y,preparation.height());
        small(g,"PREPARATION / SWITCHES",20,PREPARATION_Y+20,GOLD);
        g.setFont(PREPARATION_FONT);
        int noteY=PREPARATION_Y+41;
        for (PreparationNotesLayout.Line line:preparation.lines()) {
            if(line.heading()) {
                label(g,line.text(),17,noteY,10,GOLD,true);
            } else {
                small(g,line.text(),17,noteY,TEXT);
            }
            noteY+=PreparationNotesLayout.LINE_HEIGHT;
        }
        String authority=switch(model.tierSelection().authority()) {
            case OFFICIAL_WIKI_RENDERED_LAYOUT -> "Official Wiki layout";
            case WIKI_LAYOUT_WITH_TPT_EXPLICIT_VARIANTS -> "Wiki layout · TPT dose/quantity";
            case TPT_CURATED_WIKI_STRATEGY -> "TPT curated · Wiki strategy";
            case TPT_CURATED_WIKI_AND_COMMUNITY -> "TPT curated · Wiki + community";
        };
        int footer=PREPARATION_Y+preparation.height()-22;
        small(g,authority,16,footer-15,GOLD);
        small(g,"Conditional setup - verify unlocks",16,footer,MUTED);
    }
    private void kbdWildernessWarning(Graphics2D g) {
        final int x=13,y=397,w=199,h=66;
        g.setColor(new Color(70,32,26));g.fillRoundRect(x,y,w,h,7,7);
        g.setColor(new Color(245,156,88));g.drawRoundRect(x,y,w-1,h-1,7,7);
        label(g,"!  WILDERNESS TRAVEL",x+9,y+18,11,new Color(255,195,124),true);
        label(g,"Usual routes cross PvP Wilderness.",x+9,y+37,10,TEXT,false);
        label(g,"KBD lair is outside Wilderness.",x+9,y+53,10,TEXT,false);
    }
    private void itemCell(Graphics2D g, VerifiedOutfitterCatalog.Item item,
                          int x,int y,int w,int h,String slotName) {
        g.setColor(new Color(35,39,38));g.fillRoundRect(x,y,w,h,4,4);
        g.setColor(item!=null && item.id()<1?BAD:LINE);g.drawRoundRect(x,y,w,h,4,4);
        if(item!=null) {
            BufferedImage sprite=item.id()>0?itemImage.apply(item.id()):null;
            if(sprite!=null)g.drawImage(sprite,x+(w-32)/2,y+2,32,32,null);
            else if(item.id()<1)label(g,"?",x+w/2-4,y+24,15,BAD,true);
            if(item.amount()>1)label(g,Integer.toString(item.amount()),x+3,y+h-3,10,GOLD,true);
            if(item.amount()<0)label(g,"×?",x+3,y+h-3,10,GOLD,true);
        }
        if(slotName!=null)label(g,slotName,x+2,y+h-2,7,MUTED,false);
    }
    private static String sessionAmount(long n) {return String.format(Locale.US,"%,d",n);}
    private int sessionContentBottom() {
        int y=254;
        y+=sessionGroupHeight(sessionXp.size(),SessionFeed.XP,false);
        y+=12+sessionGroupHeight(sessionKc.size(),SessionFeed.BOSS_KC,false);
        y+=12+sessionItemsHeight(sessionDrops.values());
        y+=12+sessionItemsHeight(sessionSupplies.values());
        return y+12;
    }
    private int sessionGroupHeight(int rows,SessionFeed feed,boolean isItem) {
        if(rows==0)return 80;
        // Item names/attribution may take two visible lines; never paint over the next card.
        return (feed==SessionFeed.XP?91:59)+rows*(isItem?43:24)+10;
    }
    private int sessionItemsHeight(Collection<SessionItem> entries) {
        if(entries.isEmpty())return 80;
        int total=69;
        for(SessionItem item:entries)total+=sessionItemRowHeight(item);
        return total;
    }
    private int sessionItemRowHeight(SessionItem item) {
        FontMetrics metrics=getFontMetrics(new Font("Dialog",Font.PLAIN,10));
        int nameLines=wrapItemName(item.itemName(),metrics,143).size();
        return 29+nameLines*14;
    }
    private void sessions(Graphics2D g) {
        title(g,"SESSIONS","Activity in this login only");
        card(g,178,64);
        Color stateColor=activeSessionState==SessionState.ACTIVE?MINT:activeSessionState==SessionState.SUSPENDED?GOLD:MUTED;
        String stateLabel=activeSessionState==SessionState.ACTIVE?"ACTIVE LOGIN":
            activeSessionState==SessionState.SUSPENDED?"OBSERVATIONS PAUSED":"NOT CONNECTED";
        small(g,"CURRENT LOGIN",20,199,GOLD);
        label(g,stateLabel,20,219,12,stateColor,true);
        small(g,activeSessionOrigin==SessionOrigin.SYNTHETIC_FIXTURE?"SYNTHETIC FIXTURE · NOT LIVE":
            "No saved session history",20,234,activeSessionOrigin==SessionOrigin.SYNTHETIC_FIXTURE?BAD:MUTED);
        int y=254;
        y=paintSessionGroup(g,y,"XP GAINED",SessionFeed.XP,sessionXp);
        y+=12;
        y=paintSessionGroup(g,y,"BOSS KC GAINS",SessionFeed.BOSS_KC,sessionKc);
        y+=12;
        y=paintSessionItems(g,y,"DROPS",SessionFeed.DROPS,sessionDrops);
        y+=12;
        paintSessionItems(g,y,"SUPPLIES USED",SessionFeed.SUPPLIES,sessionSupplies);
    }
    private void sectionFrame(Graphics2D g,int y,int h,String title,SessionFeed feed) {
        card(g,y,h);
        label(g,title,19,y+21,11,GOLD,true);
        FeedStatus status=sessionFeeds.getOrDefault(feed,FeedStatus.NOT_CONNECTED);
        small(g,status==FeedStatus.AVAILABLE?"OBSERVED INPUT":status==FeedStatus.UNAVAILABLE?
            "SOURCE UNAVAILABLE":"AWAITING EVENT SOURCE",19,y+37,
            status==FeedStatus.AVAILABLE?MINT:MUTED);
    }
    private void sessionEmpty(Graphics2D g,int y,SessionFeed feed) {
        String text=sessionFeeds.getOrDefault(feed,FeedStatus.NOT_CONNECTED)==FeedStatus.AVAILABLE?
            "No activity recorded this login":
            sessionFeeds.getOrDefault(feed,FeedStatus.NOT_CONNECTED)==FeedStatus.UNAVAILABLE?
            "Cannot verify this activity":"Waiting for verified events";
        small(g,text,19,y+61,MUTED);
    }
    private int paintSessionGroup(Graphics2D g,int y,String title,SessionFeed feed,
                                  Map<String,Long> entries) {
        int height=sessionGroupHeight(entries.size(),feed,false);
        sectionFrame(g,y,height,title,feed);
        if(entries.isEmpty()) {sessionEmpty(g,y,feed);return y+height;}
        if(feed==SessionFeed.XP) {
            label(g,"+"+sessionAmount(sessionTotalXp),19,y+63,21,MINT,true);
            small(g,"TOTAL XP",157,y+61,MUTED);
        }
        int cy=y+(feed==SessionFeed.XP?90:53);
        // Size includes the total summary line for XP, if any.
        for(Map.Entry<String,Long> entry:entries.entrySet()) {
            small(g,elideSessionText(g,entry.getKey(),138),19,cy,TEXT);
            label(g,"+"+sessionAmount(entry.getValue()),148,cy,10,MINT,true);
            cy+=24;
        }
        return y+Math.max(height,cy-y+12);
    }
    private int paintSessionItems(Graphics2D g,int y,String title,SessionFeed feed,
                                  Map<String,SessionItem> entries) {
        int height=sessionItemsHeight(entries.values());
        sectionFrame(g,y,height,title,feed);
        if(entries.isEmpty()) {sessionEmpty(g,y,feed);return y+height;}
        int cy=y+57;
        FontMetrics metrics=getFontMetrics(new Font("Dialog",Font.PLAIN,10));
        for(SessionItem entry:entries.values()) {
            java.util.List<String> nameLines=wrapItemName(entry.itemName(),metrics,143);
            for(int i=0;i<nameLines.size();i++)
                label(g,nameLines.get(i),19,cy+i*14,10,TEXT,i==0);
            label(g,"×"+sessionAmount(entry.quantity()),169,cy,10,MINT,true);
            small(g,elideSessionText(g,entry.attribution(),181),19,cy+nameLines.size()*14,MUTED);
            cy+=sessionItemRowHeight(entry);
        }
        return y+height;
    }
    private String elideSessionText(Graphics2D g,String text,int maxWidth) {
        g.setFont(new Font("Dialog",Font.PLAIN,10));
        FontMetrics fm=g.getFontMetrics();
        if(fm.stringWidth(text)<=maxWidth)return text;
        String cut=text;
        while(cut.length()>1 && fm.stringWidth(cut+"…")>maxWidth)
            cut=cut.substring(0,cut.length()-1);
        return cut+"…";
    }
    private void label(Graphics2D g,String s,int x,int y,int size,Color color,boolean bold) {
        g.setColor(color);g.setFont(new Font("Dialog",bold?Font.BOLD:Font.PLAIN,size));g.drawString(s,x,y);
    }
    private void small(Graphics2D g,String s,int x,int y,Color c) {label(g,s,x,y,10,c,false);}
    private void clipped(Graphics2D g,String s,int x,int y,Color c,int pixels) {
        g.setFont(new Font("Dialog",Font.BOLD,11));
        FontMetrics metrics = g.getFontMetrics();
        String display = s;
        while (display.length()>1 && metrics.stringWidth(display)>pixels) {
            display = display.substring(0,display.length()-1);
        }
        if (!display.equals(s)) {
            while (display.length()>1 && metrics.stringWidth(display + "…")>pixels)
                display=display.substring(0,display.length()-1);
            display += "…";
        }
        g.setColor(c);g.drawString(display,x,y);
    }
}
