package gg.feral.burrow.ui;
import gg.feral.burrow.core.BurrowModel;
import gg.feral.burrow.core.TieredOutfitterCatalog.Tier;
import javax.swing.SwingUtilities;
/** Existing navigation plus scoped Outfitter controls. */
public final class BurrowHitboxTest {
 static int checks;
 static void ok(boolean yes,String why){checks++;if(!yes)throw new AssertionError(why);}
 public static void main(String[] ignored) throws Exception {
  BurrowModel m=new BurrowModel();BurrowPanel p=new BurrowPanel(m);
  p.clickAt(12,90);ok(m.view()==BurrowModel.View.HOME,"Home");
  p.clickAt(155,106);ok(m.view()==BurrowModel.View.PATHFINDER,"Pathfinder");
  p.clickAt(22,166);ok(m.view()==BurrowModel.View.OUTFITTER,"Outfitter");
  p.clickAt(26,282);ok(m.boss().equals("Brutus")&&m.plan()!=null,"boss selector advances to Brutus");
  p.clickAt(26,282);ok(m.boss().equals("Giant Mole")&&m.plan()!=null,"boss selector advances to Mole");
  p.clickAt(180,380);ok(m.tier()==Tier.OPTIMAL && m.plan()!=null,"optimal tier selection");
  p.clickAt(80,380);ok(m.tier()==Tier.RECOMMENDED && m.plan()!=null,"default tier return");
  p.clickAt(170,426);ok(m.selectedStyle().equals("Melee"),"unsupported style cannot select");
  p.clickAt(155,106);ok(m.view()==BurrowModel.View.PATHFINDER,"Pathfinder return");
  p.clickAt(30,411);ok(m.boss().equals("Vorkath"),"existing Pathfinder boss choice");
  p.clickAt(22,166);ok(m.view()==BurrowModel.View.OUTFITTER&&m.selectedStyle().equals("Ranged"),"Vorkath coherent selection");
  p.clickAt(150,166);ok(m.view()==BurrowModel.View.SESSIONS,"Sessions");
  var fixture=new BurrowPanel.SessionScope("synthetic_hitbox_test","login_1");
  SwingUtilities.invokeAndWait(()->{
   ok(p.ingestSessionEvent(new BurrowPanel.SessionStart(fixture,"hitbox-start",
     BurrowPanel.SessionOrigin.SYNTHETIC_FIXTURE)),"synthetic session accepted");
   ok(p.ingestSessionEvent(new BurrowPanel.SessionXpGain(fixture,"hitbox-xp",
     BurrowPanel.SessionOrigin.SYNTHETIC_FIXTURE,"Strength",25,
     "explicit synthetic fixture")),"only typed XP event adds progress");
  });
  var before=p.sessionReadout();
  ok(before.synthetic()&&before.totalXp()==25&&before.kcByBoss().isEmpty(),"fixture has no fake kills");
  p.clickAt(30,303);
  ok(m.view()==BurrowModel.View.SESSIONS&&p.sessionReadout().equals(before),
    "old demo hitbox read only");
  p.clickAt(30,353);
  ok(m.view()==BurrowModel.View.SESSIONS&&p.sessionReadout().equals(before),
    "old reset hitbox read only");
  ok(m.demoKills()==0,"no model demo counter remains");
  p.clickAt(40,91);ok(m.view()==BurrowModel.View.HOME,"Home return");
  p.clickAt(30,BurrowPanel.HEIGHT);ok(m.view()==BurrowModel.View.HOME,"outside bottom");
  System.out.println("OUTFITTER HITBOX PASS: "+checks+" assertions");
 }
}
