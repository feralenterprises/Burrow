package gg.feral.burrow.ui;

import gg.feral.burrow.core.BurrowModel;
import gg.feral.burrow.core.LiveCombat;
import gg.feral.burrow.core.LiveWeapon;
import gg.feral.burrow.core.QuestRecommendation;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.swing.SwingUtilities;

/** BUR-0017/0018: narrow visual regression; no RuneLite/native claims. */
public final class FeralModernHomePathfinderUiTest {
    private static BufferedImage render(BurrowPanel panel) {
        BufferedImage image = new BufferedImage(225, 880, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        panel.paint(g);
        g.dispose();
        return image;
    }
    private static void require(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
    private static boolean different(BufferedImage a, BufferedImage b, int left, int top, int right, int bottom) {
        for(int y=top;y<bottom;y++) for(int x=left;x<right;x++) {
            if(a.getRGB(x,y)!=b.getRGB(x,y)) return true;
        }
        return false;
    }
    public static void main(String[] args) throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            require(Sprites.loaded(), "Missing approved original artwork");
            BurrowModel model = new BurrowModel();
            BurrowPanel panel = new BurrowPanel(model);
            panel.setSize(225,880);
            require(panel.getPreferredSize().width==225, "Native sidebar width must remain 225");
            BufferedImage home = render(panel);
            // The specific approved raccoon asset must be present in the Home waiting card.
            require(different(home, new BufferedImage(225,880,BufferedImage.TYPE_INT_RGB),124,326,201,402),
                "Home waiting illustration missing");
            panel.clickAt(153,108);
            require(model.view()==BurrowModel.View.PATHFINDER, "Four-tab navigation changed");
            require(panel.observedQuest().state()==QuestRecommendation.State.OFFLINE,
                "Visual lane must not assume a verified quest");
            BufferedImage before = render(panel);
            String selected = model.boss();
            // The new empty queue card is purely decorative and must not mutate boss state.
            panel.clickAt(82,740);
            require(selected.equals(model.boss()), "Goal placeholder gained a phantom action");
            panel.setObservedQuest(QuestRecommendation.of(QuestRecommendation.State.FINISHED));
            BufferedImage finished = render(panel);
            require(different(before,finished,20,260,210,335), "Observed quest status not displayed");
            panel.clickAt(40,105);
            require(model.view()==BurrowModel.View.HOME, "Home tab no longer works");
            panel.setObservedWeapon(LiveWeapon.equipped(4151,"Abyssal whip"));
            panel.setObservedCombat(LiveCombat.fromRealLevels(new int[]{75,80,75,82,81,70,70}));
            BufferedImage live = render(panel);
            require(different(home,live,50,525,202,602), "Home live observations did not update");
            require(model.view()==BurrowModel.View.HOME, "Paint changed selected tab");
            // Current Home and Pathfinder painter never manipulates profile or bank inputs.
            panel.clickAt(39,165);
            require(model.view()==BurrowModel.View.OUTFITTER, "Outfitter tab changed");
            panel.clickAt(151,165);
            require(model.view()==BurrowModel.View.SESSIONS, "Sessions tab changed");
            System.out.println("BUR-0017/0018 Feral Modern focused offline UI PASS");
        });
    }
}
