package gg.feral.burrow.ui;

import gg.feral.burrow.core.BurrowModel;
import gg.feral.burrow.core.TieredOutfitterCatalog;
import gg.feral.burrow.core.VerifiedOutfitterCatalog;
import gg.feral.burrow.core.TieredOutfitterCatalog.Tier;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import javax.swing.SwingUtilities;

/** BUR-0040: actual mouse-release routing, sourced method coverage and visible rejection. */
public final class OutfitterStyleInteractionTest {
    private static int checks;
    private static void check(boolean ok, String message) {
        checks++;
        if (!ok) throw new AssertionError(message);
    }
    private static void leftClick(BurrowPanel panel, int x, int y) {
        panel.dispatchEvent(new MouseEvent(panel, MouseEvent.MOUSE_RELEASED,
            System.currentTimeMillis(), InputEvent.BUTTON1_DOWN_MASK,
            x, y, 1, false, MouseEvent.BUTTON1));
    }
    private static String tip(BurrowPanel panel, int x, int y) {
        return panel.getToolTipText(new MouseEvent(panel, MouseEvent.MOUSE_MOVED,
            System.currentTimeMillis(), 0, x, y, 0, false));
    }
    private static void test() {
        BurrowModel model=new BurrowModel();
        BurrowPanel panel=new BurrowPanel(model);
        panel.setSize(BurrowPanel.WIDTH, BurrowPanel.HEIGHT);
        model.show(BurrowModel.View.OUTFITTER);
        model.chooseBoss("Dagannoth Kings");
        model.chooseTier(Tier.OPTIMAL);
        String[] styles={"Melee","Ranged","Magic"};
        String[] methods={"Supreme, melee","Prime, ranged","Rex safespot with Guthan healing switch"};
        for(int i=0;i<3;i++) {
            leftClick(panel,35+66*i, 423);
            check(model.method().equals(methods[i]),"DK " + styles[i] + " click chooses matching method");
            check(model.selectedStyle().equals(styles[i]),"DK " + styles[i] + " style active");
            check(model.tier()==Tier.OPTIMAL && model.boss().equals("Dagannoth Kings"),"preserves DK boss/tier");
            check(model.profile()!=null && model.plan()!=null,"DK backed by verified profile");
            check(panel.styleFeedbackForTest()==null,"successful selection clears warning");
        }
        model.chooseBoss("Scurrius");
        model.chooseTier(Tier.ENTRY);
        var before=model.plan();
        var methodBefore=model.method();
        leftClick(panel,101,423); // ranged is intentionally missing in FINAL-06
        check(model.plan()==before && model.method().equals(methodBefore),"unsupported style does not mutate selection");
        check(model.tier()==Tier.ENTRY && model.boss().equals("Scurrius"),"unsupported preserves boss/tier");
        check("No verified Ranged setup for this boss".equals(panel.styleFeedbackForTest()),"visible rejection text");
        check(tip(panel,101,423).contains("No verified Ranged method for Scurrius"),"specific explanatory tooltip");
        leftClick(panel,167,423);
        check(panel.styleFeedbackForTest().contains("Magic"),"separate feedback for unsupported magic");
        leftClick(panel,35,423);
        check(panel.styleFeedbackForTest()==null,"supported click clears feedback");
        check(model.plan()==before,"clicking selected style does not regenerate plan");
        leftClick(panel,101,423);
        leftClick(panel,101,377); // tier Recommended (existing tier hitbox)
        check(model.tier()==Tier.RECOMMENDED && panel.styleFeedbackForTest()==null,"tier changes clear stale warning");
        leftClick(panel,167,423);
        leftClick(panel,35,283); // next boss Brutus (existing boss hitbox)
        check(model.boss().equals("Brutus") && panel.styleFeedbackForTest()==null,"boss change clears stale warning");
        model.chooseBoss("Dagannoth Kings");
        leftClick(panel,167,423);
        check(tip(panel,167,423).contains("selected"),"active style tooltip says selected");
        check(tip(panel,35,423).contains("Switch to Melee"),"supported alternative tooltip offers switch");
        String selected=model.method();
        panel.dispatchEvent(new MouseEvent(panel,MouseEvent.MOUSE_RELEASED,
            System.currentTimeMillis(), InputEvent.BUTTON3_DOWN_MASK,35,423,1,false,MouseEvent.BUTTON3));
        check(model.method().equals(selected),"right click cannot select style");
        // Confirm entire catalog's actual method/style coverage is respected with real mouse events.
        int supported=0, unsupported=0;
        for(String boss:VerifiedOutfitterCatalog.BOSSES) {
            model.chooseBoss(boss);
            model.chooseTier(Tier.RECOMMENDED);
            for(int i=0;i<3;i++) {
                String expected=null;
                for(String method:model.methods())
                    if(TieredOutfitterCatalog.style(boss,method).equals(styles[i])) {expected=method;break;}
                var previous=model.plan();
                var previousMethod=model.method();
                leftClick(panel,35+66*i,423);
                if(expected!=null) {
                    supported++;
                    check(model.method().equals(expected),boss+" "+styles[i]+" switches to a real method");
                    check(model.profile()!=null && model.selectedStyle().equals(styles[i]),"verified style and profile");
                    check(panel.styleFeedbackForTest()==null,"no warning for supported method");
                } else {
                    unsupported++;
                    check(model.method().equals(previousMethod)&&model.plan()==previous,"no manufactured method for " + boss + " " + styles[i]);
                    check(panel.styleFeedbackForTest()!=null&&panel.styleFeedbackForTest().contains(styles[i]),"clear rejected style");
                }
                check(model.boss().equals(boss)&&model.tier()==Tier.RECOMMENDED,"boss and tier preserved");
            }
        }
        check(supported==17 && unsupported==28,"17 valid method/style choices, 28 unavailable style/boss combinations");
        // Headless full paint check exercises both the disabled and selected control labels.
        BufferedImage image=new BufferedImage(BurrowPanel.WIDTH,BurrowPanel.HEIGHT,BufferedImage.TYPE_INT_ARGB);
        panel.paint(image.createGraphics());
        check(image.getRGB(35,423)!=0,"style buttons render");
        System.out.println("BUR-0040 STYLE INTERACTION PASS: " + checks +
            " assertions; 17 supported and 28 explicitly unavailable combinations");
    }
    public static void main(String[] args) throws Exception {
        if(SwingUtilities.isEventDispatchThread())test();
        else SwingUtilities.invokeAndWait(OutfitterStyleInteractionTest::test);
    }
}
