package gg.feral.burrow.ui;

import gg.feral.burrow.core.BurrowModel;
import gg.feral.burrow.core.VerifiedOutfitterCatalog;
import gg.feral.burrow.core.TieredOutfitterCatalog.Tier;
import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.JToolTip;

/** Offline, dependency-free BUR-0036 regression check; Java 17 source-compatible. */
public final class PreparationTooltipSmokeCheck {
    private static void require(boolean pass, String message) {
        if (!pass) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        String large = "Safe but extremely long preparation notes about special phases and equipment switches ".repeat(30);
        String html = PreparationTooltip.render(
            List.of(large, large, large), List.of(large), List.of(large), List.of(large));
        require(html.startsWith("<html>"), "HTML renderer");
        JToolTip tip = new JToolTip();
        tip.setTipText(html);
        Dimension d = tip.getPreferredSize();
        require(d.width <= 270 && d.height <= 340, "Tooltip bounds: " + d);
        String escaped = PreparationTooltip.render(List.of("<img> & all"), List.of(), List.of(), List.of());
        require(escaped.contains("&lt;img&gt;") && escaped.contains("&amp;"), "HTML encoding");
        BurrowModel model = new BurrowModel();
        model.show(BurrowModel.View.OUTFITTER);
        BurrowPanel panel = new BurrowPanel(model);
        MouseEvent preparationHover = new MouseEvent(panel, MouseEvent.MOUSE_MOVED, 0, 0, 40, 1090, 0, false);
        String preparation = panel.getToolTipText(preparationHover);
        require(preparation != null && preparation.startsWith("<html>"), "Preparation hover should be bounded HTML");
        MouseEvent gearHover = new MouseEvent(panel, MouseEvent.MOUSE_MOVED, 0, 0, 100, 500, 0, false);
        String gear = panel.getToolTipText(gearHover);
        require(gear != null && !gear.startsWith("<html>"), "Gear naming must remain plain-text");
        int profiles = 0;
        int largestWidth = 0, largestHeight = 0;
        for (String boss : VerifiedOutfitterCatalog.BOSSES) {
            model.chooseBoss(boss);
            for (String method : model.methods()) {
                model.chooseMethod(method);
                for (Tier tier : Tier.values()) {
                    model.chooseTier(tier);
                    if (model.profile() == null) continue;
                    // KBD's visible Wilderness banner moves the preparation card
                    // down 72px; follow the actual drawn card, not an old fixed y.
                    int shiftedY = 1090 + ("King Black Dragon".equals(boss) ? 72 : 0);
                    MouseEvent actualPrepHover = new MouseEvent(panel, MouseEvent.MOUSE_MOVED,
                        0, 0, 40, shiftedY, 0, false);
                    String hover = panel.getToolTipText(actualPrepHover);
                    require(hover != null && hover.startsWith("<html>"), boss + " / " + method + " / " + tier);
                    tip.setTipText(hover);
                    Dimension actual = tip.getPreferredSize();
                    largestWidth = Math.max(largestWidth, actual.width);
                    largestHeight = Math.max(largestHeight, actual.height);
                    require(actual.width <= 270 && actual.height <= 340,
                        "Overflow: " + boss + " / " + method + " / " + tier + " => " + actual);
                    profiles++;
                }
            }
        }
        require(profiles == 51, "Expected 51 verified profiles, got " + profiles);
        System.out.println("BUR-0036 SMOKE PASS: " + profiles + " profiles, max tooltip "
            + largestWidth + "x" + largestHeight + ", HTML escaping, panel routing, gear hover preserved");
    }
}
