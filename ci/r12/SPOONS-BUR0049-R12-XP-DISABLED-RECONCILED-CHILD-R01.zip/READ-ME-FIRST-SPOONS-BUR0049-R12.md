# PROJECT BURROW | SPOONS | BUR-0049 R12 | SOURCE CHILD HANDOFF

**RESULT: NARROW XP SAFETY DISABLE IMPLEMENTED. OFFLINE TESTS PASS. REAL JAVA 17 GATE BLOCKED. RELEASE HOLD.**

## What changed in the player-facing plugin

- The live Sessions XP feed is **disabled**, not silently reset to 0 and not portrayed as a verified feed. Its status remains `UNAVAILABLE`, and no live `SessionXpGain` events can leave `BurrowPlugin` while `SESSION_XP_ENABLED=false`.
- A fixed, **nonconfigurable, default-OFF** `SESSION_XP_ENABLED=false` host flag guards both `trySynchronizeXp()` and `observeSessionXp()`. Additional delivery checks block XP gains and coerce XP availability to `UNAVAILABLE` even if a caller tries to pass `AVAILABLE`. The existing XP observation adapter is retained for future authenticated work.
- `BURROW-MASTER.json` authoritative root pointers now agree with `BURROW-TICKETS.json`: BUR-0049 active, 49 tickets, next unused BUR-0050, current source candidate is this R12 child. Older snapshots are preserved.
- Existing three XP host JUnit test classes are updated from previously allowed real XP expectations to assert that the **disabled host never synchronizes or emits**, with their earlier account-transition safety assertions retained. Four focused additional JUnit tests are staged for all 24 skills, valid zero XP, A→B→A, login/restart/hop/logout, duplicate/backward events, the **synthetic** stale-cache +959 ordering, forced availability, direct XP injection and Sessions UI status. **These newly staged host JUnit tests have NOT been compiled or run** because real RuneLite/Gradle/JDK17 dependencies are missing.

## Evidence

- Original parent ZIP SHA-256: `0799c0440a63038ade44c4cbecdcce28a9e88f641be9c7cb27fb1d093df0a58d`. SHA matched.
- 5 existing project files edited, 1 focused test file added, 268 existing project files byte-identical to parent, **zero deleted**. See `R12-SOURCE-DIFF.patch` and `R12-VERIFICATION-MANIFEST.json`.
- 26 dependency-free production files and 30 offline test/preview source files compiled with local Java 21 `javac --release 17`. **27/27 offline executable programs passed**, including 6,545 Outfitter catalog checks for 15 bosses, 17 methods and 51 loadouts and 41 Sessions UI assertions (synthetic). Original 51 loadout JSON unchanged.
- Genuine Java 17 prerequisite probe (`scripts/require-java17.sh`) returned exit **17**, because only Java **21** is available; Gradle 8.14.6 and pinned RuneLite `net.runelite:client:1.13.4` dependencies are not locally available. Therefore `clean test jar` is **BLOCKED / NOT RUN**, no JUnit XML and no new authentic RuneLite plugin JAR. Java 21 compatibility is **not** a Java17 PASS.
- Neither original source, GitHub, nor canonical archive was changed. No Windows/player test requested or performed.

## What is NOT established

- Live XP account/cache ownership remains **unproven**, even though XP is now gated off. The documented +959 XP scenario is a **synthetic conditional source replay**, not observed native RuneLite behavior.
- The new host JUnit tests are **staged but not executed**; their expected behavior has not been independently observed with actual RuneLite classes.
- No authenticated Java 17 Gradle/JUnit build, independent R12 Tongs L2 or Wrench safety approval exists. **RELEASE HOLD remains active**; no owner Windows testing.

## Next dispatch

A build engineer with **genuine JDK 17**, Gradle **8.14.6**, and RuneLite **1.13.4** must run `clean test jar` on **this exact R12 source**, save full logs, XML, and JAR hash. Stop on any failure and have Spoons repair only proven source/test-harness defects. **Only after a real green build** dispatch `NEXT-UP-TONGS-BUR0049-R12-CONDITIONAL-L2.md`. Wrench approval is an additional separate gate; do not claim gameplay acceptance on a green build alone.
