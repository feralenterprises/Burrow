@echo off
setlocal EnableExtensions
cd /d "%~dp0Project-Burrow" || goto failed
echo =============================================================
echo FERAL DUAL DEV - TRASHPANDA BANK R05 + HOVERLITE v0.2.8
echo TEST AND BUILD ONLY - RELEASE HOLD - JDK 17 REQUIRED
echo =============================================================
call "WINDOWS-BUILD20-PREFLIGHT.cmd"
if errorlevel 1 goto failed
if defined JAVA17_HOME set "JAVA_HOME=%JAVA17_HOME%"
call "gradlew.bat" --no-daemon --console=plain clean test hoverliteDevClasses jar
if errorlevel 1 goto failed
echo [PASS] Test/build completed. Native game QA still required.
pause
exit /b 0
:failed
echo [FAIL] Copy the FIRST error above, including the failing source line.
pause
exit /b 1
