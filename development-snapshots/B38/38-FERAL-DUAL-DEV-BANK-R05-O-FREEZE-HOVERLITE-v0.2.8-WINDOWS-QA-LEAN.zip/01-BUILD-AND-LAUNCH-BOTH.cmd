@echo off
setlocal EnableExtensions
cd /d "%~dp0Project-Burrow" || goto failed
echo =============================================================
echo FERAL DUAL DEV - ONE RUNELITE CLIENT / TWO LOCAL PLUGINS
echo TrashPanda BANK R05 + HoverLite v0.2.8 LEAN OWNER QA
echo R05 IS A WINDOWS TEST CANDIDATE - RELEASE HOLD
echo =============================================================
call "WINDOWS-BUILD20-PREFLIGHT.cmd"
if errorlevel 1 goto failed
if defined JAVA17_HOME set "JAVA_HOME=%JAVA17_HOME%"
echo [1/2] Run tests and compile both plugins...
call "gradlew.bat" --no-daemon --console=plain clean test hoverliteDevClasses
if errorlevel 1 goto failed
echo [2/2] Starting ONE RuneLite developer client...
call "gradlew.bat" --no-daemon --console=plain runBoth
if errorlevel 1 goto failed
echo [INFO] RuneLite developer client closed. RELEASE HOLD.
pause
exit /b 0
:failed
echo [FAIL] Copy the FIRST relevant error above.
pause
exit /b 1
