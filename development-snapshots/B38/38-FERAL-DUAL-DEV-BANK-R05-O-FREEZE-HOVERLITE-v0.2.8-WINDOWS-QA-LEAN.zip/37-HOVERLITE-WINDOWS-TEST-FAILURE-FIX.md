# FERAL ENTERPRISES | R37 • Test-only correction | RELEASE HOLD

## Owner's verified Windows failure

JDK 17 Gradle `:test`: **633 tests executed, 1 failed** in
`AutoPolicyTest.exactOwnerTargetsAndColorPreservation()` at line 248.
Build did **not** launch RuneLite. This log is supplied by the owner, not
something independently reproduced with Gradle here.

### What was wrong

The test expected `Chop Spirit tree` for a `Chop down` interaction on
`Spirit tree`. But HoverLite's approved `CoreAction.TREE` whitelist excludes
Spirit trees, intentionally preserving unapproved verbs. The actual
correct safe display is `Chop down Spirit tree`. Rewriting production
semantics to pass the test could hide the meaning of a special interaction.

### Exactly one source-file change

`Project-Burrow/src/test/java/com/feralenterprises/hoverlite/AutoPolicyTest.java`

- Expected: `Chop Spirit tree`
+ Expected: `Chop down Spirit tree`

The assertion still checks that unapproved targets **retain their verbs**.
Every production Java source file (TrashPanda AND HoverLite) is byte-for-byte
unchanged from build 36. Bank R04 withdrawal behavior is **not** altered.

### Windows steps

1. Extract this R37 ZIP into a fresh folder, NOT over R36.
2. With Windows JDK 17, run `00-BUILD-AND-TEST-BOTH.cmd`.
   Expected: Gradle completes `:test` successfully with **zero failures**.
3. Only after the test passes, run `01-BUILD-AND-LAUNCH-BOTH.cmd`.
4. In the client test HoverLite on `Spirit tree` (if accessible), ordinary
   `Oak tree`, NPC combat-level removal, and Bank R04 green O withdrawal.
   Normal bank withdrawal still requires native QA confirmation.
5. If a different test fails, copy the first failure name, line and
   expected/actual details. Do not assume native success.

### Verification levels

- Original and corrected test expressions inspected against `CoreAction`.
- ZIP entry CRC / SHA-256 manifest checked; all production bytes compared
  with R36.
- Java-formatting isolated regression harness rerun on Java 21 with
  `javac --release 17` (NOT Windows JDK17/Gradle).
- Full Gradle tests on **this** R37 archive: NOT RUN HERE.
- Native RuneLite: NOT RUN HERE.
- Bank R04 / HoverLite v0.2.8 remain **owner QA candidates**.
