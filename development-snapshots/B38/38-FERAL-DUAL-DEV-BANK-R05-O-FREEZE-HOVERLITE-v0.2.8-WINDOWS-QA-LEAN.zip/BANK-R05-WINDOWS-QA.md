# R38 | BANK R05 Owner QA | Focused withdrawal-tab test

**Goal:** keep Best in Bank's temporary O tab OPEN through two withdrawals, then
rescan only AFTER leaving the tab. No repeated "evidence changed; old bank tag
was closed for safety" while the verified tab remains selected.

## Test

1. Fresh extract; run `01-BUILD-AND-LAUNCH-BOTH.cmd` on Windows JDK 17.
   Full test suite must pass and RuneLite must launch both plugins.
2. Select boss and Best in Bank; open bank; wait for verified scan; open O.
3. Withdraw two distinct, safe pieces of *currently banked* selected gear.
   **PASS** if O stays open, right-click Withdraw works, and both items reach inventory.
4. Close O; **PASS** if old evidence is retired, new scan occurs and a subsequent
   O layout excludes withdrawn items now only in inventory/equipment.
5. Switch to saved Bank Tags tab, reopen O, close bank, and confirm saved tabs
   remain unmodified and O does not cross account/bank-open boundaries.

If any item is a placeholder rather than a real withdrawable bank item, FAIL.
If the exact old-tag-closed message recurs while O is selected, FAIL.
If only one item is present, test withdrawing another safe banked item after
reopening the updated layout; do NOT invent a test item to force this case.

**Known limitation:** The layout is intentionally frozen while open; newly
withdrawn/removed stock is not re-planned until you leave O. Native RuneLite
bank filtering still controls which stock can actually be withdrawn.

**RELEASE HOLD:** no full Windows JDK 17 suite, no two-withdrawal native pass,
no Tongs integrated L2 approval has yet been documented for R38.
