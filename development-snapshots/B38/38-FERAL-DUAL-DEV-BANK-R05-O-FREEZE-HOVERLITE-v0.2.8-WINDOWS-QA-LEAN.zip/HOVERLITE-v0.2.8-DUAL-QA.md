# FERAL DUAL DEV | HoverLite v0.2.8 QA

SOURCE: latest chronologically uploaded standalone
`HoverLite-v0.2.8-LEAN-AUTO-OWNER-QA.zip` (owner QA / release hold).

## Main v0.2.8 behaviors to verify

- Auto Shorten ON by default for NPCs and world objects.
- NPC combat level suffix removed even when same-name NPCs differ in level.
- Safe verbs retained or shortened by the whitelist. Inventory, spells and
  item-on-target options are not silently shortened.
- Fullscreen interface hover draw hook and null menu entry guard added in v0.2.8.
- QA identity option adds `[HL ...]` prefix, proving HoverLite submitted tooltip.

## Expected on Windows

- Disable built-in RuneLite Mouse Tooltips during test to avoid duplicate visuals.
- Enable HoverLite and QA identity in plugin settings.
- Hover NPC Imp (level-2): `[HL NPC SMART_SHORTEN] Attack Imp`.
- Hover oak tree: `[HL GAME_OBJECT SMART_SHORTEN] Chop Oak`.
- Hover an inventory stack/bank item: keep meaningful use/withdraw action.
- Confirm normal hovering and compatible fullscreen interfaces; no duplicate tooltip.
- Confirm both TrashPanda and HoverLite appear in the SAME dev RuneLite client.

Check console/logs and test errors if any. Source was copied exactly, not
rewritten for the dual build. Actual runtime GUI proof remains mandatory.
