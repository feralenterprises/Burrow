package gg.feral.burrow.host;

import gg.feral.burrow.ui.BurrowPanel;
import gg.feral.burrow.ui.SidebarWheelRouter;
import java.awt.BorderLayout;
import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import net.runelite.client.ui.PluginPanel;

/**
 * Build 19 single-scroll-owner host for the RuneLite sidebar.
 *
 * <p>RuneLite 1.13.4 {@code ClientUI} mounts {@code navigation.getPanel().getWrappedPanel()} in its
 * sidebar tab pane. With {@code PluginPanel(false)} the wrapped panel is the plugin panel itself,
 * so there is NO RuneLite outer scroll pane. The only JScrollPane in the sidebar is the one created
 * here; its viewport is bounded by the real sidebar height, so mouse-wheel, scrollbar drag and
 * keyboard all move the same viewport.
 */
public final class SidebarHost extends PluginPanel {
    private final JScrollPane scroll;
    private final BurrowPanel content;

    private SidebarHost(BurrowPanel content) {
        super(false);
        this.content = content;
        setLayout(new BorderLayout());
        scroll = new JScrollPane(content,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(24);
        scroll.getVerticalScrollBar().setBlockIncrement(240);
        SidebarWheelRouter.install(scroll, content);
        add(scroll, BorderLayout.CENTER);
    }

    public static SidebarHost mount(BurrowPanel content) {
        if (content == null) throw new IllegalArgumentException("content");
        return new SidebarHost(content);
    }

    /** The single effective scroll owner. */
    public JScrollPane scrollOwner() { return scroll; }
    public BurrowPanel content() { return content; }
}
