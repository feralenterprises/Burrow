package gg.feral.burrow.pathfinder;

import java.util.*;

/**
 * Pathfinder suggestion engine. Inputs must be authenticated by the host (RuneLite plugin);
 * this class never calls RuneLite and never controls the game.
 *
 * <p>Build 19 expands the original eight curated activities (IDs, titles and semantics preserved)
 * into a source-linked rule registry ({@link GuideData}): the ironman.guide quest order with a
 * prerequisite graph, the 17 Outfitter encounters, ironman.guide AFK and money-making tables, Wiki
 * Ironman gear goals and route milestones. Each suggestion explains why, what is missing, the next
 * concrete step and its source. Unknown is never treated as unfinished or missing.
 */
public final class SuggestionEngine {
    private SuggestionEngine() {}
    public enum State { MET, UNMET, UNKNOWN }
    public enum Quest { FINISHED, IN_PROGRESS, NOT_STARTED, UNKNOWN }
    /** Build 20 appends AFK (category filter: ironman.guide AFK methods). Ordinals of earlier values unchanged. */
    public enum Focus { ANY, QUESTS, PVM, GP, SUPPLIES, AFK }
    /** Build 20 appends AFK: only activities with a sourced look-away interval of at least {@link #AFK_MIN_SECONDS}. */
    public enum Attention { LOW, ACTIVE, AFK }
    public static final int AFK_MIN_SECONDS = 60;
    /** Minutes dropdown values (Build 20). */
    public static final List<Integer> MINUTE_CHOICES = List.of(15,30,45,60,90,120);
    public enum BankStatus { VERIFIED_SAME_ACCOUNT, UNAVAILABLE }
    public enum Mode { IRONMAN, MAIN }
    /** Explicit owner action recorded per account; never inferred. */
    public enum GoalMark { SAVED, SKIPPED, DONE }

    public record Snapshot(boolean verifiedIdentity, Map<String,Integer> skills,
                           Map<String,Quest> quests, BankStatus bankStatus,
                           Set<Integer> observedItemIds, Mode mode,
                           Map<String,String> bossReadiness, Map<String,GoalMark> goals) {
        public Snapshot {
            skills=Map.copyOf(skills); quests=Map.copyOf(quests);
            Objects.requireNonNull(bankStatus); observedItemIds=Set.copyOf(observedItemIds);
            mode=mode==null?Mode.IRONMAN:mode;
            bossReadiness=Map.copyOf(bossReadiness); goals=Map.copyOf(goals);
            if (skills.values().stream().anyMatch(x -> x == null || x < 1 || x > 99))
                throw new IllegalArgumentException("invalid level");
        }
        /** Build 17/18 constructor: Ironman default, no boss readiness or saved goals. */
        public Snapshot(boolean verifiedIdentity, Map<String,Integer> skills, Map<String,Quest> quests,
                        BankStatus bankStatus, Set<Integer> observedItemIds) {
            this(verifiedIdentity,skills,quests,bankStatus,observedItemIds,Mode.IRONMAN,Map.of(),Map.of());
        }
        public Snapshot withMode(Mode m){return new Snapshot(verifiedIdentity,skills,quests,bankStatus,observedItemIds,m,bossReadiness,goals);}
        public Snapshot withGoals(Map<String,GoalMark> g){return new Snapshot(verifiedIdentity,skills,quests,bankStatus,observedItemIds,mode,bossReadiness,g);}
        public Snapshot withBossReadiness(Map<String,String> b){return new Snapshot(verifiedIdentity,skills,quests,bankStatus,observedItemIds,mode,b,goals);}
        Quest quest(String name) {return quests.getOrDefault(name, Quest.UNKNOWN);}
        State completed(String name) {return switch(quest(name)) {
            case FINISHED -> State.MET; case NOT_STARTED, IN_PROGRESS -> State.UNMET; case UNKNOWN -> State.UNKNOWN;
        };}
        State level(String skill,int minimum) {
            Integer value=skills.get(skill); return value==null ? State.UNKNOWN : value>=minimum ? State.MET : State.UNMET;
        }
        State item(int id) {
            if (bankStatus != BankStatus.VERIFIED_SAME_ACCOUNT) return State.UNKNOWN;
            return observedItemIds.contains(id) ? State.MET : State.UNMET;
        }
    }
    public record Preferences(Focus focus, Attention attention, int minutes) {
        public Preferences { Objects.requireNonNull(focus); Objects.requireNonNull(attention); if(minutes<=0) throw new IllegalArgumentException("minutes"); }
    }
    /** First nine components are the Build 17/18 contract; the rest are Build 19 explanation fields. */
    public record Suggestion(String id, String title, String why, State readiness,
                             String requirement, String source, Focus focus,
                             Attention attention, int minimumMinutes,
                             GuideRule.Category category, String section, List<String> missing,
                             String nextStep, String outfitterBoss, int score, GoalMark goal,
                             boolean optional, List<String> unverified, int afkSeconds,
                             PathfinderTiming.Start start) {
        public Suggestion {
            missing=List.copyOf(missing); unverified=List.copyOf(unverified);
            start=start==null?PathfinderTiming.Start.NOT_TIME_BOUND:start;
        }
        /** Pre-CP-2 shape (no start-time verdict). */
        public Suggestion(String id, String title, String why, State readiness, String requirement, String source,
                          Focus focus, Attention attention, int minimumMinutes, GuideRule.Category category, String section,
                          List<String> missing, String nextStep, String outfitterBoss, int score, GoalMark goal,
                          boolean optional, List<String> unverified, int afkSeconds) {
            this(id,title,why,readiness,requirement,source,focus,attention,minimumMinutes,category,section,missing,nextStep,
                outfitterBoss,score,goal,optional,unverified,afkSeconds,PathfinderTiming.Start.NOT_TIME_BOUND);
        }
        /** Requirements observed AND the window can honestly start it (CP-2). */
        public boolean readyNow() { return readiness==State.MET && start!=PathfinderTiming.Start.UNKNOWN_FOR_WINDOW; }
    }

    public static List<Suggestion> suggest(Snapshot s, Preferences p) {
        Objects.requireNonNull(s); Objects.requireNonNull(p);
        if(!s.verifiedIdentity()) return List.of();
        List<Suggestion> out=new ArrayList<>();
        Set<String> goalQuests=goalPrerequisiteQuests(s);
        for(GuideRule r:GuideData.rules()) {
            Suggestion x=evaluate(r,s,goalQuests);
            if(x==null)continue;
            if(!passes(p,x))continue;
            out.add(timed(x,r,s,p));
        }
        out.sort(Comparator.comparingInt(Suggestion::score).reversed()
            .thenComparing(x->x.readiness()==State.MET?0:x.readiness()==State.UNKNOWN?1:2)
            .thenComparing(Suggestion::title));
        return diversify(out);
    }
    /** CP-2: start-time penalty for unknown travel in a short window; bank inputs for bank-standing methods. */
    static final int UNKNOWN_TRAVEL_PENALTY = 200, INPUTS_OBSERVED_BONUS = 60, INPUTS_MISSING_PENALTY = 80;
    static Suggestion timed(Suggestion x,GuideRule r,Snapshot s,Preferences p) {
        String why=x.why(), requirement=x.requirement(); State readiness=x.readiness(); int score=x.score();
        var access=PathfinderTiming.access(r);
        PathfinderTiming.Start start=PathfinderTiming.Start.NOT_TIME_BOUND;
        if(access==PathfinderTiming.Access.BANKSTANDING) {
            start=PathfinderTiming.Start.STARTABLE_AT_BANK;
            var in=PathfinderTiming.inputs(r,s);
            why=why+" Can be started at a bank.";
            switch(in.state()) {
                case OBSERVED -> { score+=INPUTS_OBSERVED_BONUS; why=why+" Inputs ("+in.label()+") seen in your last bank read."; }
                case NOT_OBSERVED -> { score-=INPUTS_MISSING_PENALTY; why=why+" Inputs ("+in.label()+") not seen in your last bank read."; }
                case BANK_UNKNOWN -> why=why+" Open your bank to check inputs ("+in.label()+").";
                default -> { if(!in.label().isEmpty()) why=why+" Needs "+in.label()+"."; }
            }
        } else if(PathfinderTiming.timeSensitive(x.category()) && p.minutes()<=PathfinderTiming.SHORT_WINDOW_MINUTES) {
            score-=UNKNOWN_TRAVEL_PENALTY;
            start=PathfinderTiming.Start.UNKNOWN_FOR_WINDOW;
            why=why+" Travel and set-up time are not modelled, so this may not fit "+p.minutes()+" minutes.";
            requirement=requirement+" · start time unknown for "+p.minutes()+" min";
        }
        return new Suggestion(x.id(),x.title(),why,readiness,requirement,x.source(),x.focus(),x.attention(),x.minimumMinutes(),
            x.category(),x.section(),x.missing(),x.nextStep(),x.outfitterBoss(),score,x.goal(),x.optional(),x.unverified(),x.afkSeconds(),start);
    }
    /** Greedy re-rank: each further pick from an already-used category costs DIVERSITY points, so a
     *  plan mixes quests, bosses, AFK, money and gear instead of one category repeated. Stable. */
    static final int DIVERSITY = 45;
    static List<Suggestion> diversify(List<Suggestion> sorted) {
        List<Suggestion> pool=new ArrayList<>(sorted), out=new ArrayList<>(sorted.size());
        Map<GuideRule.Category,Integer> used=new EnumMap<>(GuideRule.Category.class);
        while(!pool.isEmpty()) {
            int bestIdx=0; int best=Integer.MIN_VALUE; int bestBand=Integer.MAX_VALUE;
            for(int i=0;i<pool.size();i++) {
                Suggestion x=pool.get(i);
                int eff=x.score()-DIVERSITY*used.getOrDefault(x.category(),0);
                // Variety reorders within a band. It never lifts something you cannot start over something you can.
                int band=band(x);
                if(band<bestBand || (band==bestBand && eff>best)){best=eff;bestIdx=i;bestBand=band;}
            }
            Suggestion pick=pool.remove(bestIdx);
            used.merge(pick.category(),1,Integer::sum);
            out.add(pick);
        }
        return List.copyOf(out);
    }
    private static int band(Suggestion x) {
        if(x.readiness()==State.MET || x.goal()==GoalMark.SAVED || x.score()>=300) return 0;
        return x.readiness()==State.UNKNOWN?1:2;
    }
    /** Everything evaluable regardless of focus/attention/time (for coverage and goal views). */
    public static List<Suggestion> evaluateAll(Snapshot s) {
        if(!s.verifiedIdentity())return List.of();
        Set<String> goalQuests=goalPrerequisiteQuests(s);
        List<Suggestion> out=new ArrayList<>();
        for(GuideRule r:GuideData.rules()) { var x=evaluate(r,s,goalQuests); if(x!=null)out.add(x); }
        return out;
    }
    /** Sourced AFK methods that are fights against monsters, so a PvM filter must find them. */
    static final Set<String> COMBAT_AFK = Set.of("afk_brutus_afk","afk_nmz_melee","afk_nmz_ranged","afk_vyrewatch",
        "afk_monkeys_barrage","afk_monkeys_chinning","afk_gemstone_crabs","afk_sand_crabs","afk_ammonite_crabs");
    static boolean passes(Preferences p,Suggestion s) {
        boolean focus=switch(p.focus()) {
            case ANY -> true;
            case AFK -> s.category()==GuideRule.Category.AFK;
            case PVM -> s.focus()==Focus.PVM || COMBAT_AFK.contains(s.id());
            default -> p.focus()==s.focus();
        };
        boolean attention=switch(p.attention()) {
            case ACTIVE -> true;
            case LOW -> s.attention()==Attention.LOW;
            // Never inferred: only a sourced look-away interval qualifies as AFK.
            case AFK -> s.afkSeconds()>=AFK_MIN_SECONDS;
        };
        return focus && attention && s.minimumMinutes()<=p.minutes();
    }

    /** Unfinished quests required by the owner's saved goals (goal-directed prioritisation). */
    private static Set<String> goalPrerequisiteQuests(Snapshot s) {
        Set<String> out=new HashSet<>();
        for(var e:s.goals().entrySet()) {
            if(e.getValue()!=GoalMark.SAVED)continue;
            for(GuideRule r:GuideData.rules()) if(r.id().equals(e.getKey())) {
                Deque<String> todo=new ArrayDeque<>(r.quests());
                if(r.completesQuest()!=null) todo.add(r.completesQuest());
                while(!todo.isEmpty()) {
                    String q=todo.pop();
                    if(!out.add(q))continue;
                    todo.addAll(GuideData.questPrerequisites().getOrDefault(q,List.of()));
                }
            }
        }
        return out;
    }

    static Suggestion evaluate(GuideRule r,Snapshot s,Set<String> goalQuests) {
        GoalMark mark=s.goals().get(r.id());
        if(mark==GoalMark.SKIPPED || mark==GoalMark.DONE)return null; // explicit owner action, provenance kept by host
        if(r.mode()==GuideRule.ModeScope.IRONMAN && s.mode()!=Mode.IRONMAN)return null;
        if(r.mode()==GuideRule.ModeScope.MAIN && s.mode()!=Mode.MAIN)return null;
        // Done / not applicable.
        Quest own=r.completesQuest()==null?null:s.quest(r.completesQuest());
        if(r.category()==GuideRule.Category.QUEST) {
            if(own==Quest.FINISHED || own==Quest.UNKNOWN) return null; // UNKNOWN is never claimed unfinished
        } else if(own!=null) {
            if(own==Quest.FINISHED) return null;
            if(r.doneWhenStarted() && own==Quest.IN_PROGRESS) return null;
        }
        if(!r.doneAt().isEmpty() && r.doneAt().entrySet().stream().allMatch(e->s.level(e.getKey(),e.getValue())==State.MET))return null;
        for(int id:r.skipIfOwned()) if(s.item(id)==State.MET) return null; // positive observation only
        if(!r.needsOwned().isEmpty() && r.needsOwned().stream().noneMatch(id->s.item(id)==State.MET)) return null;
        // Requirements.
        List<String> missing=new ArrayList<>(), unknown=new ArrayList<>();
        for(var e:r.skills().entrySet()) {
            switch(s.level(e.getKey(),e.getValue())) {
                case UNMET -> missing.add(e.getKey()+" "+e.getValue()+" (have "+s.skills().get(e.getKey())+")");
                case UNKNOWN -> unknown.add(e.getKey()+" "+e.getValue());
                default -> {}
            }
        }
        String firstMissingQuest=null;
        for(String q:r.quests()) {
            Quest st=s.quest(q);
            if(st==Quest.FINISHED)continue;
            if(st==Quest.UNKNOWN){unknown.add(q);continue;}
            missing.add(q+(st==Quest.IN_PROGRESS?" (in progress)":" (not started)"));
            if(firstMissingQuest==null || order(q)<order(firstMissingQuest)) firstMissingQuest=q;
        }
        State readiness=!missing.isEmpty()?State.UNMET:!unknown.isEmpty()?State.UNKNOWN:State.MET;
        // Explanation fields.
        String title=r.title(), why=r.why(), next=r.nextStep();
        if(r.category()==GuideRule.Category.QUEST) {
            title=(own==Quest.IN_PROGRESS?"Continue ":"Start ")+r.title();
            if(r.id().equals("quest_sote")) title="Work toward Song of the Elves";
            if(own==Quest.IN_PROGRESS) why="In progress in your quest journal. "+why;
            next=readiness==State.MET?(own==Quest.IN_PROGRESS?"Resume where you left off.":"Start the quest."):next;
        }
        if(firstMissingQuest!=null) {
            String first=firstStep(firstMissingQuest,s,new HashSet<>());
            next=first.equals(firstMissingQuest)?"Next: complete "+first+".":"Next: complete "+first+" (needed for "+firstMissingQuest+").";
        }
        else if(!missing.isEmpty()) next="Next: train "+missing.get(0).replaceAll(" \\(have.*","")+".";
        if(r.category()==GuideRule.Category.MONEY && s.mode()==Mode.MAIN)
            why="Main account: ironman.guide coin estimate shown; market value is not modelled. "+why;
        if(r.category()==GuideRule.Category.GEAR && s.bankStatus()!=BankStatus.VERIFIED_SAME_ACCOUNT)
            why=why+" Bank not observed this login, so ownership is unknown.";
        String boss=r.outfitterBoss();
        if(boss!=null) {
            String bank=s.bossReadiness().get(boss);
            if(bank!=null) why=why+" Best in Bank: "+bank+".";
        }
        String requirement=requirementText(r,missing,unknown);
        int score=score(r,s,readiness,own,mark,goalQuests);
        return new Suggestion(r.id(),title,why,readiness,requirement,r.source(),r.focus(),r.attention(),r.minimumMinutes(),
            r.category(),r.section(),missing,next,boss,score,mark,r.optional(),r.unverified(),r.afkSeconds());
    }
    /** Follows unfinished prerequisites down to a quest that can be worked on now. Unknown quests are not assumed unfinished. */
    private static String firstStep(String quest,Snapshot s,Set<String> seen) {
        if(!seen.add(quest))return quest;
        String best=null;
        for(String q:GuideData.questPrerequisites().getOrDefault(quest,List.of())) {
            Quest st=s.quest(q);
            if(st==Quest.FINISHED || st==Quest.UNKNOWN)continue;
            if(best==null || order(q)<order(best))best=q;
        }
        return best==null?quest:firstStep(best,s,seen);
    }
    private static String requirementText(GuideRule r,List<String> missing,List<String> unknown) {
        if(!missing.isEmpty()) return "Missing: "+String.join(", ",missing);
        if(!unknown.isEmpty()) return "Not observed: "+String.join(", ",unknown);
        if(!r.unverified().isEmpty()) return "Observed requirements met; check: "+r.unverified().get(0);
        return r.skills().isEmpty() && r.quests().isEmpty()?"No observable prerequisite":"Observed requirements met";
    }
    private static int order(String quest) {
        for(var e:GuideQuestOrder.entries()) if(e.name().equals(quest)) return e.order();
        return Integer.MAX_VALUE;
    }
    private static final Map<String,Integer> DEPENDENTS = dependents();
    private static Map<String,Integer> dependents() {
        Map<String,Integer> m=new HashMap<>();
        for(var e:GuideData.questPrerequisites().entrySet()) for(String q:e.getValue()) m.merge(q,1,Integer::sum);
        for(GuideRule r:GuideData.rules()) if(r.category()!=GuideRule.Category.QUEST) for(String q:r.quests()) m.merge(q,1,Integer::sum);
        return m;
    }
    static int score(GuideRule r,Snapshot s,State readiness,Quest own,GoalMark mark,Set<String> goalQuests) {
        int score=switch(readiness){case MET->300;case UNKNOWN->150;case UNMET->0;};
        if(mark==GoalMark.SAVED) score+=250;
        if(r.completesQuest()!=null && goalQuests.contains(r.completesQuest())) score+=150;
        switch(r.category()) {
            case QUEST -> {
                if(own==Quest.IN_PROGRESS) score+=400;
                score+=Math.max(0,100-r.order()/3);                       // follow the guide route
                score+=Math.min(60,DEPENDENTS.getOrDefault(r.completesQuest(),0)*6); // unlock value
            }
            case BOSS, LEGACY -> {
                String bank=r.outfitterBoss()==null?null:s.bossReadiness().get(r.outfitterBoss());
                if(bank!=null) score+=bank.startsWith("READY")?120:bank.startsWith("GEAR READY")?90:bank.startsWith("OWNED")?40:0;
                if(!r.needsOwned().isEmpty()) score+=100; // positively observed key item
                if(!r.quests().isEmpty() && readiness==State.MET) score+=40; // an unlock you have earned
            }
            // CP-2 (BQA-R12-006): look-away length is a filter (Attention.AFK), never a reward by itself.
            case AFK -> {}
            case MONEY -> score+=s.mode()==Mode.IRONMAN?Math.min(80,(r.gpLowK()+r.gpHighK())/30):0;
            case GEAR -> score+=r.optional()?0:20;
            case SKILL -> score+=30;
        }
        if(r.optional()) score-=40;
        boolean nothingObservable=r.skills().isEmpty() && r.quests().isEmpty() && r.doneAt().isEmpty()
            && r.needsOwned().isEmpty() && r.category()!=GuideRule.Category.QUEST && r.category()!=GuideRule.Category.LEGACY;
        if(nothingObservable) score-=90; // "ready" only because Burrow can verify nothing: rank below verified items
        // CP-2 (BQA-R12-006): no blanket reward for a higher requirement. A small bonus only when the method's
        // requirement is close to the player's own level in that skill (it is the account's current tier of method).
        if(readiness==State.MET && (r.category()==GuideRule.Category.AFK || r.category()==GuideRule.Category.MONEY)) {
            for(var e:r.skills().entrySet()) {
                Integer have=s.skills().get(e.getKey());
                if(have!=null && e.getValue()>1 && have-e.getValue()<=15) { score+=25; break; }
            }
        }
        return score;
    }
}
