# FERAL ENTERPRISES | R38 | Bank R05 O-withdrawal freeze + HoverLite v0.2.8

**OWNER WINDOWS QA ONLY · RELEASE HOLD · NOT NATIVE-VERIFIED**

This ZIP supersedes R37. It addresses the repeated in-game message:
`TrashPanda Outfitter: Best in Bank evidence changed; the old bank tag was closed for safety.`

## Source change (only two existing production Java files, one new pure gate)

- `BurrowPlugin.java`: while the SAME authenticated account, bank-open epoch and
  selected Best in Bank O tab remain valid, defer bank evidence revalidation on
  bank/inventory/equipment events and stop tick-by-tick bank rescans. A withdrawal
  may alter bank stock, but the frozen plan is NOT republished as fresh evidence.
  Leaving O ALWAYS invalidates the frozen bank snapshot and requests a brand-new
  bank scan, even when no container event was observed.
- `OutfitterBank.java`: exposes a narrow, current-setup, current-generation
  selected-O lease; covers synchronous Bank Tags events during openTag before
  Bank Tags reports the active tab. Account/mode/selection changes cannot hold O.
- `BankWithdrawalFreezeGate.java`: fail-closed pure gate. New JUnit and updated
  controller tests cover session boundaries and early-open event ordering.
- No changes to Bank Tags persistent files, withdrawal actions, inventory
  clicks, approved Outfitter item ranking, any HoverLite production or test Java,
  launcher authentication, or RuneLite APIs.

## Run the actual Windows QA

1. Extract the WHOLE ZIP into a NEW folder, not over R37. Close other dev RuneLite clients.
2. Run the root `01-BUILD-AND-LAUNCH-BOTH.cmd` (requires Windows JDK 17).
   It runs all tests before launching ONE local RuneLite client with both plugins.
3. Enable RuneLite Bank Tags. Pick a boss, choose Best in Bank, open bank, wait
   for the accepted same-login read, then click the green O.
4. **Leave O open and withdraw TWO different real banked recommended items**.
   Normal Withdraw actions must appear and each withdrawn item must land in inventory.
   The O tab should remain selected between withdrawals, with NO old-tag-closed warning.
5. Close O manually or select All items. A new bank read must be required before
   the next Best in Bank layout is authorized; reopening O after scan should show
   only remaining banked items, not items now carried in inventory.
6. Try the bank's normal tabs and another pre-existing Bank Tags tab. They must
   remain unaffected. Reopen bank and repeat with O.
7. If safe/convenient, close the bank while O is open: O must clear and never
   persist into the next login/bank-open epoch. Never deliberately risk account items.

**Important:** the plan in O is FROZEN while O is open. It is a selected withdrawal
layout, not a claim that every entry still exists after taking items out. Only
fresh evidence after closing O can authorize an updated Best in Bank plan.

## Exact failure evidence

- Copy the first JUnit failure and stack-trace assertion if Gradle fails.
- If the tab still auto-closes, screenshot the FIRST `TrashPanda Outfitter:`
  message, plus selected boss, Best in Bank mode, bank tab and relevant item.
- If Withdraw is absent, right-click the item, capture native menu and item state.
- If O persists after bank close/logout or touches a saved tag, STOP immediately.

## Verification limits

Spoons ran 64 pure Java 17-compatible freeze-gate boundary combinations and parsed
5 modified/new sources with JDK 21 `--release 17` (syntax only). Full JDK 17
Gradle, integrated Tongs L2 and RuneLite game behavior have NOT been run here.
R37's prior one-test-failing Windows trace is NOT proof of an R38 suite pass.

See `BANK-R05-WINDOWS-QA.md` for the short owner checklist.
